<?php
$page_title = 'المحاضرات';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
$pdo = get_db_connection();

$student_grade = $user['grade'];

// جلب الإعلانات العامة
$announcements = $pdo->query("SELECT * FROM announcements WHERE is_visible = 1 AND is_notification = 0 ORDER BY created_at DESC LIMIT 3")->fetchAll();

// جلب قوائم التشغيل المتاحة لصف الطالب
$stmt = $pdo->prepare("
    SELECT p.*, (SELECT COUNT(*) FROM lectures l WHERE l.playlist_id = p.id AND l.is_active = 1 AND (l.grade = ? OR l.grade = 'all')) as lecture_count
    FROM playlists p 
    WHERE p.is_active = 1 AND (p.grade = ? OR p.grade = 'all')
    HAVING lecture_count > 0
    ORDER BY p.sort_order, p.name
");
$stmt->execute([$student_grade, $student_grade]);
$playlists = $stmt->fetchAll();
?>

<div class="page-container">
    <div class="page-header">
        <h1><i class="fas fa-play-circle"></i> قوائم التشغيل المتاحة</h1>
        <p>تصفح الكورسات واختر ما تريد مشاهدته.</p>
    </div>

    <?php if (!empty($announcements)): ?>
    <div class="announcements-section">
        <h2 class="section-title"><i class="fas fa-bullhorn"></i> الإعلانات</h2>
        <div class="announcements-grid">
            <?php foreach ($announcements as $ann): ?>
            <div class="announcement-card">
                <div class="announcement-icon">
                    <i class="fas fa-info-circle"></i>
                </div>
                <div class="announcement-content">
                    <h4><?= htmlspecialchars($ann['title']) ?></h4>
                    <div class="announcement-text"><?= $ann['content'] ?></div>
                    <div class="announcement-date">
                        <i class="far fa-calendar"></i> <?= date('Y-m-d', strtotime($ann['created_at'])) ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="playlists-section">
        <h2 class="section-title"><i class="fas fa-list"></i> قوائم التشغيل</h2>
        <div class="playlists-grid">
            <?php if (empty($playlists)): ?>
                <div class="empty-state">
                    <i class="fas fa-folder-open"></i>
                    <p>لا توجد قوائم تشغيل متاحة لصفك الدراسي حالياً.</p>
                </div>
            <?php else: ?>
                <?php foreach ($playlists as $playlist): ?>
                <div class="playlist-card">
                    <a href="view_playlist.php?id=<?= $playlist['id'] ?>" class="playlist-link">
                        <div class="playlist-cover">
                            <?php if (!empty($playlist['cover_image'])): ?>
                                <img src="../<?= htmlspecialchars($playlist['cover_image']) ?>" alt="<?= htmlspecialchars($playlist['name']) ?>">
                            <?php else: ?>
                                <div class="default-cover">
                                    <i class="fas fa-film"></i>
                                </div>
                            <?php endif; ?>
                            <div class="playlist-overlay">
                                <span class="view-playlist-btn">عرض المحاضرات</span>
                            </div>
                        </div>
                        <div class="playlist-info">
                            <h3 class="playlist-title"><?= htmlspecialchars($playlist['name']) ?></h3>
                            <p class="playlist-description"><?= htmlspecialchars($playlist['description'] ?? 'لا يوجد وصف') ?></p>
                            <div class="playlist-meta">
                                <span class="lecture-count">
                                    <i class="fas fa-play-circle"></i> <?= $playlist['lecture_count'] ?> محاضرة
                                </span>
                                <?php if($playlist['grade'] != 'all'): ?>
                                <span class="playlist-grade">
                                    <i class="fas fa-user-graduate"></i> <?= get_grade_text($playlist['grade']) ?>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    /* استخدام نفس نظام الألوان من الصفحة الرئيسية */
    :root {
        --primary: #0f0f23;
        --primary-dark: #070711;
        --primary-light: #1a1a2e;
        --secondary: #00d4ff;
        --secondary-dark: #0099cc;
        --accent: #7b42f6;
        --accent-dark: #5e2fc9;
        --neon: #e5ff00ff;
        --neon-secondary: #00ffbfff;
        --gold: #ffd700;
        --silver: #c0c0c0;
        --text-dark: #0f172a;
        --text-darker: #020617;
        --text-light: #f0f8ff;
        --text-muted: #94a3b8;
        --bg-light: #0a0a18;
        --bg-dark: #050510;
        --card-light: rgba(16, 16, 36, 0.8);
        --card-dark: rgba(10, 10, 30, 0.9);
        --border-light: rgba(0, 212, 255, 0.3);
        --border-dark: rgba(123, 66, 246, 0.3);
        --shadow: 0 0 20px rgba(0, 212, 255, 0.3);
        --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.4);
        --transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        --gradient-primary: linear-gradient(135deg, #60aa00ff, #008ee0ff);
        --gradient-secondary: linear-gradient(135deg, #ff00aa, #7b42f6);
        --gradient-gold: linear-gradient(135deg, #ffd700, #ffaa00);
        --success: #00ff88;
        --danger: #ff0066;
    }

    .light-mode {
        --primary: #f0f8ff;
        --primary-dark: #d6e4f0;
        --primary-light: #ffffff;
        --secondary: #0066cc;
        --secondary-dark: #004499;
        --accent: #7b42f6;
        --accent-dark: #5e2fc9;
        --neon: #0099cc;
        --neon-secondary: #cc0066;
        --gold: #ffaa00;
        --silver: #666666;
        --text-dark: #1e293b;
        --text-darker: #0f172a;
        --text-light: #1e293b;
        --text-muted: #64748b;
        --bg-light: #f0f8ff;
        --bg-dark: #e6f2ff;
        --card-light: rgba(255, 255, 255, 0.9);
        --card-dark: rgba(240, 248, 255, 0.95);
        --border-light: rgba(0, 102, 204, 0.3);
        --border-dark: rgba(123, 66, 246, 0.3);
        --shadow: 0 0 20px rgba(0, 102, 204, 0.2);
        --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.2);
        --gradient-primary: linear-gradient(135deg, #0066cc, #7b42f6);
        --gradient-secondary: linear-gradient(135deg, #cc0066, #7b42f6);
        --gradient-gold: linear-gradient(135deg, #ffaa00, #ff6600);
        --success: #00aa55;
        --danger: #cc0044;
    }

    /* الحل الجذري لمشكلة الهيدر */
    .student-container {
        min-height: 100vh;
        position: relative;
        z-index: 1;
        padding-top: 90px; /* مسافة آمنة بعد الهيدر */
    }

    .main-content {
        min-height: calc(100vh - 160px);
        position: relative;
        z-index: 1;
    }

    .page-container {
        padding: 2rem;
        max-width: 1400px;
        margin: 0 auto;
        min-height: calc(100vh - 200px);
    }

    .page-header {
        text-align: center;
        margin-bottom: 3rem;
        animation: fadeInUp 0.8s ease-out;
    }

    .page-header h1 {
        font-size: 2.5rem;
        font-weight: 800;
        color: var(--text-light);
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 1rem;
    }

    .light-mode .page-header h1 {
        color: var(--text-dark);
    }

    .page-header h1 i {
        color: var(--neon);
        font-size: 2.8rem;
    }

    .light-mode .page-header h1 i {
        color: var(--secondary);
    }

    .page-header p {
        font-size: 1.2rem;
        color: var(--text-light);
        opacity: 0.9;
        font-weight: 600;
    }

    .light-mode .page-header p {
        color: var(--text-dark);
    }

    .section-title {
        font-size: 1.8rem;
        font-weight: 700;
        color: var(--text-light);
        margin-bottom: 2rem;
        display: flex;
        align-items: center;
        gap: 0.8rem;
        border-bottom: 2px solid var(--border-light);
        padding-bottom: 0.5rem;
    }

    .light-mode .section-title {
        color: var(--text-dark);
        border-bottom-color: var(--border-light);
    }

    .section-title i {
        color: var(--neon);
    }

    .light-mode .section-title i {
        color: var(--secondary);
    }

    /* تصميم الإعلانات */
    .announcements-section {
        margin-bottom: 3rem;
        animation: fadeInUp 0.8s ease-out 0.2s both;
    }

    .announcements-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
        gap: 1.5rem;
    }

    .announcement-card {
        background: var(--card-light);
        border-radius: 15px;
        padding: 1.5rem;
        border: 1px solid var(--border-light);
        box-shadow: var(--shadow);
        transition: var(--transition);
        display: flex;
        align-items: flex-start;
        gap: 1rem;
    }

    .light-mode .announcement-card {
        background: var(--card-light);
        border: 1px solid var(--border-light);
        box-shadow: var(--shadow);
    }

    .announcement-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 212, 255, 0.2);
    }

    .light-mode .announcement-card:hover {
        box-shadow: 0 10px 25px rgba(0, 102, 204, 0.2);
    }

    .announcement-icon {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        background: var(--gradient-primary);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.3rem;
        flex-shrink: 0;
    }

    .announcement-content {
        flex: 1;
    }

    .announcement-content h4 {
        color: var(--text-light);
        margin-bottom: 0.8rem;
        font-weight: 700;
        font-size: 1.2rem;
    }

    .light-mode .announcement-content h4 {
        color: var(--text-dark);
    }

    .announcement-text {
        color: var(--text-light);
        line-height: 1.6;
        margin-bottom: 1rem;
        font-weight: 600;
        opacity: 0.9;
    }

    .light-mode .announcement-text {
        color: var(--text-dark);
    }

    .announcement-date {
        color: var(--neon);
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-weight: 600;
    }

    .light-mode .announcement-date {
        color: var(--secondary);
    }

    /* تصميم قوائم التشغيل */
    .playlists-section {
        animation: fadeInUp 0.8s ease-out 0.4s both;
    }

    .playlists-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 2rem;
    }

    .playlist-card {
        background: var(--card-light);
        border-radius: 15px;
        overflow: hidden;
        border: 1px solid var(--border-light);
        box-shadow: var(--shadow);
        transition: var(--transition);
        height: 100%;
    }

    .light-mode .playlist-card {
        background: var(--card-light);
        border: 1px solid var(--border-light);
        box-shadow: var(--shadow);
    }

    .playlist-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 30px rgba(0, 212, 255, 0.3);
    }

    .light-mode .playlist-card:hover {
        box-shadow: 0 15px 30px rgba(0, 102, 204, 0.3);
    }

    .playlist-link {
        text-decoration: none;
        color: inherit;
        display: block;
        height: 100%;
    }

    .playlist-cover {
        position: relative;
        height: 200px;
        overflow: hidden;
    }

    .playlist-cover img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: var(--transition);
    }

    .default-cover {
        width: 100%;
        height: 100%;
        background: var(--gradient-primary);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 3rem;
    }

    .playlist-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: var(--transition);
    }

    .playlist-card:hover .playlist-overlay {
        opacity: 1;
    }

    .playlist-card:hover .playlist-cover img {
        transform: scale(1.1);
    }

    .view-playlist-btn {
        background: var(--gradient-primary);
        color: white;
        padding: 0.8rem 1.5rem;
        border-radius: 25px;
        font-weight: 600;
        font-size: 0.9rem;
    }

    .playlist-info {
        padding: 1.5rem;
    }

    .playlist-title {
        color: var(--text-light);
        font-size: 1.3rem;
        font-weight: 700;
        margin-bottom: 0.8rem;
        line-height: 1.4;
    }

    .light-mode .playlist-title {
        color: var(--text-dark);
    }

    .playlist-description {
        color: var(--text-light);
        font-size: 0.95rem;
        line-height: 1.5;
        margin-bottom: 1.2rem;
        opacity: 0.9;
        font-weight: 600;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .light-mode .playlist-description {
        color: var(--text-dark);
    }

    .playlist-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.85rem;
    }

    .lecture-count, .playlist-grade {
        color: var(--neon);
        display: flex;
        align-items: center;
        gap: 0.3rem;
        font-weight: 600;
    }

    .light-mode .lecture-count,
    .light-mode .playlist-grade {
        color: var(--secondary);
    }

    /* حالة فارغة */
    .empty-state {
        grid-column: 1 / -1;
        text-align: center;
        padding: 4rem 2rem;
        color: var(--text-light);
    }

    .light-mode .empty-state {
        color: var(--text-dark);
    }

    .empty-state i {
        font-size: 4rem;
        margin-bottom: 1.5rem;
        opacity: 0.5;
        color: var(--neon);
    }

    .light-mode .empty-state i {
        color: var(--secondary);
    }

    .empty-state p {
        font-size: 1.2rem;
        font-weight: 600;
        opacity: 0.8;
    }

    /* تأثيرات الحركة */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    /* التصميم المتجاوب */
    @media (max-width: 768px) {
        .page-container {
            padding: 1rem;
        }

        .page-header h1 {
            font-size: 2rem;
        }

        .announcements-grid {
            grid-template-columns: 1fr;
        }

        .playlists-grid {
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
        }

        .announcement-card {
            flex-direction: column;
            text-align: center;
        }

        .announcement-icon {
            align-self: center;
        }
    }

    @media (max-width: 480px) {
        .page-header h1 {
            font-size: 1.8rem;
        }

        .playlists-grid {
            grid-template-columns: 1fr;
        }

        .section-title {
            font-size: 1.5rem;
        }
    }
</style>

<?php include 'partials/footer.php'; ?>