</div>
    </main>
    
    <footer class="student-footer">
        <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. جميع الحقوق محفوظة.</p>
    </footer>

    <style>
        .student-footer {
            background: var(--card-light);
            border-top: 1px solid var(--border-light);
            padding: 1.2rem;
            text-align: center;
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .light-mode .student-footer {
            background: var(--card-light);
            border-top: 1px solid var(--border-light);
            color: var(--text-dark);
        }

        .student-footer p {
            margin: 0;
            opacity: 0.9;
        }

        @media (max-width: 768px) {
            .student-footer {
                padding: 1rem;
                font-size: 0.85rem;
            }
        }
    </style>
 <script src="<?= SITE_URL ?>/assets/js/main.js"></script>
    <script>
        
            // Dark/Light Mode Toggle
            const themeToggle = document.createElement('button');
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            themeToggle.className = 'theme-toggle-student';
            themeToggle.style.cssText = `
                position: fixed;
                bottom: 20px;
                left: 20px;
                width: 50px;
                height: 50px;
                border-radius: 50%;
                background: var(--gradient-primary);
                color: white;
                border: none;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 1.2rem;
                z-index: 999;
                box-shadow: var(--shadow);
                transition: var(--transition);
            `;

            document.body.appendChild(themeToggle);

            // Check for saved theme preference or default to dark
            const currentTheme = localStorage.getItem('theme') || 'dark';
            if (currentTheme === 'light') {
                document.documentElement.classList.add('light-mode');
                themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            }
            
            themeToggle.addEventListener('click', function() {
                document.documentElement.classList.toggle('light-mode');
                
                if (document.documentElement.classList.contains('light-mode')) {
                    themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
                    localStorage.setItem('theme', 'light');
                } else {
                    themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
                    localStorage.setItem('theme', 'dark');
                }
            });
    
    </script>
</body>
</html>