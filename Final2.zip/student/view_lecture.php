<?php
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/db_connection.php';
// التحقق من تسجيل الدخول
if (!current_user()) {
    redirect('login.php');
}

// التحقق من وجود معرف المحاضرة
if (!isset($_GET['id'])) {
    die('معرف المحاضرة مطلوب.');
}

$lecture_id = intval($_GET['id']);

// جلب بيانات المحاضرة
$stmt = $pdo->prepare("SELECT l.*, p.name as playlist_name FROM lectures l JOIN playlists p ON l.playlist_id = p.id WHERE l.id = ?");
$stmt->execute([$lecture_id]);
$lecture = $stmt->fetch();

if (!$lecture) {
    die('المحاضرة غير موجودة.');
}

// التحقق من صلاحية الوصول للمحاضرة
$user = current_user();
$has_access = false;
$remaining_views = 0;

if ($user['type'] === 'admin') {
    // الأدمن لديه وصول كامل
    $has_access = true;
} elseif ($user['type'] === 'student') {
    // التحقق من أن المحاضرة للصف الدراسي الصحيح
    if ($lecture['grade'] !== 'all' && $lecture['grade'] !== $user['grade']) {
        die('هذه المحاضرة غير متاحة لصفك الدراسي.');
    }
    
    // التحقق من الوصول للمحاضرة
    if ($lecture['is_free']) {
        // المحاضرة مجانية - الوصول مفتوح
        $has_access = true;
        $remaining_views = 'unlimited';
    } else {
        // التحقق من وجود كود تفعيل
        $stmt = $pdo->prepare("SELECT * FROM student_lecture_access WHERE student_id = ? AND lecture_id = ?");
        $stmt->execute([$user['id'], $lecture_id]);
        $access = $stmt->fetch();
        
        if ($access && $access['remaining_views'] > 0) {
            $has_access = true;
            $remaining_views = $access['remaining_views'];
        } else {
            // التحقق من وجود كود غير مستخدم
            $stmt = $pdo->prepare("SELECT * FROM codes WHERE lecture_id = ? AND is_used = 0 LIMIT 1");
            $stmt->execute([$lecture_id]);
            $available_code = $stmt->fetch();
            
            if ($available_code) {
                echo "<div class='access-denied-container'>
                        <div class='access-denied-card'>
                            <div class='access-icon'>
                                <i class='fas fa-key'></i>
                            </div>
                            <h3>هذه المحاضرة تتطلب كود تفعيل</h3>
                            <p>يجب عليك تفعيل المحاضرة باستخدام كود قبل مشاهدتها.</p>
                            <a href='activate_lecture.php?lecture_id=$lecture_id' class='btn btn-primary'>
                                <i class='fas fa-key'></i> تفعيل المحاضرة
                            </a>
                        </div>
                      </div>";
            } else {
                echo "<div class='access-denied-container'>
                        <div class='access-denied-card'>
                            <div class='access-icon'>
                                <i class='fas fa-times-circle'></i>
                            </div>
                            <h3>لا توجد أكواد متاحة</h3>
                            <p>لا توجد أكواد متاحة لهذه المحاضرة حالياً.</p>
                            <a href='index.php' class='btn btn-secondary'>
                                <i class='fas fa-arrow-right'></i> العودة للقائمة
                            </a>
                        </div>
                      </div>";
            }
            exit;
        }
    }
}

if (!$has_access) {
    die('ليس لديك صلاحية الوصول لهذه المحاضرة.');
}

// جلب المرفقات
$att_stmt = $pdo->prepare("SELECT * FROM lecture_attachments WHERE lecture_id = ?");
$att_stmt->execute([$lecture_id]);
$attachments = $att_stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($lecture['title']) ?> - <?= SITE_NAME ?></title>
   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0f0f23;
            --primary-dark: #070711;
            --primary-light: #1a1a2e;
            --secondary: #00d4ff;
            --secondary-dark: #0099cc;
            --accent: #7b42f6;
            --accent-dark: #5e2fc9;
            --neon: #e5ff00ff;
            --neon-secondary: #00ffbfff;
            --gold: #ffd700;
            --silver: #c0c0c0;
            --text-dark: #0f172a;
            --text-darker: #020617;
            --text-light: #f0f8ff;
            --text-muted: #94a3b8;
            --bg-light: #0a0a18;
            --bg-dark: #050510;
            --card-light: rgba(16, 16, 36, 0.8);
            --card-dark: rgba(10, 10, 30, 0.9);
            --border-light: rgba(0, 212, 255, 0.3);
            --border-dark: rgba(123, 66, 246, 0.3);
            --shadow: 0 0 20px rgba(0, 212, 255, 0.3);
            --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.4);
            --transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --gradient-primary: linear-gradient(135deg, #60aa00ff, #008ee0ff);
            --gradient-secondary: linear-gradient(135deg, #ff00aa, #7b42f6);
            --gradient-gold: linear-gradient(135deg, #ffd700, #ffaa00);
            --success: #00ff88;
            --danger: #ff0066;
        }

        .light-mode {
            --primary: #f0f8ff;
            --primary-dark: #d6e4f0;
            --primary-light: #ffffff;
            --secondary: #0066cc;
            --secondary-dark: #004499;
            --accent: #7b42f6;
            --accent-dark: #5e2fc9;
            --neon: #0099cc;
            --neon-secondary: #cc0066;
            --gold: #ffaa00;
            --silver: #666666;
            --text-dark: #1e293b;
            --text-darker: #0f172a;
            --text-light: #1e293b;
            --text-muted: #64748b;
            --bg-light: #f0f8ff;
            --bg-dark: #e6f2ff;
            --card-light: rgba(255, 255, 255, 0.9);
            --card-dark: rgba(240, 248, 255, 0.95);
            --border-light: rgba(0, 102, 204, 0.3);
            --border-dark: rgba(123, 66, 246, 0.3);
            --shadow: 0 0 20px rgba(0, 102, 204, 0.2);
            --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.2);
            --gradient-primary: linear-gradient(135deg, #0066cc, #7b42f6);
            --gradient-secondary: linear-gradient(135deg, #cc0066, #7b42f6);
            --gradient-gold: linear-gradient(135deg, #ffaa00, #ff6600);
            --success: #00aa55;
            --danger: #cc0044;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: var(--bg-light);
            color: var(--text-light);
            overflow-x: hidden;
            line-height: 1.6;
            min-height: 100vh;
            transition: background-color 0.8s ease, color 0.5s ease;
            padding: 0;
            margin: 0;
        }

        .light-mode body {
            background: var(--bg-light);
            color: var(--text-dark);
        }

        /* خلفية ثابتة */
        .cyber-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -2;
            overflow: hidden;
            background: 
                radial-gradient(circle at 20% 80%, rgba(0, 212, 255, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(123, 66, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(255, 0, 170, 0.05) 0%, transparent 50%);
        }

        .grid-lines {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(0, 212, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 212, 255, 0.05) 1px, transparent 1px);
            background-size: 50px 50px;
        }

        .lecture-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            min-height: calc(100vh - 120px);
            padding-top: 90px; /* مسافة آمنة بعد الهيدر */
        }

        /* الهيدر المحسن */
        .lecture-header {
            background: var(--card-light);
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-light);
            border-right: 4px solid var(--secondary);
        }

        .light-mode .lecture-header {
            background: var(--card-light);
            border: 1px solid var(--border-light);
        }

        .lecture-header h1 {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            color: var(--text-light);
            line-height: 1.3;
            font-weight: 700;
        }

        .light-mode .lecture-header h1 {
            color: var(--text-dark);
        }

        .lecture-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 1.5rem;
            margin-bottom: 1rem;
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            color: var(--text-light);
            font-size: 1rem;
            font-weight: 600;
        }

        .light-mode .meta-item {
            color: var(--text-dark);
        }

        .meta-item i {
            color: var(--neon);
            width: 20px;
            font-size: 1.2rem;
        }

        .light-mode .meta-item i {
            color: var(--secondary);
        }

        .views-info {
            background: rgba(255, 193, 7, 0.1);
            padding: 1.2rem;
            border-radius: 10px;
            margin-top: 1.5rem;
            text-align: center;
            border: 1px solid rgba(255, 193, 7, 0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
            flex-wrap: wrap;
        }

        .views-info.expired {
            background: rgba(255, 0, 102, 0.1);
            border: 1px solid rgba(255, 0, 102, 0.3);
        }

        .views-info i {
            font-size: 1.3rem;
            color: var(--warning-color);
        }

        .views-info.expired i {
            color: var(--danger);
        }

        /* حاوية الفيديو المحسنة */
        .video-container {
            background: var(--card-light);
            border-radius: 15px;
            overflow: hidden;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            position: relative;
            width: 100%;
            border: 1px solid var(--border-light);
        }

        .light-mode .video-container {
            background: var(--card-light);
            border: 1px solid var(--border-light);
        }

        .video-wrapper {
            width: 100%;
            position: relative;
            background: #000;
        }

        /* تحسينات متجاوبة للفيديو */
        .responsive-video-container {
            position: relative;
            width: 100%;
            height: 0;
            padding-bottom: 56.25%; /* نسبة 16:9 */
            overflow: hidden;
        }

        .responsive-video-container iframe,
        .responsive-video-container video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: 0;
        }

        .video-placeholder {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, #333, #555);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.1rem;
        }

        .video-placeholder i {
            font-size: 2.5rem;
            margin-bottom: 1rem;
        }

        /* معلومات المحاضرة */
        .lecture-info {
            background: var(--card-light);
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-light);
        }

        .light-mode .lecture-info {
            background: var(--card-light);
            border: 1px solid var(--border-light);
        }

        .lecture-info h2 {
            margin-bottom: 1.5rem;
            color: var(--text-light);
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            font-weight: 700;
        }

        .light-mode .lecture-info h2 {
            color: var(--text-dark);
        }

        .lecture-info h2 i {
            color: var(--neon);
            font-size: 1.8rem;
        }

        .light-mode .lecture-info h2 i {
            color: var(--secondary);
        }

        .lecture-description {
            color: var(--text-light);
            font-size: 1.1rem;
            line-height: 1.7;
            margin-bottom: 2rem;
            font-weight: 600;
            opacity: 0.9;
        }

        .light-mode .lecture-description {
            color: var(--text-dark);
        }

        /* المرفقات */
        .attachments-section h3 {
            margin-bottom: 1.5rem;
            color: var(--text-light);
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1.3rem;
            font-weight: 700;
        }

        .light-mode .attachments-section h3 {
            color: var(--text-dark);
        }

        .attachments-section h3 i {
            color: var(--neon);
        }

        .light-mode .attachments-section h3 i {
            color: var(--secondary);
        }

        .attachments {
            list-style: none;
            padding: 0;
        }

        .attachment-item {
            padding: 1.5rem;
            border: 1px solid var(--border-light);
            border-radius: 10px;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: var(--transition);
            background: rgba(0, 212, 255, 0.05);
        }

        .light-mode .attachment-item {
            background: rgba(0, 102, 204, 0.05);
            border: 1px solid var(--border-light);
        }

        .attachment-item:hover {
            border-color: var(--secondary);
            transform: translateX(-5px);
        }

        .attachment-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .attachment-icon {
            width: 50px;
            height: 50px;
            background: var(--gradient-primary);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.3rem;
        }

        .attachment-details {
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
        }

        .attachment-name {
            font-weight: 700;
            color: var(--text-light);
            font-size: 1.1rem;
        }

        .light-mode .attachment-name {
            color: var(--text-dark);
        }

        .attachment-size {
            color: var(--text-muted);
            font-size: 0.9rem;
            font-weight: 600;
        }

        /* قسم الاختبار */
        .quiz-section {
            background: rgba(0, 255, 136, 0.1);
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            border: 1px solid rgba(0, 255, 136, 0.3);
        }

        .light-mode .quiz-section {
            background: rgba(0, 170, 85, 0.1);
            border: 1px solid rgba(0, 170, 85, 0.3);
        }

        .quiz-section h3 {
            margin-bottom: 1rem;
            color: var(--success);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 1rem;
            font-size: 1.4rem;
            font-weight: 700;
        }

        .quiz-section p {
            color: var(--text-light);
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
            font-weight: 600;
            opacity: 0.9;
        }

        .light-mode .quiz-section p {
            color: var(--text-dark);
        }

        /* الأزرار المحسنة */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
            padding: 1rem 2rem;
            border: none;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
            min-width: 140px;
        }

        .btn-primary {
            background: var(--gradient-primary);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 212, 255, 0.4);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-success:hover {
            background: rgba(0, 255, 136, 0.8);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 255, 136, 0.4);
        }

        .btn-large {
            padding: 1.2rem 2.5rem;
            font-size: 1.1rem;
        }

        /* العد التنازلي */
        .countdown {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-top: 0.5rem;
            font-weight: 600;
        }

        /* صفحة الوصول المرفوض */
        .access-denied-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--bg-light);
            padding: 2rem;
            padding-top: 90px;
        }

        .access-denied-card {
            background: var(--card-light);
            padding: 3rem;
            border-radius: 20px;
            box-shadow: var(--shadow);
            text-align: center;
            max-width: 500px;
            width: 100%;
            border: 1px solid var(--border-light);
        }

        .light-mode .access-denied-card {
            background: var(--card-light);
            border: 1px solid var(--border-light);
        }

        .access-icon {
            font-size: 4rem;
            color: var(--neon);
            margin-bottom: 2rem;
        }

        .light-mode .access-icon {
            color: var(--secondary);
        }

        .access-denied-card h3 {
            margin-bottom: 1.5rem;
            color: var(--text-light);
            font-size: 1.5rem;
            font-weight: 700;
        }

        .light-mode .access-denied-card h3 {
            color: var(--text-dark);
        }

        .access-denied-card p {
            color: var(--text-light);
            margin-bottom: 2rem;
            font-size: 1.1rem;
            font-weight: 600;
            opacity: 0.9;
        }

        .light-mode .access-denied-card p {
            color: var(--text-dark);
        }

        /* تأثيرات تحميل سلسة */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* التجاوب مع الشاشات الصغيرة */
        @media (max-width: 768px) {
            .lecture-container {
                padding: 1rem;
                padding-top: 90px;
            }

            .lecture-header {
                padding: 1.5rem;
            }

            .lecture-header h1 {
                font-size: 1.5rem;
            }

            .lecture-meta {
                flex-direction: column;
                gap: 1rem;
            }

            .meta-item {
                justify-content: center;
            }

            .video-container {
                border-radius: 10px;
            }

            .lecture-info {
                padding: 1.5rem;
            }

            .attachment-item {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .attachment-info {
                justify-content: center;
            }

            .quiz-section {
                padding: 1.5rem;
            }

            .quiz-section h3 {
                font-size: 1.2rem;
            }

            .btn {
                width: 100%;
                margin-bottom: 1rem;
            }

            .views-info {
                flex-direction: column;
                gap: 0.8rem;
                text-align: center;
            }
        }

        @media (max-width: 480px) {
            .lecture-container {
                padding: 0.8rem;
                padding-top: 90px;
            }

            .lecture-header {
                padding: 1.2rem;
            }

            .lecture-header h1 {
                font-size: 1.3rem;
            }

            .lecture-info {
                padding: 1.2rem;
            }

            .access-denied-card {
                padding: 2rem;
            }

            .access-icon {
                font-size: 3rem;
            }
        }
    </style>
</head>
<body>
    <!-- خلفية ثابتة -->
    <div class="cyber-bg">
        <div class="grid-lines"></div>
    </div>

    <div class="lecture-container fade-in">
        <!-- رأس المحاضرة -->
        <div class="lecture-header">
            <h1><?= htmlspecialchars($lecture['title']) ?></h1>
            
            <div class="lecture-meta">
                <div class="meta-item">
                    <i class="fas fa-list"></i>
                    <span>القائمة: <?= htmlspecialchars($lecture['playlist_name']) ?></span>
                </div>
                <div class="meta-item">
                    <i class="fas fa-user-graduate"></i>
                    <span>الصف: <?= get_grade_text($lecture['grade']) ?></span>
                </div>
                <div class="meta-item">
                    <i class="fas fa-tag"></i>
                    <span>النوع: <?= $lecture['is_free'] ? 'مجاني' : 'مدفوع' ?></span>
                </div>
            </div>
            
            <?php if ($user['type'] === 'student' && !$lecture['is_free']): ?>
                <div class="views-info <?= $remaining_views <= 0 ? 'expired' : '' ?>" id="views-info">
                    <i class="fas fa-eye"></i>
                    <span>المشاهدات المتبقية: <strong id="remaining-views"><?= $remaining_views ?></strong> مشاهدة</span>
                    <div class="countdown" id="countdown"></div>
                </div>
            <?php endif; ?>
        </div>

        <!-- حاوية الفيديو -->
        <div class="video-container">
            <div class="video-wrapper">
                <?php if ($lecture['media_type'] === 'bunny'): ?>
                    <div class="responsive-video-container">
                        <iframe src="https://iframe.mediadelivery.net/embed/<?= htmlspecialchars($lecture['bunny_library_id']) ?>/<?= htmlspecialchars($lecture['media_source']) ?>?autoplay=false" 
                                loading="lazy" 
                                allow="accelerometer;gyroscope;autoplay;encrypted-media;picture-in-picture;" 
                                allowfullscreen="true"></iframe>
                    </div>
                <?php elseif ($lecture['media_type'] === 'youtube'): ?>
                    <div class="responsive-video-container">
                        <iframe src="https://www.youtube.com/embed/<?= htmlspecialchars($lecture['media_source']) ?>?rel=0" 
                                allowfullscreen></iframe>
                    </div>
                <?php elseif ($lecture['media_type'] === 'gdrive'): ?>
                    <div class="responsive-video-container">
                        <iframe src="https://drive.google.com/file/d/<?= htmlspecialchars($lecture['media_source']) ?>/preview" 
                                allowfullscreen></iframe>
                    </div>
                <?php elseif ($lecture['media_type'] === 'peertube'): ?>
                    <div class="responsive-video-container">
                        <iframe src="<?= htmlspecialchars($lecture['media_source']) ?>" 
                                allowfullscreen></iframe>
                    </div>
                <?php elseif ($lecture['media_type'] === 'local'): ?>
                    <div class="responsive-video-container">
                        <video controls id="local-video">
                            <source src="<?= htmlspecialchars($lecture['media_source']) ?>" type="video/mp4">
                            متصفحك لا يدعم تشغيل الفيديو.
                        </video>
                    </div>
                <?php elseif ($lecture['media_type'] === 'embed'): ?>
                    <div class="responsive-video-container">
                        <?= $lecture['media_source'] ?>
                    </div>
                <?php else: ?>
                    <div class="video-placeholder">
                        <div style="text-align: center;">
                            <i class="fas fa-exclamation-triangle"></i>
                            <p>نوع الفيديو غير معروف</p>
                            <small>تعذر تحميل محتوى الفيديو. يرجى التواصل مع المسؤول.</small>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- معلومات ووصف المحاضرة -->
        <div class="lecture-info">
            <h2><i class="fas fa-info-circle"></i> وصف المحاضرة</h2>
            <div class="lecture-description">
                <?= nl2br(htmlspecialchars($lecture['description'] ?: 'لا يوجد وصف للمحاضرة')) ?>
            </div>
            
            <?php if (!empty($attachments)): ?>
                <div class="attachments-section">
                    <h3><i class="fas fa-paperclip"></i> المرفقات</h3>
                    <ul class="attachments">
                        <?php foreach ($attachments as $attachment): ?>
                            <li class="attachment-item">
                                <div class="attachment-info">
                                    <div class="attachment-icon">
                                        <i class="fas fa-file-download"></i>
                                    </div>
                                    <div class="attachment-details">
                                        <div class="attachment-name"><?= htmlspecialchars($attachment['file_name']) ?></div>
                                        <div class="attachment-size"><?= round($attachment['file_size'] / 1024, 1) ?> KB</div>
                                    </div>
                                </div>
                                <a href="<?= htmlspecialchars($attachment['file_path']) ?>" target="_blank" class="btn btn-primary" download>
                                    <i class="fas fa-download"></i> تحميل
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>

        <!-- قسم الاختبار -->
        <?php if ($user['type'] === 'student'): ?>
            <div class="quiz-section">
                <?php
                $stmt = $pdo->prepare("SELECT * FROM quizzes WHERE lecture_id = ? AND is_active = 1");
                $stmt->execute([$lecture_id]);
                $quiz = $stmt->fetch();
                
                if ($quiz): ?>
                    <h3><i class="fas fa-edit"></i> اختبر فهمك للمحاضرة</h3>
                    <p>اختبر معلوماتك من خلال حل هذا الاختبار.</p>
                    <a href="take_quiz.php?lecture_id=<?= $lecture_id ?>" class="btn btn-success btn-large">
                        <i class="fas fa-play-circle"></i> بدء الاختبار
                    </a>
                <?php else: ?>
                    <p>لا يوجد اختبار متاح لهذه المحاضرة حالياً.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <!-- أزرار التنقل -->
        <div style="text-align: center; margin-top: 2rem;">
            <a href="<?= $user['type'] === 'admin' ? '/../index.php' : 'index.php' ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-right"></i> العودة إلى القائمة الرئيسية
            </a>
        </div>
    </div>

    <script>
        // متغيرات التحكم في العد
        let viewCounted = false;
        let countdownActive = false;
        let countdownSeconds = 7;
        let countdownInterval;

        // دالة لعرض العد التنازلي
        function startCountdown() {
            if (countdownActive) return;
            
            countdownActive = true;
            const countdownElement = document.getElementById('countdown');
            if (!countdownElement) return;
            
            countdownElement.textContent = `سيتم احتساب مشاهدة بعد ${countdownSeconds} ثانية...`;
            
            countdownInterval = setInterval(() => {
                countdownSeconds--;
                countdownElement.textContent = `سيتم احتساب مشاهدة بعد ${countdownSeconds} ثانية...`;
                
                if (countdownSeconds <= 0) {
                    clearInterval(countdownInterval);
                    countView();
                    countdownElement.textContent = 'تم احتساب المشاهدة';
                }
            }, 1000);
        }

        // دالة لإيقاف العد التنازلي
        function stopCountdown() {
            if (countdownInterval) {
                clearInterval(countdownInterval);
                countdownActive = false;
            }
            const countdownElement = document.getElementById('countdown');
            if (countdownElement) {
                countdownElement.textContent = '';
            }
        }

        // دالة لتسجيل المشاهدة عبر AJAX (مرة واحدة فقط)
        function countView() {
            <?php if ($user['type'] === 'student' && !$lecture['is_free'] && $remaining_views > 0): ?>
            
            if (viewCounted) {
                console.log('تم احتساب المشاهدة مسبقاً');
                return;
            }
            
            viewCounted = true;
            stopCountdown();
            
            fetch('count_view.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    lectureId: <?= $lecture_id ?>,
                    csrf: '<?= generate_csrf_token() ?>'
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // تحديث عدد المشاهدات المتبقية
                    const remainingElement = document.getElementById('remaining-views');
                    const viewsInfo = document.getElementById('views-info');
                    
                    if (remainingElement) {
                        if (data.remaining === 'unlimited') {
                            remainingElement.textContent = 'غير محدود';
                        } else {
                            remainingElement.textContent = data.remaining;
                            
                            // إذا نفذت المشاهدات، تغيير نمط العرض
                            if (data.remaining <= 0) {
                                if (viewsInfo) {
                                    viewsInfo.classList.add('expired');
                                    viewsInfo.innerHTML = '<i class="fas fa-times-circle"></i><span>تم استنفاذ جميع المشاهدات</span>';
                                }
                            }
                        }
                    }
                    
                    console.log('تم احتساب المشاهدة بنجاح');
                } else {
                    console.error('Error counting view:', data.message);
                    viewCounted = false; // السماح بإعادة المحاولة في حالة الخطأ
                }
            })
            .catch(error => {
                console.error('Error:', error);
                viewCounted = false; // السماح بإعادة المحاولة في حالة الخطأ
            });
            <?php else: ?>
            console.log('لا يحتاج إلى احتساب مشاهدة (محاضرة مجانية أو مشاهدات منتهية)');
            <?php endif; ?>
        }

        // دالة للتحقق من تشغيل الفيديو
        function checkVideoPlayback() {
            // للفيديو المحلي
            const localVideo = document.getElementById('local-video');
            if (localVideo) {
                localVideo.addEventListener('play', function() {
                    if (!viewCounted) {
                        startCountdown();
                    }
                });
                
                localVideo.addEventListener('pause', function() {
                    stopCountdown();
                });
            }
            
            // للفيديوهات المضمنة (iframes)
            const iframes = document.querySelectorAll('iframe');
            iframes.forEach(iframe => {
                iframe.addEventListener('load', function() {
                    // بدء العد التنازلي بعد تحميل iframe
                    setTimeout(() => {
                        if (!viewCounted) {
                            startCountdown();
                        }
                    }, 2000);
                });
            });
            
            // بدء العد التنازلي تلقائياً بعد 3 ثوانٍ (للفيديوهات التلقائية)
            setTimeout(() => {
                if (!viewCounted) {
                    startCountdown();
                }
            }, 3000);
        }

        // تهيئة الصفحة عند التحميل
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($user['type'] === 'student' && !$lecture['is_free'] && $remaining_views > 0): ?>
            // بدء التحقق من تشغيل الفيديو
            checkVideoPlayback();
            <?php endif; ?>
            
            // منع إعادة تحميل الصفحة من احتساب مشاهدة جديدة
            window.addEventListener('beforeunload', function() {
                if (viewCounted) {
                    // تم احتساب المشاهدة مسبقاً، لا داعي لفعل anything
                }
            });
        });

        // منع إعادة إرسال النموذج (double submission)
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>