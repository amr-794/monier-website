<?php
$page_title = 'عرض القائمة';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
require_once __DIR__ . '/../includes/functions.php';
$pdo = get_db_connection();

$student_id = $user['id'];
$student_grade = $user['grade'];
$playlist_id = intval($_GET['id'] ?? 0);
if (!$playlist_id) {
    redirect('index.php');
}

// جلب بيانات القائمة
$playlist_stmt = $pdo->prepare("SELECT * FROM playlists WHERE id = ? AND is_active = 1");
$playlist_stmt->execute([$playlist_id]);
$playlist = $playlist_stmt->fetch();
if (!$playlist) {
    redirect('index.php');
}

// جلب صلاحيات وصول الطالب
$access_stmt = $pdo->prepare("SELECT lecture_id, remaining_views FROM student_lecture_access WHERE student_id = ?");
$access_stmt->execute([$student_id]);
$my_lectures_access = $access_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// جلب محاضرات القائمة للصف الدراسي الحالي
$lectures_stmt = $pdo->prepare("SELECT * FROM lectures WHERE playlist_id = ? AND (grade = ? OR grade = 'all') AND is_active = 1 ORDER BY id ASC");
$lectures_stmt->execute([$playlist_id, $student_grade]);
$lectures = $lectures_stmt->fetchAll();
?>

<div class="playlist-container">
    <div class="playlist-header">
        <div class="header-content">
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-right"></i>
                العودة للقوائم
            </a>
            <div class="playlist-info">
                <h1><?= htmlspecialchars($playlist['name']) ?></h1>
                <p class="playlist-description"><?= htmlspecialchars($playlist['description'] ?? '') ?></p>
                <div class="playlist-meta">
                    <span class="meta-item">
                        <i class="fas fa-play-circle"></i>
                        <?= count($lectures) ?> محاضرة
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="lectures-grid">
        <?php if(empty($lectures)): ?>
            <div class="empty-state">
                <i class="fas fa-video-slash"></i>
                <h3>لا توجد محاضرات متاحة</h3>
                <p>لا توجد محاضرات متاحة في هذه القائمة حالياً.</p>
            </div>
        <?php else: ?>
            <?php foreach ($lectures as $index => $lecture): ?>
            <div class="lecture-card">
                <div class="lecture-thumbnail">
                    <img src="../<?= htmlspecialchars($lecture['thumbnail_path'] ?? 'assets/images/default-thumb.png') ?>" 
                         alt="<?= htmlspecialchars($lecture['title']) ?>"
                         class="thumbnail-img">
                    <div class="lecture-overlay">
                        <div class="lecture-number"><?= $index + 1 ?></div>
                        <div class="play-icon">
                            <i class="fas fa-play"></i>
                        </div>
                    </div>
                    <?php if(!$lecture['is_free']): ?>
                        <div class="premium-badge">
                            <i class="fas fa-crown"></i>
                            مدفوعة
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="lecture-content">
                    <h3 class="lecture-title"><?= htmlspecialchars($lecture['title']) ?></h3>
                    <p class="lecture-description"><?= htmlspecialchars(mb_substr($lecture['description'] ?? '', 0, 120)) ?>...</p>
                    
                    <div class="lecture-meta">
                        <span class="grade-badge">
                            <i class="fas fa-user-graduate"></i>
                            <?= get_grade_text($lecture['grade']) ?>
                        </span>
                        <?php if($lecture['is_free']): ?>
                            <span class="free-badge">
                                <i class="fas fa-unlock"></i>
                                مجانية
                            </span>
                        <?php else: ?>
                            <span class="price-badge">
                                <i class="fas fa-tag"></i>
                                <?= (float)$lecture['price'] ?> جنيه
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="lecture-actions">
                        <?php if ($lecture['is_free']): ?>
                            <a href="view_lecture.php?id=<?= $lecture['id'] ?>" class="btn watch-btn">
                                <i class="fas fa-play"></i>
                                مشاهدة المحاضرة
                            </a>
                        <?php elseif (isset($my_lectures_access[$lecture['id']]) && $my_lectures_access[$lecture['id']] > 0): ?>
                            <a href="view_lecture.php?id=<?= $lecture['id'] ?>" class="btn watch-btn has-access">
                                <i class="fas fa-play"></i>
                                مشاهدة (<?= $my_lectures_access[$lecture['id']] ?> متبقي)
                            </a>
                        <?php elseif (isset($my_lectures_access[$lecture['id']])): ?>
                            <a href="activate_lecture.php?lecture_id=<?= $lecture['id'] ?>" class="btn renew-btn">
                                <i class="fas fa-sync"></i>
                                تجديد الكود
                            </a>
                        <?php else: ?>
                            <a href="activate_lecture.php?lecture_id=<?= $lecture['id'] ?>" class="btn activate-btn">
                                <i class="fas fa-key"></i>
                                تفعيل المحاضرة
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<style>
:root {
    --primary-color: #667eea;
    --primary-dark: #5a6fd8;
    --secondary-color: #764ba2;
    --success-color: #28a745;
    --warning-color: #ffc107;
    --danger-color: #dc3545;
    --light-bg: #f8f9fa;
    --dark-text: #333;
    --gray-text: #666;
    --border-color: #e9ecef;
    --card-shadow: 0 4px 15px rgba(0,0,0,0.1);
    --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
}

.playlist-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 1rem;
    animation: fadeInUp 0.8s ease-out;
    min-height: calc(100vh - 200px);
}

/* هيدر القائمة */
.playlist-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    border-radius: 20px;
    margin-top: 2rem;
    margin-bottom: 2rem;
    overflow: hidden;
    box-shadow: var(--card-shadow);
}

.header-content {
    padding: 2rem;
    position: relative;
}

.back-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    color: white;
    text-decoration: none;
    padding: 0.8rem 1.5rem;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 25px;
    transition: var(--transition);
    margin-bottom: 1.5rem;
    font-weight: 600;
    font-size: 0.9rem;
}

.back-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateX(-5px);
}

.playlist-info h1 {
    font-size: 2rem;
    margin-bottom: 1rem;
    font-weight: 700;
}

.playlist-description {
    font-size: 1.1rem;
    opacity: 0.9;
    margin-bottom: 1.5rem;
    line-height: 1.6;
    font-weight: 600;
}

.playlist-meta {
    display: flex;
    gap: 1.5rem;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background: rgba(255, 255, 255, 0.2);
    padding: 0.6rem 1.2rem;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.9rem;
}

/* شبكة المحاضرات */
.lectures-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.lecture-card {
    background: var(--card-light);
    border-radius: 15px;
    overflow: hidden;
    box-shadow: var(--shadow);
    transition: var(--transition);
    border: 1px solid var(--border-light);
}

.light-mode .lecture-card {
    background: var(--card-light);
    border: 1px solid var(--border-light);
    box-shadow: var(--shadow);
}

.lecture-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0, 212, 255, 0.2);
}

.light-mode .lecture-card:hover {
    box-shadow: 0 10px 25px rgba(0, 102, 204, 0.2);
}

/* الصورة المصغرة */
.lecture-thumbnail {
    position: relative;
    height: 180px;
    overflow: hidden;
}

.thumbnail-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.lecture-card:hover .thumbnail-img {
    transform: scale(1.05);
}

.lecture-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(0,0,0,0.4), transparent);
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    padding: 1rem;
}

.lecture-number {
    background: rgba(255, 255, 255, 0.9);
    color: var(--dark-text);
    width: 35px;
    height: 35px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1rem;
    box-shadow: var(--shadow-sm);
}

.play-icon {
    background: var(--primary-color);
    color: white;
    width: 45px;
    height: 45px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.1rem;
    box-shadow: var(--shadow-sm);
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.lecture-card:hover .play-icon {
    transform: scale(1);
}

.premium-badge {
    position: absolute;
    top: 1rem;
    left: 1rem;
    background: linear-gradient(45deg, #ffd700, #ffed4e);
    color: #856404;
    padding: 0.4rem 0.8rem;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 0.3rem;
    box-shadow: var(--shadow-sm);
}

/* محتوى المحاضرة */
.lecture-content {
    padding: 1.5rem;
}

.lecture-title {
    font-size: 1.2rem;
    font-weight: 700;
    margin-bottom: 0.8rem;
    color: var(--text-light);
    line-height: 1.4;
}

.light-mode .lecture-title {
    color: var(--text-dark);
}

.lecture-description {
    color: var(--text-light);
    font-size: 0.9rem;
    line-height: 1.5;
    margin-bottom: 1.2rem;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    opacity: 0.9;
    font-weight: 600;
}

.light-mode .lecture-description {
    color: var(--text-dark);
}

.lecture-meta {
    display: flex;
    gap: 0.8rem;
    margin-bottom: 1.2rem;
    flex-wrap: wrap;
}

.grade-badge,
.free-badge,
.price-badge {
    display: flex;
    align-items: center;
    gap: 0.3rem;
    padding: 0.4rem 0.8rem;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: 700;
}

.grade-badge {
    background: rgba(0, 212, 255, 0.1);
    color: var(--secondary);
    border: 1px solid rgba(0, 212, 255, 0.3);
}

.free-badge {
    background: rgba(0, 255, 136, 0.1);
    color: var(--success);
    border: 1px solid rgba(0, 255, 136, 0.3);
}

.price-badge {
    background: rgba(255, 193, 7, 0.1);
    color: var(--warning-color);
    border: 1px solid rgba(255, 193, 7, 0.3);
}

/* أزرار المشاهدة */
.lecture-actions .btn {
    width: 100%;
    padding: 0.8rem 1.2rem;
    border: none;
    border-radius: 10px;
    font-weight: 700;
    text-decoration: none;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    transition: var(--transition);
    font-size: 0.9rem;
}

.watch-btn {
    background: var(--primary-color);
    color: white;
}

.watch-btn:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}

.has-access {
    background: var(--success);
}

.has-access:hover {
    background: rgba(0, 255, 136, 0.8);
}

.renew-btn {
    background: var(--warning-color);
    color: var(--dark-text);
}

.renew-btn:hover {
    background: #e0a800;
    transform: translateY(-2px);
}

.activate-btn {
    background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
    color: white;
}

.activate-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

/* حالة فارغة */
.empty-state {
    grid-column: 1 / -1;
    text-align: center;
    padding: 3rem 1rem;
    color: var(--text-light);
}

.light-mode .empty-state {
    color: var(--text-dark);
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
    color: var(--neon);
}

.light-mode .empty-state i {
    color: var(--secondary);
}

.empty-state h3 {
    font-size: 1.3rem;
    margin-bottom: 0.5rem;
    color: var(--text-light);
    font-weight: 700;
}

.light-mode .empty-state h3 {
    color: var(--text-dark);
}

.empty-state p {
    font-size: 1rem;
    opacity: 0.8;
    font-weight: 600;
}

/* تأثيرات الدخول */
.lecture-card {
    animation: fadeInUp 0.6s ease;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* تنسيق متدرج للبطاقات */
.lecture-card:nth-child(2n) {
    animation-delay: 0.1s;
}

.lecture-card:nth-child(3n) {
    animation-delay: 0.2s;
}

/* التجاوب مع الشاشات الصغيرة */
@media (max-width: 768px) {
    .playlist-container {
        padding: 0.8rem;
    }
    
    .header-content {
        padding: 1.5rem;
    }
    
    .playlist-info h1 {
        font-size: 1.6rem;
    }
    
    .lectures-grid {
        grid-template-columns: 1fr;
        gap: 1.2rem;
    }
    
    .lecture-thumbnail {
        height: 160px;
    }
    
    .lecture-content {
        padding: 1.2rem;
    }
    
    .playlist-meta {
        flex-direction: column;
        gap: 0.8rem;
    }
}

@media (max-width: 480px) {
    .playlist-container {
        padding: 0.5rem;
    }
    
    .header-content {
        padding: 1.2rem;
    }
    
    .playlist-info h1 {
        font-size: 1.4rem;
    }
    
    .lecture-thumbnail {
        height: 140px;
    }
    
    .lecture-content {
        padding: 1rem;
    }
    
    .lecture-title {
        font-size: 1.1rem;
    }
    
    .lecture-meta {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .back-btn {
        font-size: 0.85rem;
        padding: 0.6rem 1rem;
    }
}
</style>

<?php include 'partials/footer.php'; ?>