<?php
// إعدادات الاتصال بقاعدة البيانات
define('DB_HOST', 'locasql109.infinityfree.com');
define('DB_NAME', 'if0_40385629_monier1');
define('DB_USER', 'if0_40385629');
define('DB_PASS', 'amr11318');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الموقع
define('SITE_URL', 'https://mahmoud-monier.free.nf');
define('SITE_NAME', 'منصة منير');

// إعدادات أخرى
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
?>