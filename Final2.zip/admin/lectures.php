<?php
$page_title = 'إدارة المحاضرات';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
$pdo = get_db_connection();

// معالجة حذف مرفق
if(isset($_GET['delete_attachment'])){
    $att_id = intval($_GET['delete_attachment']);
    $edit_lecture_id = intval($_GET['edit']);
    
    $stmt = $pdo->prepare("DELETE FROM lecture_attachments WHERE id = ?");
    $stmt->execute([$att_id]);
    echo "<div class='alert alert-success'>تم حذف المرفق. جاري تحديث الصفحة...</div>";
    echo "<meta http-equiv='refresh' content='2;url=lectures.php?edit={$edit_lecture_id}'>";
}

// معالجة تفعيل/تعطيل المحاضرة
if(isset($_GET['toggle_status'])){
    $id = intval($_GET['toggle_status']);
    $stmt = $pdo->prepare("UPDATE lectures SET is_active = NOT is_active WHERE id = ?");
    $stmt->execute([$id]);
    echo "<div class='alert alert-success'>تم تغيير حالة المحاضرة. جاري تحديث الصفحة...</div>";
    echo "<meta http-equiv='refresh' content='2;url=lectures.php'>";
}

// معالجة إضافة وتعديل المحاضرات
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_lecture'])) {
    $lecture_id = intval($_POST['lecture_id'] ?? 0);
    $title = sanitize_input($_POST['title']);
    $description = sanitize_input($_POST['description']);
    $playlist_id = intval($_POST['playlist_id']);
    $price = floatval($_POST['price']);
    $is_free = isset($_POST['is_free']) ? 1 : 0;
    $grade = sanitize_input($_POST['grade']);
    $max_views = intval($_POST['max_views']);
    $media_type = sanitize_input($_POST['media_type']);
    $bunny_library_id = sanitize_input($_POST['bunny_library_id'] ?? null);
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    // --- *** START OF FIX: تحديد مصدر الوسائط بناءً على النوع *** ---
    $media_source = '';
    
    if ($media_type === 'bunny') {
        $media_source = sanitize_input($_POST['bunny_video_id'] ?? '');
    } elseif (in_array($media_type, ['youtube', 'gdrive', 'peertube'])) {
        $media_source = sanitize_input($_POST['link_source'] ?? '');
    } elseif ($media_type === 'local') {
        // معالجة رفع ملف محلي
        if (isset($_FILES['local_video']) && $_FILES['local_video']['error'] == 0) {
            $target_dir = __DIR__ . "/../uploads/videos/";
            if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
            $video_name = uniqid() . '-' . basename($_FILES["local_video"]["name"]);
            $media_source = "uploads/videos/" . $video_name;
            move_uploaded_file($_FILES["local_video"]["tmp_name"], __DIR__ . "/../" . $media_source);
        } else {
            $media_source = $_POST['current_video'] ?? '';
        }
    } elseif ($media_type === 'embed') {
        // Use the specific lenient sanitizer for embed codes
        $media_source = sanitize_embed_content($_POST['embed_code'] ?? '');
    }
    // --- *** END OF FIX *** ---

    if ($is_free) {
        $price = 0.00;
        $max_views = 9999;
    }

    
    $thumbnail_path = $_POST['current_thumbnail'] ?? null;
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        $target_dir = __DIR__ . "/../uploads/thumbnails/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
        $thumbnail_name = uniqid() . '-' . basename($_FILES["thumbnail"]["name"]);
        $thumbnail_path = "uploads/thumbnails/" . $thumbnail_name;
        move_uploaded_file($_FILES["thumbnail"]["tmp_name"], __DIR__ . "/../" . $thumbnail_path);
    }
    
    if ($lecture_id > 0) { // تحديث
        $sql = "UPDATE lectures SET title=?, description=?, playlist_id=?, price=?, is_free=?, grade=?, max_views=?, media_type=?, media_source=?, bunny_library_id=?, thumbnail_path=?, is_active=? WHERE id=?";
        $params = [$title, $description, $playlist_id, $price, $is_free, $grade, $max_views, $media_type, $media_source, $bunny_library_id, $thumbnail_path, $is_active, $lecture_id];
    } else { // إضافة
        $sql = "INSERT INTO lectures (title, description, playlist_id, price, is_free, grade, max_views, media_type, media_source, bunny_library_id, thumbnail_path, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $params = [$title, $description, $playlist_id, $price, $is_free, $grade, $max_views, $media_type, $media_source, $bunny_library_id, $thumbnail_path, $is_active];
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $saved_lecture_id = $lecture_id > 0 ? $lecture_id : $pdo->lastInsertId();
    
    // حفظ المرفقات
    if (isset($_POST['attachment_links'])) {
        foreach ($_POST['attachment_links'] as $link) {
            if (!empty(trim($link))) {
                $att_stmt = $pdo->prepare("INSERT INTO lecture_attachments (lecture_id, file_path, file_name) VALUES (?, ?, ?)");
                $att_stmt->execute([$saved_lecture_id, $link, basename($link)]);
            }
        }
    }
    
    echo "<div class='alert alert-success'>تم حفظ المحاضرة بنجاح.</div>";
    
    // إذا كان التحديث من نافذة التعديل، إعادة التوجيه لإغلاق النافذة
    if ($lecture_id > 0 && isset($_POST['from_modal'])) {
        echo "<script>window.opener.location.reload(); window.close();</script>";
        exit;
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // You should also delete the associated files here (thumbnail)
    $stmt = $pdo->prepare("DELETE FROM lectures WHERE id = ?");
    $stmt->execute([$id]);
}


// جلب بيانات المحاضرة للتعديل
$edit_lecture = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM lectures WHERE id = ?");
    $stmt->execute([$id]);
    $edit_lecture = $stmt->fetch();
}

// جلب كل المحاضرات وقوائم التشغيل
// --- *** FIX STARTS HERE *** ---
// The `l.created_at` column was removed. Sorting by title or id.
$lectures = $pdo->query("SELECT l.*, p.name as playlist_name FROM lectures l JOIN playlists p ON l.playlist_id = p.id ORDER BY l.id DESC")->fetchAll();
// --- *** FIX ENDS HERE *** ---
$playlists = $pdo->query("SELECT id, name FROM playlists WHERE is_active = 1 ORDER BY name ASC")->fetchAll();
?>

<div class="form-container">
    <h2>إضافة محاضرة جديدة</h2>
    <form action="lectures.php" method="post" enctype="multipart/form-data">
        <div class="form-grid">
            <div class="form-group">
                <label for="title">عنوان المحاضرة:</label>
                <input type="text" id="title" name="title" value="" required>
            </div>

            <div class="form-group">
                <label for="playlist_id">قائمة التشغيل:</label>
                <select id="playlist_id" name="playlist_id" required>
                    <option value="">-- اختر قائمة --</option>
                    <?php foreach ($playlists as $playlist): ?>
                        <option value="<?= $playlist['id'] ?>"><?= htmlspecialchars($playlist['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="grade">الصف الدراسي:</label>
                <select id="grade" name="grade" required>
                    <option value="first_secondary">الأول الثانوي</option>
                    <option value="second_secondary">الثاني الثانوي</option>
                    <option value="third_secondary">الثالث الثانوي</option>
                </select>
            </div>

            <div class="form-group">
                <label>
                    <input type="checkbox" name="is_free" id="is_free" value="1" onchange="togglePriceField()">
                    محاضرة مجانية
                </label>
            </div>

            <div class="form-group" id="price_field">
                <label for="price">سعر المحاضرة:</label>
                <input type="number" step="0.01" id="price" name="price" value="0.00">
            </div>

            <div class="form-group" id="max_views_field">
                <label for="max_views">عدد المشاهدات المسموح بها:</label>
                <input type="number" id="max_views" name="max_views" value="3">
            </div>

            <div class="form-group">
                <label>
                    <input type="checkbox" name="is_active" value="1" checked>
                    محاضرة مفعلة
                </label>
            </div>
        </div>

        <div class="form-group">
            <label for="description">وصف المحاضرة:</label>
            <textarea id="description" name="description" rows="4"></textarea>
        </div>

        <div class="form-group">
            <label for="thumbnail">صورة مصغرة:</label>
            <input type="file" id="thumbnail" name="thumbnail" accept="image/*">
        </div>

        <hr>

        <div class="form-group">
            <label for="media_type">مصدر الفيديو:</label>
            <select id="media_type" name="media_type" onchange="toggleMediaFields()" required>
                <option value="">-- اختر المصدر --</option>
                <option value="bunny">Bunny Stream</option>
                <option value="youtube">YouTube</option>
                <option value="gdrive">Google Drive</option>
                <option value="peertube">PeerTube</option>
                <option value="local">رفع ملف من الجهاز</option>
                <option value="embed">تضمين (Embed)</option>
            </select>
        </div>

        <!-- حقول Bunny Stream -->
        <div id="bunny_fields" class="media-fields">
            <div class="form-grid">
                <div class="form-group">
                    <label for="bunny_library_id">رقم المكتبة (Library ID):</label>
                    <input type="text" id="bunny_library_id" name="bunny_library_id" value="">
                </div>
                <div class="form-group">
                    <label for="bunny_video_id">معرف الفيديو (Video ID):</label>
                    <input type="text" id="bunny_video_id" name="bunny_video_id" value="">
                </div>
            </div>
            <div class="preview-container" id="bunny_preview"></div>
        </div>

        <!-- حقول YouTube و Google Drive و PeerTube -->
        <div id="link_fields" class="media-fields">
            <div class="form-group">
                <label for="link_source">رابط الفيديو:</label>
                <input type="text" id="link_source" name="link_source" placeholder="https://..." value="">
            </div>
            <div class="preview-container" id="link_preview"></div>
        </div>

        <!-- حقول رفع ملف محلي -->
        <div id="local_fields" class="media-fields">
            <div class="form-group">
                <label for="local_video">اختر ملف فيديو:</label>
                <input type="file" id="local_video" name="local_video" accept="video/*">
            </div>
            <div class="preview-container" id="local_preview">
                <p>سيظهر معاينة الفيديو هنا بعد الرفع</p>
            </div>
        </div>

        <!-- حقول التضمين -->
        <div id="embed_fields" class="media-fields">
            <div class="form-group">
                <label for="embed_code">كود التضمين الكامل:</label>
                <textarea id="embed_code" name="embed_code" rows="8" placeholder='&lt;div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"&gt;...&lt;/div&gt;'></textarea>
                <small>قم بلصق كود التضمين الكامل بما في ذلك علامات &lt;script&gt; إذا كانت موجودة</small>
            </div>
            <div class="preview-container" id="embed_preview">
                <p>سيظهر معاينة التضمين هنا بعد الحفظ</p>
            </div>
        </div>

        <hr>

        <div class="form-group">
            <label>إضافة مرفقات (روابط):</label>
            <div id="attachment_links">
                <div class="attachment-link">
                    <input type="text" name="attachment_links[]" placeholder="رابط المرفق (PDF, صورة, إلخ)">
                    <button type="button" class="btn btn-danger btn-sm" onclick="removeAttachmentLink(this)">حذف</button>
                </div>
            </div>
            <button type="button" class="btn btn-secondary btn-sm" onclick="addAttachmentLink()">+ إضافة رابط آخر</button>
        </div>

        <div class="form-actions">
            <button type="submit" name="save_lecture" class="btn btn-primary">إضافة المحاضرة</button>
        </div>
    </form>
</div>

<div class="table-container">
    <h2>المحاضرات المضافة</h2>
    
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>العنوان</th>
                    <th>القائمة</th>
                    <th>الصف</th>
                    <th>النوع</th>
                    <th>الحالة</th>
                    <th>مصدر الفيديو</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($lectures)): ?>
                    <tr>
                        <td colspan="8" class="text-center">لا توجد محاضرات.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($lectures as $index => $lecture): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($lecture['title']) ?></td>
                            <td><?= htmlspecialchars($lecture['playlist_name']) ?></td>
                            <td><?= get_grade_text($lecture['grade']) ?></td>
                            <td>
                                <span class="badge <?= $lecture['is_free'] ? 'badge-success' : 'badge-warning' ?>">
                                    <?= $lecture['is_free'] ? 'مجانية' : 'مدفوعة' ?>
                                </span>
                            </td>
                            <td>
                                <span class="status-badge status-<?= $lecture['is_active'] ? 'active' : 'inactive' ?>">
                                    <?= $lecture['is_active'] ? 'مفعلة' : 'معطلة' ?>
                                </span>
                            </td>
                            <td><?= htmlspecialchars($lecture['media_type']) ?></td>
                            <td class="actions">
                                <button onclick="openEditModal(<?= $lecture['id'] ?>)" class="btn btn-sm btn-primary">تعديل</button>
                                <a href="lectures.php?toggle_status=<?= $lecture['id'] ?>" class="btn btn-sm <?= $lecture['is_active'] ? 'btn-warning' : 'btn-success' ?>" onclick="return confirm('هل أنت متأكد من <?= $lecture['is_active'] ? 'تعطيل' : 'تفعيل' ?> هذه المحاضرة؟')">
                                    <?= $lecture['is_active'] ? 'تعطيل' : 'تفعيل' ?>
                                </a>
                                <a href="lectures.php?delete=<?= $lecture['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من حذف هذه المحاضرة؟')">حذف</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- نافذة التعديل -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>تعديل المحاضرة</h2>
            <span class="close" onclick="closeEditModal()">&times;</span>
        </div>
        <div class="modal-body" id="editModalBody">
            <!-- سيتم تحميل محتوى التعديل هنا -->
        </div>
    </div>
</div>

<script>
function togglePriceField() {
    const isFree = document.getElementById('is_free').checked;
    const priceField = document.getElementById('price_field');
    const maxViewsField = document.getElementById('max_views_field');
    
    if (isFree) {
        priceField.style.display = 'none';
        maxViewsField.style.display = 'none';
        document.getElementById('price').value = '0';
        document.getElementById('max_views').value = '9999';
    } else {
        priceField.style.display = 'block';
        maxViewsField.style.display = 'block';
        document.getElementById('max_views').value = '3';
    }
}

function toggleMediaFields() {
    const mediaType = document.getElementById('media_type').value;
    document.querySelectorAll('.media-fields').forEach(field => {
        field.style.display = 'none';
        field.querySelector('.preview-container').innerHTML = '<p>جاري تحميل المعاينة...</p>';
    });
    
    if (mediaType === 'bunny') {
        document.getElementById('bunny_fields').style.display = 'block';
        updateBunnyPreview();
    } else if (['youtube', 'gdrive', 'peertube'].includes(mediaType)) {
        document.getElementById('link_fields').style.display = 'block';
        updateLinkPreview();
    } else if (mediaType === 'local') {
        document.getElementById('local_fields').style.display = 'block';
        updateLocalPreview();
    } else if (mediaType === 'embed') {
        document.getElementById('embed_fields').style.display = 'block';
        updateEmbedPreview();
    }
}

function updateBunnyPreview() {
    const libraryId = document.getElementById('bunny_library_id').value;
    const videoId = document.getElementById('bunny_video_id').value;
    const preview = document.getElementById('bunny_preview');
    
    if (libraryId && videoId) {
        preview.innerHTML = `
            <h4>معاينة Bunny Stream:</h4>
            <div style="position:relative;padding-top:56.25%;">
                <iframe src="https://iframe.mediadelivery.net/embed/${libraryId}/${videoId}?autoplay=false" 
                        loading="lazy" 
                        style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                        allow="accelerometer;gyroscope;autoplay;encrypted-media;picture-in-picture;" 
                        allowfullscreen="true"></iframe>
            </div>
        `;
    } else {
        preview.innerHTML = '<p>أدخل بيانات Bunny Stream لعرض المعاينة</p>';
    }
}

function updateLinkPreview() {
    const link = document.getElementById('link_source').value;
    const preview = document.getElementById('link_preview');
    const mediaType = document.getElementById('media_type').value;
    
    if (link) {
        if (mediaType === 'youtube') {
            const videoId = extractYouTubeId(link);
            if (videoId) {
                preview.innerHTML = `
                    <h4>معاينة YouTube:</h4>
                    <div style="position:relative;padding-top:56.25%;">
                        <iframe src="https://www.youtube.com/embed/${videoId}?rel=0" 
                                style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                allowfullscreen></iframe>
                    </div>
                `;
            } else {
                preview.innerHTML = '<p style="color:red;">رابط YouTube غير صالح</p>';
            }
        } else if (mediaType === 'gdrive') {
            const fileId = extractGoogleDriveId(link);
            if (fileId) {
                preview.innerHTML = `
                    <h4>معاينة Google Drive:</h4>
                    <div style="position:relative;padding-top:56.25%;">
                        <iframe src="https://drive.google.com/file/d/${fileId}/preview" 
                                style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                allowfullscreen></iframe>
                    </div>
                `;
            } else {
                preview.innerHTML = '<p style="color:red;">رابط Google Drive غير صالح</p>';
            }
        } else if (mediaType === 'peertube') {
            preview.innerHTML = `
                <h4>معاينة PeerTube:</h4>
                <div style="position:relative;padding-top:56.25%;">
                    <iframe src="${link}" 
                            style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                            allowfullscreen></iframe>
                </div>
            `;
        }
    } else {
        preview.innerHTML = '<p>أدخل الرابط لعرض المعاينة</p>';
    }
}

function updateLocalPreview() {
    const fileInput = document.getElementById('local_video');
    const preview = document.getElementById('local_preview');
    
    if (fileInput.files && fileInput.files[0]) {
        const file = fileInput.files[0];
        const url = URL.createObjectURL(file);
        preview.innerHTML = `
            <h4>معاينة الفيديو المحلي:</h4>
            <video controls width="100%" style="max-width: 600px;">
                <source src="${url}" type="${file.type}">
                متصفحك لا يدعم تشغيل الفيديو.
            </video>
            <p>اسم الملف: ${file.name}</p>
            <p>الحجم: ${(file.size / (1024 * 1024)).toFixed(2)} MB</p>
        `;
    } else {
        preview.innerHTML = '<p>اختر ملف فيديو لعرض المعاينة</p>';
    }
}

function updateEmbedPreview() {
    const embedCode = document.getElementById('embed_code').value;
    const preview = document.getElementById('embed_preview');
    
    if (embedCode.trim()) {
        preview.innerHTML = `
            <h4>معاينة التضمين:</h4>
            <div class="embed-preview-wrapper">
                ${embedCode}
            </div>
        `;
    } else {
        preview.innerHTML = '<p>أدخل كود التضمين لعرض المعاينة</p>';
    }
}

// دوال مساعدة لاستخراج المعرفات
function extractYouTubeId(url) {
    const regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[7].length === 11) ? match[7] : false;
}

function extractGoogleDriveId(url) {
    const match = url.match(/\/d\/([^\/]+)/);
    return match ? match[1] : false;
}

// إضافة event listeners للحقول
document.addEventListener('DOMContentLoaded', function() {
    // تهيئة الحقول
    togglePriceField();
    toggleMediaFields();
    
    // إضافة event listeners للتحديث التلقائي للمعاينة
    document.getElementById('bunny_library_id').addEventListener('input', updateBunnyPreview);
    document.getElementById('bunny_video_id').addEventListener('input', updateBunnyPreview);
    document.getElementById('link_source').addEventListener('input', updateLinkPreview);
    document.getElementById('local_video').addEventListener('change', updateLocalPreview);
    document.getElementById('embed_code').addEventListener('input', updateEmbedPreview);
});

function addAttachmentLink() {
    const container = document.getElementById('attachment_links');
    const newLink = document.createElement('div');
    newLink.className = 'attachment-link';
    newLink.innerHTML = `
        <input type="text" name="attachment_links[]" placeholder="رابط المرفق (PDF, صورة, إلخ)">
        <button type="button" class="btn btn-danger btn-sm" onclick="removeAttachmentLink(this)">حذف</button>
    `;
    container.appendChild(newLink);
}

function removeAttachmentLink(button) {
    button.parentElement.remove();
}

// دوال نافذة التعديل
function openEditModal(lectureId) {
    const modal = document.getElementById('editModal');
    const modalBody = document.getElementById('editModalBody');
    
    // عرض مؤشر التحميل
    modalBody.innerHTML = '<div class="loading">جاري تحميل البيانات...</div>';
    modal.style.display = 'block';
    
    // جلب بيانات المحاضرة عبر AJAX
    fetch(`lectures_edit.php?edit=${lectureId}`)
        .then(response => response.text())
        .then(data => {
            modalBody.innerHTML = data;
            // تهيئة الحقول بعد تحميل النموذج
            initEditForm();
        })
        .catch(error => {
            modalBody.innerHTML = '<div class="alert alert-danger">حدث خطأ في تحميل البيانات</div>';
        });
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

function initEditForm() {
    // تهيئة جميع الحقول في نموذج التعديل
    const editForm = document.querySelector('#editModalBody form');
    if (editForm) {
        // تهيئة حقل السعر
        const isFreeCheckbox = editForm.querySelector('#edit_is_free');
        if (isFreeCheckbox) {
            isFreeCheckbox.addEventListener('change', function() {
                toggleEditPriceField();
            });
            toggleEditPriceField();
        }
        
        // تهيئة حقول الوسائط
        const mediaTypeSelect = editForm.querySelector('#edit_media_type');
        if (mediaTypeSelect) {
            mediaTypeSelect.addEventListener('change', function() {
                toggleEditMediaFields();
            });
            toggleEditMediaFields();
        }
        
        // إضافة event listeners للمعاينة
        const bunnyLibraryId = editForm.querySelector('#edit_bunny_library_id');
        const bunnyVideoId = editForm.querySelector('#edit_bunny_video_id');
        const linkSource = editForm.querySelector('#edit_link_source');
        const localVideo = editForm.querySelector('#edit_local_video');
        const embedCode = editForm.querySelector('#edit_embed_code');
        
        if (bunnyLibraryId) bunnyLibraryId.addEventListener('input', updateEditBunnyPreview);
        if (bunnyVideoId) bunnyVideoId.addEventListener('input', updateEditBunnyPreview);
        if (linkSource) linkSource.addEventListener('input', updateEditLinkPreview);
        if (localVideo) localVideo.addEventListener('change', updateEditLocalPreview);
        if (embedCode) embedCode.addEventListener('input', updateEditEmbedPreview);
    }
}

function toggleEditPriceField() {
    const editForm = document.querySelector('#editModalBody form');
    if (!editForm) return;
    
    const isFree = editForm.querySelector('#edit_is_free').checked;
    const priceField = editForm.querySelector('#edit_price_field');
    const maxViewsField = editForm.querySelector('#edit_max_views_field');
    
    if (isFree) {
        priceField.style.display = 'none';
        maxViewsField.style.display = 'none';
        editForm.querySelector('#edit_price').value = '0';
        editForm.querySelector('#edit_max_views').value = '9999';
    } else {
        priceField.style.display = 'block';
        maxViewsField.style.display = 'block';
    }
}

function toggleEditMediaFields() {
    const editForm = document.querySelector('#editModalBody form');
    if (!editForm) return;
    
    const mediaType = editForm.querySelector('#edit_media_type').value;
    editForm.querySelectorAll('.edit-media-fields').forEach(field => {
        field.style.display = 'none';
    });
    
    if (mediaType === 'bunny') {
        editForm.querySelector('#edit_bunny_fields').style.display = 'block';
        updateEditBunnyPreview();
    } else if (['youtube', 'gdrive', 'peertube'].includes(mediaType)) {
        editForm.querySelector('#edit_link_fields').style.display = 'block';
        updateEditLinkPreview();
    } else if (mediaType === 'local') {
        editForm.querySelector('#edit_local_fields').style.display = 'block';
        updateEditLocalPreview();
    } else if (mediaType === 'embed') {
        editForm.querySelector('#edit_embed_fields').style.display = 'block';
        updateEditEmbedPreview();
    }
}

// دوال المعاينة لنموذج التعديل
function updateEditBunnyPreview() {
    const editForm = document.querySelector('#editModalBody form');
    if (!editForm) return;
    
    const libraryId = editForm.querySelector('#edit_bunny_library_id').value;
    const videoId = editForm.querySelector('#edit_bunny_video_id').value;
    const preview = editForm.querySelector('#edit_bunny_preview');
    
    if (libraryId && videoId && preview) {
        preview.innerHTML = `
            <h4>معاينة Bunny Stream:</h4>
            <div style="position:relative;padding-top:56.25%;">
                <iframe src="https://iframe.mediadelivery.net/embed/${libraryId}/${videoId}?autoplay=false" 
                        loading="lazy" 
                        style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                        allow="accelerometer;gyroscope;autoplay;encrypted-media;picture-in-picture;" 
                        allowfullscreen="true"></iframe>
            </div>
        `;
    } else if (preview) {
        preview.innerHTML = '<p>أدخل بيانات Bunny Stream لعرض المعاينة</p>';
    }
}

function updateEditLinkPreview() {
    const editForm = document.querySelector('#editModalBody form');
    if (!editForm) return;
    
    const link = editForm.querySelector('#edit_link_source').value;
    const preview = editForm.querySelector('#edit_link_preview');
    const mediaType = editForm.querySelector('#edit_media_type').value;
    
    if (link && preview) {
        if (mediaType === 'youtube') {
            const videoId = extractYouTubeId(link);
            if (videoId) {
                preview.innerHTML = `
                    <h4>معاينة YouTube:</h4>
                    <div style="position:relative;padding-top:56.25%;">
                        <iframe src="https://www.youtube.com/embed/${videoId}?rel=0" 
                                style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                allowfullscreen></iframe>
                    </div>
                `;
            } else {
                preview.innerHTML = '<p style="color:red;">رابط YouTube غير صالح</p>';
            }
        } else if (mediaType === 'gdrive') {
            const fileId = extractGoogleDriveId(link);
            if (fileId) {
                preview.innerHTML = `
                    <h4>معاينة Google Drive:</h4>
                    <div style="position:relative;padding-top:56.25%;">
                        <iframe src="https://drive.google.com/file/d/${fileId}/preview" 
                                style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                allowfullscreen></iframe>
                    </div>
                `;
            } else {
                preview.innerHTML = '<p style="color:red;">رابط Google Drive غير صالح</p>';
            }
        } else if (mediaType === 'peertube') {
            preview.innerHTML = `
                <h4>معاينة PeerTube:</h4>
                <div style="position:relative;padding-top:56.25%;">
                    <iframe src="${link}" 
                            style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                            allowfullscreen></iframe>
                </div>
            `;
        }
    } else if (preview) {
        preview.innerHTML = '<p>أدخل الرابط لعرض المعاينة</p>';
    }
}

function updateEditLocalPreview() {
    const editForm = document.querySelector('#editModalBody form');
    if (!editForm) return;
    
    const fileInput = editForm.querySelector('#edit_local_video');
    const preview = editForm.querySelector('#edit_local_preview');
    
    if (fileInput && preview) {
        if (fileInput.files && fileInput.files[0]) {
            const file = fileInput.files[0];
            const url = URL.createObjectURL(file);
            preview.innerHTML = `
                <h4>معاينة الفيديو المحلي:</h4>
                <video controls width="100%" style="max-width: 600px;">
                    <source src="${url}" type="${file.type}">
                    متصفحك لا يدعم تشغيل الفيديو.
                </video>
                <p>اسم الملف: ${file.name}</p>
                <p>الحجم: ${(file.size / (1024 * 1024)).toFixed(2)} MB</p>
            `;
        } else {
            preview.innerHTML = '<p>اختر ملف فيديو لعرض المعاينة</p>';
        }
    }
}

function updateEditEmbedPreview() {
    const editForm = document.querySelector('#editModalBody form');
    if (!editForm) return;
    
    const embedCode = editForm.querySelector('#edit_embed_code').value;
    const preview = editForm.querySelector('#edit_embed_preview');
    
    if (embedCode && preview) {
        if (embedCode.trim()) {
            preview.innerHTML = `
                <h4>معاينة التضمين:</h4>
                <div class="embed-preview-wrapper">
                    ${embedCode}
                </div>
            `;
        } else {
            preview.innerHTML = '<p>أدخل كود التضمين لعرض المعاينة</p>';
        }
    }
}

// إغلاق النافذة عند النقر خارجها
window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target == modal) {
        closeEditModal();
    }
}
</script>

<style>
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.media-fields {
    border: 1px solid #ddd;
    padding: 20px;
    margin: 15px 0;
    border-radius: 8px;
    background: #f9f9f9;
}

.preview-container {
    margin-top: 15px;
    padding: 15px;
    background: white;
    border-radius: 8px;
    border: 1px solid #e0e0e0;
}

.preview-container h4 {
    margin-top: 0;
    color: #333;
}

.attachment-link {
    display: flex;
    gap: 10px;
    margin-bottom: 10px;
    align-items: center;
}

.attachment-link input {
    flex: 1;
}

.attachments-list {
    list-style: none;
    padding: 0;
}

.attachments-list li {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid #eee;
}

.attachments-list li:last-child {
    border-bottom: none;
}

.current-file {
    margin-top: 10px;
    padding: 10px;
    background: #f0f0f0;
    border-radius: 6px;
}

.embed-preview-wrapper {
    max-width: 100%;
    overflow: hidden;
}

.status-toggle-btn {
    padding: 4px 8px;
    border-radius: 4px;
    border: none;
    cursor: pointer;
    font-size: 12px;
    margin-left: 5px;
}

.status-active {
    background-color: #28a745;
    color: white;
}

.status-inactive {
    background-color: #dc3545;
    color: white;
}

/* أنماط نافذة التعديل */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.5);
}

.modal-content {
    background-color: white;
    margin: 2% auto;
    padding: 0;
    border-radius: 12px;
    width: 90%;
    max-width: 1000px;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.modal-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    padding: 20px;
    border-radius: 12px 12px 0 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    margin: 0;
    font-size: 1.5rem;
}

.close {
    color: white;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s ease;
}

.close:hover {
    color: #f0f0f0;
}

.modal-body {
    padding: 25px;
    max-height: calc(90vh - 100px);
    overflow-y: auto;
}

.loading {
    text-align: center;
    padding: 40px;
    font-size: 1.1rem;
    color: var(--gray-text);
}

/* أنماط خاصة لنموذج التعديل داخل النافذة */
.edit-media-fields {
    border: 1px solid #ddd;
    padding: 20px;
    margin: 15px 0;
    border-radius: 8px;
    background: #f9f9f9;
}

.edit-preview-container {
    margin-top: 15px;
    padding: 15px;
    background: white;
    border-radius: 8px;
    border: 1px solid #e0e0e0;
}

@media (max-width: 768px) {
    .form-grid {
        grid-template-columns: 1fr;
    }
    
    .attachment-link {
        flex-direction: column;
        align-items: stretch;
    }
    
    .modal-content {
        width: 95%;
        margin: 5% auto;
    }
    
    .modal-body {
        padding: 15px;
    }
}
</style>

<?php include 'partials/footer.php'; ?>