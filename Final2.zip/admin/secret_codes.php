<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db_connection.php';

if (!current_user() || current_user()['type'] !== 'admin') {
    header('Location: /login.php');
    exit;
}

$message = '';
$error = '';

// معالجة إضافة/تعديل الرمز السري
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $id = $_POST['id'] ?? 0;
        $lecture_id = intval($_POST['lecture_id']);
        $secret_code = trim($_POST['secret_code']);
        $target_type = $_POST['target_type'];
        $target_value = $_POST['target_value'] ?? '';
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $show_in_free = isset($_POST['show_in_free']) ? 1 : 0;
        $show_in_paid = isset($_POST['show_in_paid']) ? 1 : 0;
        $delay_seconds = intval($_POST['delay_seconds']);

        // التحقق من البيانات
        if (empty($lecture_id) || empty($secret_code)) {
            throw new Exception('جميع الحقول المطلوبة يجب ملؤها.');
        }

        if ($id > 0) {
            // تحديث الرمز الحالي
            $stmt = $pdo->prepare("UPDATE lecture_secret_codes SET 
                lecture_id = ?, secret_code = ?, target_type = ?, target_value = ?,
                is_active = ?, show_in_free = ?, show_in_paid = ?, delay_seconds = ?
                WHERE id = ?");
            $stmt->execute([
                $lecture_id, $secret_code, $target_type, $target_value,
                $is_active, $show_in_free, $show_in_paid, $delay_seconds, $id
            ]);
            $message = 'تم تحديث الرمز السري بنجاح!';
        } else {
            // إضافة رمز جديد
            $stmt = $pdo->prepare("INSERT INTO lecture_secret_codes 
                (lecture_id, secret_code, target_type, target_value, is_active, 
                 show_in_free, show_in_paid, delay_seconds) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $lecture_id, $secret_code, $target_type, $target_value,
                $is_active, $show_in_free, $show_in_paid, $delay_seconds
            ]);
            $message = 'تم إضافة الرمز السري بنجاح!';
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// معالجة حذف الرمز
if (isset($_GET['delete'])) {
    try {
        $id = intval($_GET['delete']);
        $stmt = $pdo->prepare("DELETE FROM lecture_secret_codes WHERE id = ?");
        $stmt->execute([$id]);
        $message = 'تم حذف الرمز السري بنجاح!';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// جلب جميع الرموز السرية
$stmt = $pdo->query("
    SELECT sc.*, l.title as lecture_title, p.name as playlist_name 
    FROM lecture_secret_codes sc 
    JOIN lectures l ON sc.lecture_id = l.id 
    JOIN playlists p ON l.playlist_id = p.id 
    ORDER BY sc.created_at DESC
");
$secret_codes = $stmt->fetchAll();

// جلب المحاضرات للقائمة المنسدلة
$lectures_stmt = $pdo->query("
    SELECT l.id, l.title, p.name as playlist_name, l.is_free 
    FROM lectures l 
    JOIN playlists p ON l.playlist_id = p.id 
    WHERE l.is_active = 1 
    ORDER BY p.name, l.title
");
$lectures = $lectures_stmt->fetchAll();

// جلب الطلاب للقائمة المنسدلة
$students_stmt = $pdo->query("
    SELECT id, name, unique_student_id, grade 
    FROM students 
    WHERE status = 'active' 
    ORDER BY name
");
$students = $students_stmt->fetchAll();

// جلب رمز للتعديل
$edit_code = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM lecture_secret_codes WHERE id = ?");
    $stmt->execute([intval($_GET['edit'])]);
    $edit_code = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الرموز السرية - نظام الإدارة</title>
    <link rel="stylesheet" href="../assets/css/admin-main.css">
    <link rel="stylesheet" href="../assets/css/admin-components.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .secret-code-form {
            background: var(--card-light);
            padding: 2rem;
            border-radius: 15px;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-light);
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: var(--text-light);
        }

        .form-control {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid var(--border-light);
            border-radius: 8px;
            background: var(--bg-dark);
            color: var(--text-light);
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-control:focus {
            outline: none;
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.1);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
        }

        .target-value-container {
            display: none;
            margin-top: 1rem;
        }

        .secret-codes-table {
            background: var(--card-light);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .table-responsive {
            overflow-x: auto;
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-active {
            background: rgba(0, 255, 136, 0.2);
            color: var(--success);
        }

        .status-inactive {
            background: rgba(255, 0, 102, 0.2);
            color: var(--danger);
        }

        .action-buttons {
            display: flex;
            gap: 0.5rem;
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.85rem;
        }

        .multi-select {
            min-height: 120px;
            max-height: 200px;
            overflow-y: auto;
        }

        .multi-select option {
            padding: 0.5rem;
            border-bottom: 1px solid var(--border-light);
        }

        .multi-select option:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <?php include 'partials/header.php'; ?>

    <div class="admin-container">
        <?php include 'partials/sidebar.php'; ?>

        <main class="admin-main">
            <div class="page-header">
                <h1><i class="fas fa-key"></i> إدارة الرموز السرية للمحاضرات</h1>
                <p>إدارة الرموز السرية التي تظهر للطلاب أثناء مشاهدة المحاضرات</p>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?= $message ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- نموذج إضافة/تعديل الرمز السري -->
            <div class="secret-code-form">
                <h2><?= $edit_code ? 'تعديل الرمز السري' : 'إضافة رمز سري جديد' ?></h2>
                
                <form method="POST">
                    <input type="hidden" name="id" value="<?= $edit_code ? $edit_code['id'] : 0 ?>">
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="lecture_id">المحاضرة *</label>
                            <select name="lecture_id" id="lecture_id" class="form-control" required>
                                <option value="">اختر المحاضرة</option>
                                <?php foreach ($lectures as $lecture): ?>
                                    <option value="<?= $lecture['id'] ?>" 
                                        <?= $edit_code && $edit_code['lecture_id'] == $lecture['id'] ? 'selected' : '' ?>
                                        data-is-free="<?= $lecture['is_free'] ?>">
                                        <?= htmlspecialchars($lecture['playlist_name']) ?> - <?= htmlspecialchars($lecture['title']) ?>
                                        (<?= $lecture['is_free'] ? 'مجاني' : 'مدفوع' ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="secret_code">الرمز السري *</label>
                            <input type="text" name="secret_code" id="secret_code" 
                                   class="form-control" required 
                                   value="<?= $edit_code ? htmlspecialchars($edit_code['secret_code']) : '' ?>"
                                   placeholder="أدخل الرمز السري">
                        </div>

                        <div class="form-group">
                            <label for="target_type">نوع الهدف</label>
                            <select name="target_type" id="target_type" class="form-control">
                                <option value="all" <?= $edit_code && $edit_code['target_type'] == 'all' ? 'selected' : '' ?>>جميع الطلاب</option>
                                <option value="grade" <?= $edit_code && $edit_code['target_type'] == 'grade' ? 'selected' : '' ?>>صف دراسي معين</option>
                                <option value="student" <?= $edit_code && $edit_code['target_type'] == 'student' ? 'selected' : '' ?>>طالب معين</option>
                                <option value="students" <?= $edit_code && $edit_code['target_type'] == 'students' ? 'selected' : '' ?>>مجموعة طلاب</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="delay_seconds">تأخير الظهور (بالثواني)</label>
                            <input type="number" name="delay_seconds" id="delay_seconds" 
                                   class="form-control" min="0" max="60" 
                                   value="<?= $edit_code ? $edit_code['delay_seconds'] : 7 ?>">
                        </div>
                    </div>

                    <!-- حقل الهدف الديناميكي -->
                    <div id="target-value-container" class="target-value-container">
                        <div class="form-group">
                            <label id="target-value-label">قيمة الهدف</label>
                            <div id="target-value-field">
                                <!-- سيتم تعبئته ديناميكياً بناءً على نوع الهدف -->
                            </div>
                        </div>
                    </div>

                    <div class="form-grid">
                        <div class="checkbox-group">
                            <input type="checkbox" name="is_active" id="is_active" 
                                   <?= !$edit_code || $edit_code['is_active'] ? 'checked' : '' ?>>
                            <label for="is_active">مفعل</label>
                        </div>

                        <div class="checkbox-group">
                            <input type="checkbox" name="show_in_free" id="show_in_free"
                                   <?= $edit_code && $edit_code['show_in_free'] ? 'checked' : '' ?>>
                            <label for="show_in_free">إظهار في المحاضرات المجانية</label>
                        </div>

                        <div class="checkbox-group">
                            <input type="checkbox" name="show_in_paid" id="show_in_paid"
                                   <?= !$edit_code || $edit_code['show_in_paid'] ? 'checked' : '' ?>>
                            <label for="show_in_paid">إظهار في المحاضرات المدفوعة</label>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i>
                            <?= $edit_code ? 'تحديث الرمز' : 'إضافة الرمز' ?>
                        </button>
                        
                        <?php if ($edit_code): ?>
                            <a href="secret_codes.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> إلغاء
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- قائمة الرموز السرية -->
            <div class="secret-codes-table">
                <div class="table-header">
                    <h3>الرموز السرية الحالية</h3>
                </div>

                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>المحاضرة</th>
                                <th>الرمز السري</th>
                                <th>نوع الهدف</th>
                                <th>الحالة</th>
                                <th>التأخير</th>
                                <th>تاريخ الإنشاء</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($secret_codes)): ?>
                                <tr>
                                    <td colspan="7" class="text-center">لا توجد رموز سرية مضافة</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($secret_codes as $code): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($code['playlist_name']) ?></strong><br>
                                            <small><?= htmlspecialchars($code['lecture_title']) ?></small>
                                        </td>
                                        <td>
                                            <code style="background: var(--bg-dark); padding: 0.25rem 0.5rem; border-radius: 4px;">
                                                <?= htmlspecialchars($code['secret_code']) ?>
                                            </code>
                                        </td>
                                        <td>
                                            <?php
                                            $target_text = '';
                                            switch ($code['target_type']) {
                                                case 'all':
                                                    $target_text = 'جميع الطلاب';
                                                    break;
                                                case 'grade':
                                                    $target_text = 'صف: ' . get_grade_text($code['target_value']);
                                                    break;
                                                case 'student':
                                                    $target_text = 'طالب معين';
                                                    break;
                                                case 'students':
                                                    $target_text = 'مجموعة طلاب';
                                                    break;
                                            }
                                            echo $target_text;
                                            ?>
                                        </td>
                                        <td>
                                            <span class="status-badge <?= $code['is_active'] ? 'status-active' : 'status-inactive' ?>">
                                                <?= $code['is_active'] ? 'مفعل' : 'معطل' ?>
                                            </span>
                                        </td>
                                        <td><?= $code['delay_seconds'] ?> ثانية</td>
                                        <td><?= date('Y/m/d H:i', strtotime($code['created_at'])) ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="?edit=<?= $code['id'] ?>" class="btn btn-warning btn-sm">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="?delete=<?= $code['id'] ?>" 
                                                   class="btn btn-danger btn-sm"
                                                   onclick="return confirm('هل أنت متأكد من حذف هذا الرمز السري؟')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
        // ديناميكية حقل الهدف
        document.getElementById('target_type').addEventListener('change', function() {
            const targetType = this.value;
            const container = document.getElementById('target-value-container');
            const field = document.getElementById('target-value-field');
            const label = document.getElementById('target-value-label');

            if (targetType === 'all') {
                container.style.display = 'none';
                field.innerHTML = '';
            } else {
                container.style.display = 'block';
                
                switch (targetType) {
                    case 'grade':
                        label.textContent = 'الصف الدراسي';
                        field.innerHTML = `
                            <select name="target_value" class="form-control" required>
                                <option value="first_secondary">الصف الأول الثانوي</option>
                                <option value="second_secondary">الصف الثاني الثانوي</option>
                                <option value="third_secondary">الصف الثالث الثانوي</option>
                            </select>
                        `;
                        break;
                    
                    case 'student':
                        label.textContent = 'الطالب';
                        field.innerHTML = `
                            <select name="target_value" class="form-control" required>
                                <option value="">اختر الطالب</option>
                                <?php foreach ($students as $student): ?>
                                    <option value="<?= $student['id'] ?>">
                                        <?= htmlspecialchars($student['name']) ?> (<?= $student['unique_student_id'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        `;
                        break;
                    
                    case 'students':
                        label.textContent = 'مجموعة الطلاب';
                        field.innerHTML = `
                            <select name="target_value[]" class="form-control multi-select" multiple required>
                                <?php foreach ($students as $student): ?>
                                    <option value="<?= $student['id'] ?>">
                                        <?= htmlspecialchars($student['name']) ?> (<?= $student['unique_student_id'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small style="color: var(--text-muted); margin-top: 0.5rem; display: block;">
                                اضغط مع الاستمرار على Ctrl لاختيار عدة طلاب
                            </small>
                        `;
                        break;
                }
            }

            // تعيين القيمة السابقة إذا كانت موجودة
            <?php if ($edit_code && $edit_code['target_type'] != 'all'): ?>
            if (targetType === '<?= $edit_code['target_type'] ?>') {
                setTimeout(() => {
                    const targetValueField = document.querySelector('[name="target_value"]');
                    if (targetValueField) {
                        <?php if ($edit_code['target_type'] == 'students'): ?>
                            // معالجة مجموعة الطلاب
                            const values = <?= json_encode(explode(',', $edit_code['target_value'])) ?>;
                            Array.from(targetValueField.options).forEach(option => {
                                option.selected = values.includes(option.value);
                            });
                        <?php else: ?>
                            targetValueField.value = '<?= $edit_code['target_value'] ?>';
                        <?php endif; ?>
                    }
                }, 100);
            }
            <?php endif; ?>
        });

        // تشغيل الحدث عند التحميل لتهيئة الحقل
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('target_type').dispatchEvent(new Event('change'));
            
            // تعيين القيم السابقة للتحقق من الصناديق
            <?php if ($edit_code): ?>
            document.getElementById('show_in_free').checked = <?= $edit_code['show_in_free'] ? 'true' : 'false' ?>;
            document.getElementById('show_in_paid').checked = <?= $edit_code['show_in_paid'] ? 'true' : 'false' ?>;
            <?php endif; ?>
        });
    </script>
</body>
</html>