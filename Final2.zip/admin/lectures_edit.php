<?php
// lectures_edit.php
require_once __DIR__ . '/../includes/db_connection.php';
require_once __DIR__ . '/../includes/functions.php';
$pdo = get_db_connection();

if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM lectures WHERE id = ?");
    $stmt->execute([$id]);
    $lecture = $stmt->fetch();
    
    if ($lecture) {
        $playlists = $pdo->query("SELECT id, name FROM playlists WHERE is_active = 1 ORDER BY name ASC")->fetchAll();
        
        // جلب المرفقات
        $att_stmt = $pdo->prepare("SELECT * FROM lecture_attachments WHERE lecture_id = ?");
        $att_stmt->execute([$lecture['id']]);
        $attachments = $att_stmt->fetchAll();
        ?>
        
        <form action="lectures.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="lecture_id" value="<?= $lecture['id'] ?>">
            <input type="hidden" name="from_modal" value="1">
            
            <div class="form-grid">
                <div class="form-group">
                    <label for="edit_title">عنوان المحاضرة:</label>
                    <input type="text" id="edit_title" name="title" value="<?= htmlspecialchars($lecture['title']) ?>" required>
                </div>

                <div class="form-group">
                    <label for="edit_playlist_id">قائمة التشغيل:</label>
                    <select id="edit_playlist_id" name="playlist_id" required>
                        <option value="">-- اختر قائمة --</option>
                        <?php foreach ($playlists as $playlist): ?>
                            <option value="<?= $playlist['id'] ?>" <?= ($lecture['playlist_id'] == $playlist['id']) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($playlist['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="edit_grade">الصف الدراسي:</label>
                    <select id="edit_grade" name="grade" required>
                        <option value="first_secondary" <?= ($lecture['grade'] == 'first_secondary') ? 'selected' : '' ?>>الأول الثانوي</option>
                        <option value="second_secondary" <?= ($lecture['grade'] == 'second_secondary') ? 'selected' : '' ?>>الثاني الثانوي</option>
                        <option value="third_secondary" <?= ($lecture['grade'] == 'third_secondary') ? 'selected' : '' ?>>الثالث الثانوي</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_free" id="edit_is_free" value="1" <?= ($lecture['is_free'] == 1) ? 'checked' : '' ?>>
                        محاضرة مجانية
                    </label>
                </div>

                <div class="form-group" id="edit_price_field">
                    <label for="edit_price">سعر المحاضرة:</label>
                    <input type="number" step="0.01" id="edit_price" name="price" value="<?= htmlspecialchars($lecture['price']) ?>">
                </div>

                <div class="form-group" id="edit_max_views_field">
                    <label for="edit_max_views">عدد المشاهدات المسموح بها:</label>
                    <input type="number" id="edit_max_views" name="max_views" value="<?= htmlspecialchars($lecture['max_views']) ?>">
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_active" value="1" <?= ($lecture['is_active'] == 1) ? 'checked' : '' ?>>
                        محاضرة مفعلة
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label for="edit_description">وصف المحاضرة:</label>
                <textarea id="edit_description" name="description" rows="4"><?= htmlspecialchars($lecture['description']) ?></textarea>
            </div>

            <div class="form-group">
                <label for="edit_thumbnail">صورة مصغرة:</label>
                <input type="file" id="edit_thumbnail" name="thumbnail" accept="image/*">
                <?php if (!empty($lecture['thumbnail_path'])): ?>
                    <div class="current-file">
                        <p>الصورة الحالية:</p>
                        <img src="../<?= htmlspecialchars($lecture['thumbnail_path']) ?>" width="100">
                        <input type="hidden" name="current_thumbnail" value="<?= htmlspecialchars($lecture['thumbnail_path']) ?>">
                    </div>
                <?php endif; ?>
            </div>

            <hr>

            <div class="form-group">
                <label for="edit_media_type">مصدر الفيديو:</label>
                <select id="edit_media_type" name="media_type" required>
                    <option value="">-- اختر المصدر --</option>
                    <option value="bunny" <?= ($lecture['media_type'] == 'bunny') ? 'selected' : '' ?>>Bunny Stream</option>
                    <option value="youtube" <?= ($lecture['media_type'] == 'youtube') ? 'selected' : '' ?>>YouTube</option>
                    <option value="gdrive" <?= ($lecture['media_type'] == 'gdrive') ? 'selected' : '' ?>>Google Drive</option>
                    <option value="peertube" <?= ($lecture['media_type'] == 'peertube') ? 'selected' : '' ?>>PeerTube</option>
                    <option value="local" <?= ($lecture['media_type'] == 'local') ? 'selected' : '' ?>>رفع ملف من الجهاز</option>
                    <option value="embed" <?= ($lecture['media_type'] == 'embed') ? 'selected' : '' ?>>تضمين (Embed)</option>
                </select>
            </div>

            <!-- حقول Bunny Stream -->
            <div id="edit_bunny_fields" class="edit-media-fields">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="edit_bunny_library_id">رقم المكتبة (Library ID):</label>
                        <input type="text" id="edit_bunny_library_id" name="bunny_library_id" value="<?= htmlspecialchars($lecture['bunny_library_id'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label for="edit_bunny_video_id">معرف الفيديو (Video ID):</label>
                        <input type="text" id="edit_bunny_video_id" name="bunny_video_id" value="<?= ($lecture['media_type'] == 'bunny') ? htmlspecialchars($lecture['media_source']) : '' ?>">
                    </div>
                </div>
                <div class="edit-preview-container" id="edit_bunny_preview"></div>
            </div>

            <!-- حقول YouTube و Google Drive و PeerTube -->
            <div id="edit_link_fields" class="edit-media-fields">
                <div class="form-group">
                    <label for="edit_link_source">رابط الفيديو:</label>
                    <input type="text" id="edit_link_source" name="link_source" placeholder="https://..." value="<?= in_array($lecture['media_type'], ['youtube', 'gdrive', 'peertube']) ? htmlspecialchars($lecture['media_source']) : '' ?>">
                </div>
                <div class="edit-preview-container" id="edit_link_preview"></div>
            </div>

            <!-- حقول رفع ملف محلي -->
            <div id="edit_local_fields" class="edit-media-fields">
                <div class="form-group">
                    <label for="edit_local_video">اختر ملف فيديو:</label>
                    <input type="file" id="edit_local_video" name="local_video" accept="video/*">
                    <?php if (!empty($lecture['media_source']) && $lecture['media_type'] == 'local'): ?>
                        <div class="current-file">
                            <p>الملف الحالي: <?= htmlspecialchars(basename($lecture['media_source'])) ?></p>
                            <input type="hidden" name="current_video" value="<?= htmlspecialchars($lecture['media_source']) ?>">
                        </div>
                    <?php endif; ?>
                </div>
                <div class="edit-preview-container" id="edit_local_preview">
                    <p>سيظهر معاينة الفيديو هنا بعد الرفع</p>
                </div>
            </div>

            <!-- حقول التضمين -->
            <div id="edit_embed_fields" class="edit-media-fields">
                <div class="form-group">
                    <label for="edit_embed_code">كود التضمين الكامل:</label>
                    <textarea id="edit_embed_code" name="embed_code" rows="8" placeholder='&lt;div class="wistia_responsive_padding" style="padding:56.25% 0 0 0;position:relative;"&gt;...&lt;/div&gt;'><?= ($lecture['media_type'] == 'embed') ? htmlspecialchars($lecture['media_source']) : '' ?></textarea>
                    <small>قم بلصق كود التضمين الكامل بما في ذلك علامات &lt;script&gt; إذا كانت موجودة</small>
                </div>
                <div class="edit-preview-container" id="edit_embed_preview">
                    <p>سيظهر معاينة التضمين هنا بعد الحفظ</p>
                </div>
            </div>

            <hr>

            <div class="form-group">
                <label>إضافة مرفقات (روابط):</label>
                <div id="edit_attachment_links">
                    <div class="attachment-link">
                        <input type="text" name="attachment_links[]" placeholder="رابط المرفق (PDF, صورة, إلخ)">
                        <button type="button" class="btn btn-danger btn-sm" onclick="removeEditAttachmentLink(this)">حذف</button>
                    </div>
                </div>
                <button type="button" class="btn btn-secondary btn-sm" onclick="addEditAttachmentLink()">+ إضافة رابط آخر</button>
            </div>

            <?php if ($attachments): ?>
                <h3>المرفقات الحالية:</h3>
                <ul class="attachments-list">
                    <?php foreach ($attachments as $att): ?>
                        <li>
                            <a href="<?= htmlspecialchars($att['file_path']) ?>" target="_blank"><?= htmlspecialchars($att['file_name']) ?></a>
                            <a href="lectures.php?edit=<?= $lecture['id'] ?>&delete_attachment=<?= $att['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من حذف هذا المرفق؟')">حذف</a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <div class="form-actions">
                <button type="submit" name="save_lecture" class="btn btn-primary">تحديث المحاضرة</button>
                <button type="button" class="btn btn-secondary" onclick="closeEditModal()">إلغاء</button>
            </div>
        </form>

        <script>
        function addEditAttachmentLink() {
            const container = document.getElementById('edit_attachment_links');
            const newLink = document.createElement('div');
            newLink.className = 'attachment-link';
            newLink.innerHTML = `
                <input type="text" name="attachment_links[]" placeholder="رابط المرفق (PDF, صورة, إلخ)">
                <button type="button" class="btn btn-danger btn-sm" onclick="removeEditAttachmentLink(this)">حذف</button>
            `;
            container.appendChild(newLink);
        }

        function removeEditAttachmentLink(button) {
            button.parentElement.remove();
        }

        // تهيئة المعاينة عند تحميل الصفحة
        document.addEventListener('DOMContentLoaded', function() {
            // تشغيل المعاينة الأولية بناءً على نوع الوسائط الحالي
            const mediaType = '<?= $lecture['media_type'] ?>';
            if (mediaType === 'bunny') {
                updateEditBunnyPreview();
            } else if (['youtube', 'gdrive', 'peertube'].includes(mediaType)) {
                updateEditLinkPreview();
            } else if (mediaType === 'embed') {
                updateEditEmbedPreview();
            }
        });

        function updateEditBunnyPreview() {
            const libraryId = document.getElementById('edit_bunny_library_id').value;
            const videoId = document.getElementById('edit_bunny_video_id').value;
            const preview = document.getElementById('edit_bunny_preview');
            
            if (libraryId && videoId) {
                preview.innerHTML = `
                    <h4>معاينة Bunny Stream:</h4>
                    <div style="position:relative;padding-top:56.25%;">
                        <iframe src="https://iframe.mediadelivery.net/embed/${libraryId}/${videoId}?autoplay=false" 
                                loading="lazy" 
                                style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                allow="accelerometer;gyroscope;autoplay;encrypted-media;picture-in-picture;" 
                                allowfullscreen="true"></iframe>
                    </div>
                `;
            } else {
                preview.innerHTML = '<p>أدخل بيانات Bunny Stream لعرض المعاينة</p>';
            }
        }

        function updateEditLinkPreview() {
            const link = document.getElementById('edit_link_source').value;
            const preview = document.getElementById('edit_link_preview');
            const mediaType = document.getElementById('edit_media_type').value;
            
            if (link) {
                if (mediaType === 'youtube') {
                    const videoId = extractYouTubeId(link);
                    if (videoId) {
                        preview.innerHTML = `
                            <h4>معاينة YouTube:</h4>
                            <div style="position:relative;padding-top:56.25%;">
                                <iframe src="https://www.youtube.com/embed/${videoId}?rel=0" 
                                        style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                        allowfullscreen></iframe>
                            </div>
                        `;
                    } else {
                        preview.innerHTML = '<p style="color:red;">رابط YouTube غير صالح</p>';
                    }
                } else if (mediaType === 'gdrive') {
                    const fileId = extractGoogleDriveId(link);
                    if (fileId) {
                        preview.innerHTML = `
                            <h4>معاينة Google Drive:</h4>
                            <div style="position:relative;padding-top:56.25%;">
                                <iframe src="https://drive.google.com/file/d/${fileId}/preview" 
                                        style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                        allowfullscreen></iframe>
                            </div>
                        `;
                    } else {
                        preview.innerHTML = '<p style="color:red;">رابط Google Drive غير صالح</p>';
                    }
                } else if (mediaType === 'peertube') {
                    preview.innerHTML = `
                        <h4>معاينة PeerTube:</h4>
                        <div style="position:relative;padding-top:56.25%;">
                            <iframe src="${link}" 
                                    style="border:0;position:absolute;top:0;height:100%;width:100%;" 
                                    allowfullscreen></iframe>
                        </div>
                    `;
                }
            } else {
                preview.innerHTML = '<p>أدخل الرابط لعرض المعاينة</p>';
            }
        }

        function updateEditEmbedPreview() {
            const embedCode = document.getElementById('edit_embed_code').value;
            const preview = document.getElementById('edit_embed_preview');
            
            if (embedCode.trim()) {
                preview.innerHTML = `
                    <h4>معاينة التضمين:</h4>
                    <div class="embed-preview-wrapper">
                        ${embedCode}
                    </div>
                `;
            } else {
                preview.innerHTML = '<p>أدخل كود التضمين لعرض المعاينة</p>';
            }
        }

        // دوال مساعدة لاستخراج المعرفات
        function extractYouTubeId(url) {
            const regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#&?]*).*/;
            const match = url.match(regExp);
            return (match && match[7].length === 11) ? match[7] : false;
        }

        function extractGoogleDriveId(url) {
            const match = url.match(/\/d\/([^\/]+)/);
            return match ? match[1] : false;
        }

        // إضافة event listeners للمعاينة التلقائية
        document.getElementById('edit_bunny_library_id')?.addEventListener('input', updateEditBunnyPreview);
        document.getElementById('edit_bunny_video_id')?.addEventListener('input', updateEditBunnyPreview);
        document.getElementById('edit_link_source')?.addEventListener('input', updateEditLinkPreview);
        document.getElementById('edit_embed_code')?.addEventListener('input', updateEditEmbedPreview);
        </script>
        <?php
    } else {
        echo '<div class="alert alert-danger">المحاضرة غير موجودة</div>';
    }
} else {
    echo '<div class="alert alert-danger">معرف المحاضرة غير محدد</div>';
}
?>