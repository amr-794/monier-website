<?php
require_once '../includes/functions.php';
if (!is_admin()) redirect('../login.php');

$page_title = "إدارة الاختبارات الشاملة";
include 'partials/header.php';
$pdo = get_db_connection();
$message = '';

// معالجة إضافة/تعديل اختبار
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_exam'])) {
        $exam_id = sanitize_input($_POST['exam_id']);
        $title = sanitize_input($_POST['title']);
        $description = sanitize_input($_POST['description']);
        $grade = sanitize_input($_POST['grade']);
        $time_limit = intval($_POST['time_limit']);
        $is_free = isset($_POST['is_free']) ? 1 : 0;
        $price = floatval($_POST['price']);
        $max_attempts = intval($_POST['max_attempts']);
        $start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
        $end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
        $results_visible = isset($_POST['results_visible']) ? 1 : 0;
        $results_schedule = !empty($_POST['results_schedule']) ? $_POST['results_schedule'] : null;
        $allow_multiple_answers = isset($_POST['allow_multiple_answers']) ? 1 : 0;
        
        // التحقق من عدم تكرار exam_id
        $check_stmt = $pdo->prepare("SELECT id FROM exams WHERE exam_id = ? AND id != ?");
        $check_stmt->execute([$exam_id, intval($_POST['id'] ?? 0)]);
        if ($check_stmt->fetch()) {
            $message = "<div class='alert alert-danger'>معرف الاختبار مسجل مسبقاً.</div>";
        } else {
            if (isset($_POST['id']) && $_POST['id'] > 0) {
                // تحديث اختبار موجود
                $stmt = $pdo->prepare("UPDATE exams SET exam_id=?, title=?, description=?, grade=?, time_limit_minutes=?, is_free=?, price=?, max_attempts=?, start_date=?, end_date=?, results_visible=?, results_schedule=?, allow_multiple_answers=? WHERE id=?");
                $stmt->execute([$exam_id, $title, $description, $grade, $time_limit, $is_free, $price, $max_attempts, $start_date, $end_date, $results_visible, $results_schedule, $allow_multiple_answers, $_POST['id']]);
                $message = "<div class='alert alert-success'>تم تحديث الاختبار بنجاح.</div>";
            } else {
                // إضافة اختبار جديد
                $stmt = $pdo->prepare("INSERT INTO exams (exam_id, title, description, grade, time_limit_minutes, is_free, price, max_attempts, start_date, end_date, results_visible, results_schedule, allow_multiple_answers, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$exam_id, $title, $description, $grade, $time_limit, $is_free, $price, $max_attempts, $start_date, $end_date, $results_visible, $results_schedule, $allow_multiple_answers, $user['id']]);
                $message = "<div class='alert alert-success'>تم إضافة الاختبار بنجاح.</div>";
            }
        }
    }
}

// معالجة الحذف
if (isset($_GET['delete_exam'])) {
    $id = intval($_GET['delete_exam']);
    $stmt = $pdo->prepare("DELETE FROM exams WHERE id = ?");
    $stmt->execute([$id]);
    $message = "<div class='alert alert-danger'>تم حذف الاختبار.</div>";
}

// جلب البيانات
$exams = $pdo->query("SELECT e.*, a.username as created_by_name FROM exams e LEFT JOIN admins a ON e.created_by = a.id ORDER BY e.created_at DESC")->fetchAll();
?>

<div class="page-header">
    <h1>إدارة الاختبارات الشاملة</h1>
    <button class="btn btn-primary" onclick="showExamForm()">إضافة اختبار جديد</button>
</div>

<?= $message ?>

<!-- نموذج إضافة/تعديل اختبار -->
<div class="card" id="examForm" style="display: none;">
    <div class="card-header">
        <h3 id="examFormTitle">إضافة اختبار جديد</h3>
    </div>
    <div class="card-body">
        <form method="POST" id="examFormElement">
            <input type="hidden" name="id" id="exam_id">
            <div class="form-grid">
                <div class="form-group">
                    <label>معرف الاختبار (مطلوب):</label>
                    <input type="text" name="exam_id" id="exam_exam_id" required class="form-control">
                    <small class="form-text text-muted">يجب أن يكون فريداً ولا يتكرر</small>
                </div>
                <div class="form-group">
                    <label>عنوان الاختبار:</label>
                    <input type="text" name="title" id="exam_title" required class="form-control">
                </div>
                <div class="form-group">
                    <label>الصف الدراسي:</label>
                    <select name="grade" id="exam_grade" class="form-control">
                        <option value="all">جميع الصفوف</option>
                        <option value="first_secondary">الأول الثانوي</option>
                        <option value="second_secondary">الثاني الثانوي</option>
                        <option value="third_secondary">الثالث الثانوي</option>
                        <option value="first_prep">الأول الإعدادي</option>
                        <option value="second_prep">الثاني الإعدادي</option>
                        <option value="third_prep">الثالث الإعدادي</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>المدة (دقائق):</label>
                    <input type="number" name="time_limit" id="exam_time_limit" value="30" min="1" class="form-control">
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_free" id="exam_is_free" value="1" checked onchange="togglePrice()"> اختبار مجاني
                    </label>
                </div>
                <div class="form-group" id="priceField" style="display: none;">
                    <label>السعر (جنيه):</label>
                    <input type="number" name="price" id="exam_price" value="0" min="0" step="0.01" class="form-control">
                </div>
                <div class="form-group">
                    <label>الحد الأقصى للمحاولات:</label>
                    <input type="number" name="max_attempts" id="exam_max_attempts" value="1" min="1" class="form-control">
                </div>
                <div class="form-group">
                    <label>موعد البدء:</label>
                    <input type="datetime-local" name="start_date" id="exam_start_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>موعد الانتهاء:</label>
                    <input type="datetime-local" name="end_date" id="exam_end_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="results_visible" id="exam_results_visible" value="1" checked onchange="toggleResultsSchedule()"> ظهور النتائج فورياً
                    </label>
                </div>
                <div class="form-group" id="resultsScheduleField" style="display: none;">
                    <label>موعد ظهور النتائج:</label>
                    <input type="datetime-local" name="results_schedule" id="exam_results_schedule" class="form-control">
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="allow_multiple_answers" id="exam_allow_multiple_answers" value="1"> السماح بإجابات متعددة
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label>وصف الاختبار:</label>
                <textarea name="description" id="exam_description" rows="3" class="form-control"></textarea>
            </div>
            <div class="form-actions">
                <button type="submit" name="save_exam" class="btn btn-success">حفظ الاختبار</button>
                <button type="button" class="btn btn-secondary" onclick="hideExamForm()">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<!-- قائمة الاختبارات -->
<div class="card">
    <div class="card-header">
        <h3>الاختبارات الشاملة</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>معرف الاختبار</th>
                        <th>العنوان</th>
                        <th>الصف</th>
                        <th>المدة</th>
                        <th>النوع</th>
                        <th>الحالة</th>
                        <th>تاريخ الإنشاء</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($exams as $exam): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($exam['exam_id']) ?></strong></td>
                        <td><?= htmlspecialchars($exam['title']) ?></td>
                        <td><?= get_grade_text($exam['grade']) ?></td>
                        <td><?= $exam['time_limit_minutes'] ?> دقيقة</td>
                        <td><?= $exam['is_free'] ? 'مجاني' : 'مدفوع' ?></td>
                        <td>
                            <span class="badge badge-<?= $exam['is_active'] ? 'success' : 'danger' ?>">
                                <?= $exam['is_active'] ? 'نشط' : 'معطل' ?>
                            </span>
                        </td>
                        <td><?= format_date($exam['created_at']) ?></td>
                        <td>
                            <div class="btn-group">
                                <a href="?view_questions=<?= $exam['id'] ?>" class="btn btn-info btn-sm">الأسئلة</a>
                                <button onclick="editExam(<?= $exam['id'] ?>)" class="btn btn-warning btn-sm">تعديل</button>
                                <a href="?delete_exam=<?= $exam['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function showExamForm() {
    document.getElementById('examForm').style.display = 'block';
    document.getElementById('examFormTitle').textContent = 'إضافة اختبار جديد';
    document.getElementById('examFormElement').reset();
    document.getElementById('exam_id').value = '';
    document.getElementById('exam_is_free').checked = true;
    togglePrice();
    toggleResultsSchedule();
}

function hideExamForm() {
    document.getElementById('examForm').style.display = 'none';
}

function togglePrice() {
    const isFree = document.getElementById('exam_is_free').checked;
    document.getElementById('priceField').style.display = isFree ? 'none' : 'block';
}

function toggleResultsSchedule() {
    const resultsVisible = document.getElementById('exam_results_visible').checked;
    document.getElementById('resultsScheduleField').style.display = resultsVisible ? 'none' : 'block';
}

function editExam(id) {
    fetch(`ajax/get_exam.php?id=${id}`)
        .then(response => response.json())
        .then(exam => {
            document.getElementById('examForm').style.display = 'block';
            document.getElementById('examFormTitle').textContent = 'تعديل الاختبار';
            document.getElementById('exam_id').value = exam.id;
            document.getElementById('exam_exam_id').value = exam.exam_id;
            document.getElementById('exam_title').value = exam.title;
            document.getElementById('exam_description').value = exam.description || '';
            document.getElementById('exam_grade').value = exam.grade;
            document.getElementById('exam_time_limit').value = exam.time_limit_minutes;
            document.getElementById('exam_is_free').checked = exam.is_free;
            document.getElementById('exam_price').value = exam.price;
            document.getElementById('exam_max_attempts').value = exam.max_attempts;
            document.getElementById('exam_start_date').value = exam.start_date ? exam.start_date.replace(' ', 'T') : '';
            document.getElementById('exam_end_date').value = exam.end_date ? exam.end_date.replace(' ', 'T') : '';
            document.getElementById('exam_results_visible').checked = exam.results_visible;
            document.getElementById('exam_results_schedule').value = exam.results_schedule ? exam.results_schedule.replace(' ', 'T') : '';
            document.getElementById('exam_allow_multiple_answers').checked = exam.allow_multiple_answers;
            
            togglePrice();
            toggleResultsSchedule();
        })
        .catch(error => {
            console.error('Error:', error);
            alert('حدث خطأ أثناء تحميل بيانات الاختبار');
        });
}

// تهيئة الأحداث
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('exam_results_visible').addEventListener('change', toggleResultsSchedule);
    document.getElementById('exam_is_free').addEventListener('change', togglePrice);
});
</script>

<?php include 'partials/footer.php'; ?>