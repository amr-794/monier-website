<?php
require_once '../includes/functions.php';
if (!is_admin()) redirect('../login.php');

$page_title = "إدارة الاختبارات الشاملة";
include 'partials/header.php';
$pdo = get_db_connection();
$message = '';

// معالجة إضافة/تعديل اختبار
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_exam'])) {
        $exam_id = sanitize_input($_POST['exam_id']);
        $title = sanitize_input($_POST['title']);
        $description = sanitize_input($_POST['description']);
        $grade = sanitize_input($_POST['grade']);
        $time_limit = intval($_POST['time_limit']);
        $is_free = isset($_POST['is_free']) ? 1 : 0;
        $price = floatval($_POST['price']);
        $max_attempts = intval($_POST['max_attempts']);
        $start_date = !empty($_POST['start_date']) ? $_POST['start_date'] : null;
        $end_date = !empty($_POST['end_date']) ? $_POST['end_date'] : null;
        $results_visible = isset($_POST['results_visible']) ? 1 : 0;
        $results_schedule = !empty($_POST['results_schedule']) ? $_POST['results_schedule'] : null;
        $allow_multiple_answers = isset($_POST['allow_multiple_answers']) ? 1 : 0;
        
        // التحقق من عدم تكرار exam_id
        $check_stmt = $pdo->prepare("SELECT id FROM exams WHERE exam_id = ? AND id != ?");
        $check_stmt->execute([$exam_id, intval($_POST['id'] ?? 0)]);
        if ($check_stmt->fetch()) {
            $message = "<div class='alert alert-danger'>معرف الاختبار مسجل مسبقاً.</div>";
        } else {
            if (isset($_POST['id']) && $_POST['id'] > 0) {
                // تحديث اختبار موجود
                $stmt = $pdo->prepare("UPDATE exams SET exam_id=?, title=?, description=?, grade=?, time_limit_minutes=?, is_free=?, price=?, max_attempts=?, start_date=?, end_date=?, results_visible=?, results_schedule=?, allow_multiple_answers=? WHERE id=?");
                $stmt->execute([$exam_id, $title, $description, $grade, $time_limit, $is_free, $price, $max_attempts, $start_date, $end_date, $results_visible, $results_schedule, $allow_multiple_answers, $_POST['id']]);
                $message = "<div class='alert alert-success'>تم تحديث الاختبار بنجاح.</div>";
            } else {
                // إضافة اختبار جديد
                $stmt = $pdo->prepare("INSERT INTO exams (exam_id, title, description, grade, time_limit_minutes, is_free, price, max_attempts, start_date, end_date, results_visible, results_schedule, allow_multiple_answers, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$exam_id, $title, $description, $grade, $time_limit, $is_free, $price, $max_attempts, $start_date, $end_date, $results_visible, $results_schedule, $allow_multiple_answers, $user['id']]);
                $message = "<div class='alert alert-success'>تم إضافة الاختبار بنجاح.</div>";
            }
        }
    }
    
    // معالجة إضافة/تعديل الأسئلة
    if (isset($_POST['save_question'])) {
        $exam_id = intval($_POST['exam_id']);
        $question_text = sanitize_input($_POST['question_text']);
        $question_type = sanitize_input($_POST['question_type']);
        $sort_order = intval($_POST['sort_order']);
        
        // رفع صورة السؤال إن وجدت
        $question_image = null;
        if (isset($_FILES['question_image']) && $_FILES['question_image']['error'] === 0) {
            $upload_dir = '../uploads/question_images/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
            
            $file_extension = pathinfo($_FILES['question_image']['name'], PATHINFO_EXTENSION);
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            
            if (in_array(strtolower($file_extension), $allowed_extensions)) {
                if ($_FILES['question_image']['size'] <= 8 * 1024 * 1024) { // 8MB
                    $filename = uniqid() . '.' . $file_extension;
                    if (move_uploaded_file($_FILES['question_image']['tmp_name'], $upload_dir . $filename)) {
                        $question_image = 'uploads/question_images/' . $filename;
                    }
                }
            }
        }
        
        if (isset($_POST['question_id']) && $_POST['question_id'] > 0) {
            // تحديث سؤال موجود
            $stmt = $pdo->prepare("UPDATE exam_questions SET question_text=?, question_image=?, question_type=?, sort_order=? WHERE id=?");
            $stmt->execute([$question_text, $question_image, $question_type, $sort_order, $_POST['question_id']]);
        } else {
            // إضافة سؤال جديد
            $stmt = $pdo->prepare("INSERT INTO exam_questions (exam_id, question_text, question_image, question_type, sort_order) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$exam_id, $question_text, $question_image, $question_type, $sort_order]);
            $question_id = $pdo->lastInsertId();
            
            // إضافة الخيارات
            if (isset($_POST['options']) && is_array($_POST['options'])) {
                foreach ($_POST['options'] as $index => $option_text) {
                    if (!empty(trim($option_text))) {
                        $is_correct = isset($_POST['correct_options'][$index]) ? 1 : 0;
                        $option_stmt = $pdo->prepare("INSERT INTO exam_question_options (question_id, option_text, is_correct, sort_order) VALUES (?, ?, ?, ?)");
                        $option_stmt->execute([$question_id, sanitize_input($option_text), $is_correct, $index]);
                    }
                }
            }
        }
        $message = "<div class='alert alert-success'>تم حفظ السؤال بنجاح.</div>";
    }
}

// معالجة الحذف
if (isset($_GET['delete_exam'])) {
    $id = intval($_GET['delete_exam']);
    $stmt = $pdo->prepare("DELETE FROM exams WHERE id = ?");
    $stmt->execute([$id]);
    $message = "<div class='alert alert-danger'>تم حذف الاختبار.</div>";
}

if (isset($_GET['delete_question'])) {
    $id = intval($_GET['delete_question']);
    $stmt = $pdo->prepare("DELETE FROM exam_questions WHERE id = ?");
    $stmt->execute([$id]);
    $message = "<div class='alert alert-danger'>تم حذف السؤال.</div>";
}

// جلب البيانات
$exams = $pdo->query("SELECT e.*, a.username as created_by_name FROM exams e LEFT JOIN admins a ON e.created_by = a.id ORDER BY e.created_at DESC")->fetchAll();

// جلب أسئلة اختبار معين
$exam_questions = [];
if (isset($_GET['view_questions'])) {
    $exam_id = intval($_GET['view_questions']);
    $questions_stmt = $pdo->prepare("SELECT eq.*, 
        (SELECT COUNT(*) FROM exam_question_options WHERE question_id = eq.id) as options_count
        FROM exam_questions eq WHERE eq.exam_id = ? ORDER BY eq.sort_order, eq.id");
    $questions_stmt->execute([$exam_id]);
    $exam_questions = $questions_stmt->fetchAll();
}
?>

<div class="page-header">
    <h1>إدارة الاختبارات الشاملة</h1>
    <button class="btn btn-primary" onclick="showExamForm()">إضافة اختبار جديد</button>
</div>

<?= $message ?>

<!-- نموذج إضافة/تعديل اختبار -->
<div class="card" id="examForm" style="display: none;">
    <div class="card-header">
        <h3 id="examFormTitle">إضافة اختبار جديد</h3>
    </div>
    <div class="card-body">
        <form method="POST" id="examFormElement">
            <input type="hidden" name="id" id="exam_id">
            <div class="form-grid">
                <div class="form-group">
                    <label>معرف الاختبار (مطلوب):</label>
                    <input type="text" name="exam_id" id="exam_exam_id" required class="form-control">
                </div>
                <div class="form-group">
                    <label>عنوان الاختبار:</label>
                    <input type="text" name="title" id="exam_title" required class="form-control">
                </div>
                <div class="form-group">
                    <label>الصف الدراسي:</label>
                    <select name="grade" id="exam_grade" class="form-control">
                        <option value="all">جميع الصفوف</option>
                        <option value="first_secondary">الأول الثانوي</option>
                        <option value="second_secondary">الثاني الثانوي</option>
                        <option value="third_secondary">الثالث الثانوي</option>
                        <option value="first_prep">الأول الإعدادي</option>
                        <option value="second_prep">الثاني الإعدادي</option>
                        <option value="third_prep">الثالث الإعدادي</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>المدة (دقائق):</label>
                    <input type="number" name="time_limit" id="exam_time_limit" value="30" min="1" class="form-control">
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="is_free" id="exam_is_free" value="1" checked onchange="togglePrice()"> اختبار مجاني
                    </label>
                </div>
                <div class="form-group" id="priceField" style="display: none;">
                    <label>السعر (جنيه):</label>
                    <input type="number" name="price" id="exam_price" value="0" min="0" step="0.01" class="form-control">
                </div>
                <div class="form-group">
                    <label>الحد الأقصى للمحاولات:</label>
                    <input type="number" name="max_attempts" id="exam_max_attempts" value="1" min="1" class="form-control">
                </div>
                <div class="form-group">
                    <label>موعد البدء:</label>
                    <input type="datetime-local" name="start_date" id="exam_start_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>موعد الانتهاء:</label>
                    <input type="datetime-local" name="end_date" id="exam_end_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="results_visible" id="exam_results_visible" value="1" checked> ظهور النتائج فورياً
                    </label>
                </div>
                <div class="form-group" id="resultsScheduleField" style="display: none;">
                    <label>موعد ظهور النتائج:</label>
                    <input type="datetime-local" name="results_schedule" id="exam_results_schedule" class="form-control">
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="allow_multiple_answers" id="exam_allow_multiple_answers" value="1"> السماح بإجابات متعددة
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label>وصف الاختبار:</label>
                <textarea name="description" id="exam_description" rows="3" class="form-control"></textarea>
            </div>
            <div class="form-actions">
                <button type="submit" name="save_exam" class="btn btn-success">حفظ الاختبار</button>
                <button type="button" class="btn btn-secondary" onclick="hideExamForm()">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<!-- قائمة الاختبارات -->
<div class="card">
    <div class="card-header">
        <h3>الاختبارات الشاملة</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>معرف الاختبار</th>
                        <th>العنوان</th>
                        <th>الصف</th>
                        <th>المدة</th>
                        <th>النوع</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($exams as $exam): ?>
                    <tr>
                        <td><?= htmlspecialchars($exam['exam_id']) ?></td>
                        <td><?= htmlspecialchars($exam['title']) ?></td>
                        <td><?= get_grade_text($exam['grade']) ?></td>
                        <td><?= $exam['time_limit_minutes'] ?> دقيقة</td>
                        <td><?= $exam['is_free'] ? 'مجاني' : 'مدفوع' ?></td>
                        <td>
                            <span class="badge badge-<?= $exam['is_active'] ? 'success' : 'danger' ?>">
                                <?= $exam['is_active'] ? 'نشط' : 'معطل' ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group">
                                <a href="?view_questions=<?= $exam['id'] ?>" class="btn btn-info btn-sm">الأسئلة</a>
                                <button onclick="editExam(<?= $exam['id'] ?>)" class="btn btn-warning btn-sm">تعديل</button>
                                <a href="?delete_exam=<?= $exam['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- عرض وإدارة الأسئلة -->
<?php if (isset($_GET['view_questions'])): ?>
<div class="card mt-4">
    <div class="card-header">
        <h3>أسئلة الاختبار</h3>
        <button class="btn btn-primary" onclick="showQuestionForm()">إضافة سؤال جديد</button>
    </div>
    <div class="card-body">
        <!-- نموذج إضافة/تعديل سؤال -->
        <div class="card" id="questionForm" style="display: none;">
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data" id="questionFormElement">
                    <input type="hidden" name="exam_id" value="<?= $exam_id ?>">
                    <input type="hidden" name="question_id" id="question_id">
                    
                    <div class="form-group">
                        <label>نص السؤال:</label>
                        <textarea name="question_text" id="question_text" rows="3" required class="form-control"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label>صورة السؤال (اختياري - الحد الأقصى 8MB):</label>
                        <input type="file" name="question_image" id="question_image" accept="image/*" class="form-control">
                        <small class="form-text text-muted">الصيغ المسموحة: JPG, PNG, GIF</small>
                    </div>
                    
                    <div class="form-group">
                        <label>نوع السؤال:</label>
                        <select name="question_type" id="question_type" class="form-control" onchange="toggleMultipleAnswers()">
                            <option value="single">اختيار واحد</option>
                            <option value="multiple">اختيار متعدد</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label>ترتيب السؤال:</label>
                        <input type="number" name="sort_order" id="sort_order" value="0" class="form-control">
                    </div>
                    
                    <!-- الخيارات -->
                    <div class="form-group">
                        <label>خيارات الإجابة:</label>
                        <div id="optionsContainer">
                            <div class="option-row mb-2">
                                <div class="input-group">
                                    <input type="text" name="options[]" class="form-control" placeholder="نص الخيار">
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <input type="checkbox" name="correct_options[]" value="0"> صحيح
                                        </span>
                                        <button type="button" class="btn btn-danger" onclick="removeOption(this)">×</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-secondary" onclick="addOption()">إضافة خيار</button>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="save_question" class="btn btn-success">حفظ السؤال</button>
                        <button type="button" class="btn btn-secondary" onclick="hideQuestionForm()">إلغاء</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- قائمة الأسئلة -->
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>نص السؤال</th>
                        <th>الصورة</th>
                        <th>النوع</th>
                        <th>عدد الخيارات</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($exam_questions as $index => $question): ?>
                    <?php 
                    $options_stmt = $pdo->prepare("SELECT * FROM exam_question_options WHERE question_id = ? ORDER BY sort_order");
                    $options_stmt->execute([$question['id']]);
                    $options = $options_stmt->fetchAll();
                    ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= htmlspecialchars(substr($question['question_text'], 0, 100)) ?>...</td>
                        <td>
                            <?php if ($question['question_image']): ?>
                                <img src="../<?= $question['question_image'] ?>" width="50" height="50" style="object-fit: cover;">
                            <?php else: ?>
                                <span class="text-muted">لا توجد</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $question['question_type'] == 'single' ? 'اختيار واحد' : 'اختيار متعدد' ?></td>
                        <td><?= $question['options_count'] ?></td>
                        <td>
                            <div class="btn-group">
                                <button onclick="editQuestion(<?= $question['id'] ?>)" class="btn btn-warning btn-sm">تعديل</button>
                                <a href="?view_questions=<?= $exam_id ?>&delete_question=<?= $question['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من حذف السؤال؟')">حذف</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
let optionCount = 1;

function showExamForm() {
    document.getElementById('examForm').style.display = 'block';
    document.getElementById('examFormTitle').textContent = 'إضافة اختبار جديد';
    document.getElementById('examFormElement').reset();
    document.getElementById('exam_id').value = '';
}

function hideExamForm() {
    document.getElementById('examForm').style.display = 'none';
}

function togglePrice() {
    const isFree = document.getElementById('exam_is_free').checked;
    document.getElementById('priceField').style.display = isFree ? 'none' : 'block';
}

function toggleResultsSchedule() {
    const resultsVisible = document.getElementById('exam_results_visible').checked;
    document.getElementById('resultsScheduleField').style.display = resultsVisible ? 'none' : 'block';
}

function editExam(id) {
    // جلب بيانات الاختبار عبر AJAX
    fetch(`ajax/get_exam.php?id=${id}`)
        .then(response => response.json())
        .then(exam => {
            document.getElementById('examForm').style.display = 'block';
            document.getElementById('examFormTitle').textContent = 'تعديل الاختبار';
            document.getElementById('exam_id').value = exam.id;
            document.getElementById('exam_exam_id').value = exam.exam_id;
            document.getElementById('exam_title').value = exam.title;
            document.getElementById('exam_description').value = exam.description || '';
            document.getElementById('exam_grade').value = exam.grade;
            document.getElementById('exam_time_limit').value = exam.time_limit_minutes;
            document.getElementById('exam_is_free').checked = exam.is_free;
            document.getElementById('exam_price').value = exam.price;
            document.getElementById('exam_max_attempts').value = exam.max_attempts;
            document.getElementById('exam_start_date').value = exam.start_date ? exam.start_date.replace(' ', 'T') : '';
            document.getElementById('exam_end_date').value = exam.end_date ? exam.end_date.replace(' ', 'T') : '';
            document.getElementById('exam_results_visible').checked = exam.results_visible;
            document.getElementById('exam_results_schedule').value = exam.results_schedule ? exam.results_schedule.replace(' ', 'T') : '';
            document.getElementById('exam_allow_multiple_answers').checked = exam.allow_multiple_answers;
            
            togglePrice();
            toggleResultsSchedule();
        });
}

function addOption() {
    const container = document.getElementById('optionsContainer');
    const newOption = document.createElement('div');
    newOption.className = 'option-row mb-2';
    newOption.innerHTML = `
        <div class="input-group">
            <input type="text" name="options[]" class="form-control" placeholder="نص الخيار">
            <div class="input-group-append">
                <span class="input-group-text">
                    <input type="checkbox" name="correct_options[]" value="${optionCount}"> صحيح
                </span>
                <button type="button" class="btn btn-danger" onclick="removeOption(this)">×</button>
            </div>
        </div>
    `;
    container.appendChild(newOption);
    optionCount++;
}

function removeOption(button) {
    button.closest('.option-row').remove();
}

function showQuestionForm() {
    document.getElementById('questionForm').style.display = 'block';
    document.getElementById('questionFormElement').reset();
    document.getElementById('question_id').value = '';
    document.getElementById('optionsContainer').innerHTML = `
        <div class="option-row mb-2">
            <div class="input-group">
                <input type="text" name="options[]" class="form-control" placeholder="نص الخيار">
                <div class="input-group-append">
                    <span class="input-group-text">
                        <input type="checkbox" name="correct_options[]" value="0"> صحيح
                    </span>
                    <button type="button" class="btn btn-danger" onclick="removeOption(this)">×</button>
                </div>
            </div>
        </div>
    `;
    optionCount = 1;
}

function hideQuestionForm() {
    document.getElementById('questionForm').style.display = 'none';
}

function editQuestion(id) {
    // جلب بيانات السؤال عبر AJAX
    fetch(`ajax/get_question.php?id=${id}`)
        .then(response => response.json())
        .then(question => {
            document.getElementById('questionForm').style.display = 'block';
            document.getElementById('question_id').value = question.id;
            document.getElementById('question_text').value = question.question_text;
            document.getElementById('question_type').value = question.question_type;
            document.getElementById('sort_order').value = question.sort_order;
            
            // جلب الخيارات
            fetch(`ajax/get_question_options.php?question_id=${id}`)
                .then(response => response.json())
                .then(options => {
                    const container = document.getElementById('optionsContainer');
                    container.innerHTML = '';
                    optionCount = 0;
                    
                    options.forEach((option, index) => {
                        const optionRow = document.createElement('div');
                        optionRow.className = 'option-row mb-2';
                        optionRow.innerHTML = `
                            <div class="input-group">
                                <input type="text" name="options[]" class="form-control" value="${option.option_text}" placeholder="نص الخيار">
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <input type="checkbox" name="correct_options[]" value="${optionCount}" ${option.is_correct ? 'checked' : ''}> صحيح
                                    </span>
                                    <button type="button" class="btn btn-danger" onclick="removeOption(this)">×</button>
                                </div>
                            </div>
                        `;
                        container.appendChild(optionRow);
                        optionCount++;
                    });
                });
        });
}

// تهيئة الأحداث
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('exam_results_visible').addEventListener('change', toggleResultsSchedule);
    document.getElementById('exam_is_free').addEventListener('change', togglePrice);
    togglePrice();
    toggleResultsSchedule();
});
</script>

<?php include 'partials/footer.php'; ?>