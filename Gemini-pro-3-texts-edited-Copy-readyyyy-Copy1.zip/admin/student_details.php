<?php
require_once '../includes/functions.php';
if (!is_admin()) redirect('../login.php');

$page_title = "تفاصيل الطالب";
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
$pdo = get_db_connection();

$student_id = intval($_GET['id'] ?? 0);
if (!$student_id) redirect('students.php');

// جلب بيانات الطالب
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) redirect('students.php');

// جلب جلسات الطالب
$sessions_stmt = $pdo->prepare("
    SELECT * FROM user_sessions 
    WHERE user_id = ? AND user_type = 'student' 
    ORDER BY last_activity DESC 
    LIMIT 10
");
$sessions_stmt->execute([$student_id]);
$sessions = $sessions_stmt->fetchAll();

// جلب محاولات الاختبارات
$exam_attempts_stmt = $pdo->prepare("
    SELECT a.*, e.title as exam_title, e.exam_id 
    FROM student_exam_attempts a 
    JOIN exams e ON a.exam_id = e.id 
    WHERE a.student_id = ? 
    ORDER BY a.attempted_at DESC
");
$exam_attempts_stmt->execute([$student_id]);
$exam_attempts = $exam_attempts_stmt->fetchAll();

// جلب المحاضرات التي شاهدها
$lecture_access_stmt = $pdo->prepare("
    SELECT a.*, l.title as lecture_title 
    FROM student_lecture_access a 
    JOIN lectures l ON a.lecture_id = l.id 
    WHERE a.student_id = ? 
    ORDER BY a.last_viewed DESC
");
$lecture_access_stmt->execute([$student_id]);
$lecture_access = $lecture_access_stmt->fetchAll();

// معالجة تحديث بيانات الطالب
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_student'])) {
    $name = sanitize_input($_POST['name']);
    $phone = sanitize_input($_POST['phone']);
    $parent_phone = sanitize_input($_POST['parent_phone']);
    $email = sanitize_input($_POST['email']);
    $grade = sanitize_input($_POST['grade']);
    $status = sanitize_input($_POST['status']);
    $notes = sanitize_input($_POST['notes']);
    
    // التحقق من عدم تكرار الهاتف والبريد
    $check_stmt = $pdo->prepare("SELECT id FROM students WHERE (phone = ? OR email = ?) AND id != ?");
    $check_stmt->execute([$phone, $email, $student_id]);
    if ($check_stmt->fetch()) {
        $message = "<div class='alert alert-danger'>رقم الهاتف أو البريد الإلكتروني مسجل مسبقاً.</div>";
    } else {
        $update_stmt = $pdo->prepare("
            UPDATE students SET name=?, phone=?, parent_phone=?, email=?, grade=?, status=?, notes=? 
            WHERE id=?
        ");
        $update_stmt->execute([$name, $phone, $parent_phone, $email, $grade, $status, $notes, $student_id]);
        $message = "<div class='alert alert-success'>تم تحديث بيانات الطالب بنجاح.</div>";
        
        // تحديث بيانات الطالب المحملة
        $student = array_merge($student, [
            'name' => $name,
            'phone' => $phone,
            'parent_phone' => $parent_phone,
            'email' => $email,
            'grade' => $grade,
            'status' => $status,
            'notes' => $notes
        ]);
    }
}

// معالجة تغيير كلمة المرور
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password !== $confirm_password) {
        $password_message = "<div class='alert alert-danger'>كلمات المرور غير متطابقة.</div>";
    } elseif (strlen($new_password) < 6) {
        $password_message = "<div class='alert alert-danger'>كلمة المرور يجب أن تكون 6 أحرف على الأقل.</div>";
    } else {
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $update_stmt = $pdo->prepare("UPDATE students SET password_hash = ? WHERE id = ?");
        $update_stmt->execute([$password_hash, $student_id]);
        $password_message = "<div class='alert alert-success'>تم تغيير كلمة المرور بنجاح.</div>";
    }
}
?>

<div class="page-header">
    <h1>تفاصيل الطالب: <?= htmlspecialchars($student['name']) ?></h1>
    <a href="students.php" class="btn btn-secondary">العودة للقائمة</a>
</div>

<?= $message ?? '' ?>

<div class="row">
    <!-- المعلومات الأساسية -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3>المعلومات الأساسية</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="form-group">
                        <label>الاسم الكامل:</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>رقم الهاتف:</label>
                        <input type="text" name="phone" value="<?= htmlspecialchars($student['phone']) ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>رقم ولي الأمر:</label>
                        <input type="text" name="parent_phone" value="<?= htmlspecialchars($student['parent_phone']) ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>البريد الإلكتروني:</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>الصف الدراسي:</label>
                        <select name="grade" class="form-control">
                            <option value="first_secondary" <?= $student['grade'] == 'first_secondary' ? 'selected' : '' ?>>الأول الثانوي</option>
                            <option value="second_secondary" <?= $student['grade'] == 'second_secondary' ? 'selected' : '' ?>>الثاني الثانوي</option>
                            <option value="third_secondary" <?= $student['grade'] == 'third_secondary' ? 'selected' : '' ?>>الثالث الثانوي</option>
                            <option value="first_prep" <?= $student['grade'] == 'first_prep' ? 'selected' : '' ?>>الأول الإعدادي</option>
                            <option value="second_prep" <?= $student['grade'] == 'second_prep' ? 'selected' : '' ?>>الثاني الإعدادي</option>
                            <option value="third_prep" <?= $student['grade'] == 'third_prep' ? 'selected' : '' ?>>الثالث الإعدادي</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>حالة الحساب:</label>
                        <select name="status" class="form-control">
                            <option value="active" <?= $student['status'] == 'active' ? 'selected' : '' ?>>نشط</option>
                            <option value="suspended" <?= $student['status'] == 'suspended' ? 'selected' : '' ?>>موقوف</option>
                            <option value="banned" <?= $student['status'] == 'banned' ? 'selected' : '' ?>>محظور</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>ملاحظات:</label>
                        <textarea name="notes" rows="3" class="form-control"><?= htmlspecialchars($student['notes'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" name="update_student" class="btn btn-success">تحديث البيانات</button>
                </form>
            </div>
        </div>
        
        <!-- تغيير كلمة المرور -->
        <div class="card mt-4">
            <div class="card-header">
                <h3>تغيير كلمة المرور</h3>
            </div>
            <div class="card-body">
                <?= $password_message ?? '' ?>
                <form method="POST">
                    <div class="form-group">
                        <label>كلمة المرور الجديدة:</label>
                        <input type="password" name="new_password" class="form-control" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label>تأكيد كلمة المرور:</label>
                        <input type="password" name="confirm_password" class="form-control" required minlength="6">
                    </div>
                    <button type="submit" name="change_password" class="btn btn-warning">تغيير كلمة المرور</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- الإحصائيات والمعلومات -->
    <div class="col-md-6">
        <!-- معلومات النظام -->
        <div class="card">
            <div class="card-header">
                <h3>معلومات النظام</h3>
            </div>
            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <strong>رقم الطالب:</strong>
                        <span><?= $student['unique_student_id'] ?></span>
                    </div>
                    <div class="info-item">
                        <strong>تاريخ التسجيل:</strong>
                        <span><?= format_date($student['created_at']) ?></span>
                    </div>
                    <div class="info-item">
                        <strong>آخر تسجيل دخول:</strong>
                        <span><?= $student['last_login'] ? format_date($student['last_login']) : 'لم يسجل دخول' ?></span>
                    </div>
                    <div class="info-item">
                        <strong>آخر ظهور:</strong>
                        <span><?= $student['last_seen'] ? format_date($student['last_seen']) : 'غير متصل' ?></span>
                    </div>
                    <div class="info-item">
                        <strong>عدد مرات الدخول:</strong>
                        <span><?= $student['login_count'] ?></span>
                    </div>
                    <div class="info-item">
                        <strong>نوع الجهاز:</strong>
                        <span><?= $student['device_type'] ?: 'غير معروف' ?></span>
                    </div>
                    <div class="info-item">
                        <strong>آخر IP:</strong>
                        <span><?= $student['ip_address'] ?: 'غير معروف' ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- الجلسات النشطة -->
        <div class="card mt-4">
            <div class="card-header">
                <h3>آخر الجلسات</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>جهاز الدخول</th>
                                <th>IP</th>
                                <th>آخر نشاط</th>
                                <th>الحالة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sessions as $session): ?>
                            <tr>
                                <td>
                                    <?= $session['device_type'] ?: 'غير معروف' ?>
                                    <?php if ($session['device_id']): ?>
                                        <br><small class="text-muted"><?= substr($session['device_id'], 0, 8) ?>...</small>
                                    <?php endif; ?>
                                </td>
                                <td><?= $session['ip_address'] ?></td>
                                <td><?= format_date($session['last_activity']) ?></td>
                                <td>
                                    <span class="badge badge-<?= $session['is_active'] ? 'success' : 'secondary' ?>">
                                        <?= $session['is_active'] ? 'نشط' : 'منتهي' ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- الاختبارات والمحاضرات -->
<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3>اختبارات الطالب</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>الاختبار</th>
                                <th>الدرجة</th>
                                <th>التاريخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($exam_attempts as $attempt): ?>
                            <tr>
                                <td><?= htmlspecialchars($attempt['exam_title']) ?></td>
                                <td>
                                    <span class="badge badge-<?= get_percentage_color($attempt['percentage']) ?>">
                                        <?= $attempt['score'] ?>/<?= $attempt['total_questions'] ?> (<?= $attempt['percentage'] ?>%)
                                    </span>
                                </td>
                                <td><?= format_date($attempt['attempted_at']) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3>المحاضرات المشاهدة</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>المحاضرة</th>
                                <th>المشاهدات المتبقية</th>
                                <th>آخر مشاهدة</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lecture_access as $access): ?>
                            <tr>
                                <td><?= htmlspecialchars($access['lecture_title']) ?></td>
                                <td><?= $access['remaining_views'] ?></td>
                                <td><?= $access['last_viewed'] ? format_date($access['last_viewed']) : 'لم يشاهد' ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>






















<!-- نموذج الحظر المؤقت -->
<div class="card mt-4">
    <div class="card-header">
        <h3>الحظر المؤقت</h3>
    </div>
    <div class="card-body">
        <form method="POST">
            <div class="form-group">
                <label>مدة الحظر:</label>
                <div class="row">
                    <div class="col-md-6">
                        <input type="number" name="suspend_hours" class="form-control" placeholder="الساعات" min="0">
                    </div>
                    <div class="col-md-6">
                        <input type="number" name="suspend_minutes" class="form-control" placeholder="الدقائق" min="0" max="59">
                    </div>
                </div>
                <small class="form-text text-muted">اترك الحقول فارغة لإلغاء الحظر</small>
            </div>
            <div class="form-group">
                <label>سبب الحظر (اختياري):</label>
                <textarea name="suspend_reason" rows="2" class="form-control"></textarea>
            </div>
            <button type="submit" name="suspend_student" class="btn btn-danger">تطبيق الحظر</button>
        </form>
        
        <?php if ($student['suspended_until']): ?>
        <div class="alert alert-warning mt-3">
            <strong>ملاحظة:</strong> الطالب محظور حتى <?= format_date($student['suspended_until']) ?>
        </div>
        <?php endif; ?>
    </div>
</div>











<style>
.info-grid {
    display: grid;
    gap: 10px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid #e9ecef;
}

.info-item:last-child {
    border-bottom: none;
}
</style>

<?php include 'partials/footer.php'; ?>