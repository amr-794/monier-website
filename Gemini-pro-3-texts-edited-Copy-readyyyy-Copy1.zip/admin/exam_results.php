<?php
require_once '../includes/functions.php';
if (!is_admin()) redirect('../login.php');

$page_title = "نتائج الاختبارات";
include 'partials/header.php';
$pdo = get_db_connection();

// جلب جميع الاختبارات
$exams = $pdo->query("SELECT id, exam_id, title FROM exams ORDER BY created_at DESC")->fetchAll();

// جلب النتائج بناءً على الفلتر
$exam_filter = $_GET['exam_id'] ?? '';
$grade_filter = $_GET['grade'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

$where_conditions = [];
$params = [];

if ($exam_filter) {
    $where_conditions[] = "r.exam_id = ?";
    $params[] = $exam_filter;
}

if ($grade_filter) {
    $where_conditions[] = "s.grade = ?";
    $params[] = $grade_filter;
}

if ($date_from) {
    $where_conditions[] = "DATE(r.completed_at) >= ?";
    $params[] = $date_from;
}

if ($date_to) {
    $where_conditions[] = "DATE(r.completed_at) <= ?";
    $params[] = $date_to;
}

$where_sql = $where_conditions ? "WHERE " . implode(" AND ", $where_conditions) : "";

$results_stmt = $pdo->prepare("
    SELECT r.*, s.name as student_name, s.unique_student_id, s.grade, 
           e.title as exam_title, e.exam_id
    FROM student_exam_results r 
    JOIN students s ON r.student_id = s.id 
    JOIN exams e ON r.exam_id = e.id 
    $where_sql
    ORDER BY r.completed_at DESC
");
$results_stmt->execute($params);
$results = $results_stmt->fetchAll();

// إحصائيات
$stats_stmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_results,
        AVG(r.percentage) as avg_percentage,
        MAX(r.percentage) as max_percentage,
        MIN(r.percentage) as min_percentage
    FROM student_exam_results r 
    $where_sql
");
$stats_stmt->execute($params);
$stats = $stats_stmt->fetch();
?>

<div class="page-header">
    <h1>نتائج الاختبارات</h1>
</div>

<!-- فلترة النتائج -->
<div class="card mb-4">
    <div class="card-header">
        <h3>فلترة النتائج</h3>
    </div>
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label>الاختبار:</label>
                <select name="exam_id" class="form-control">
                    <option value="">جميع الاختبارات</option>
                    <?php foreach ($exams as $exam): ?>
                    <option value="<?= $exam['id'] ?>" <?= $exam_filter == $exam['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($exam['title']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label>الصف الدراسي:</label>
                <select name="grade" class="form-control">
                    <option value="">جميع الصفوف</option>
                    <option value="first_secondary" <?= $grade_filter == 'first_secondary' ? 'selected' : '' ?>>الأول الثانوي</option>
                    <option value="second_secondary" <?= $grade_filter == 'second_secondary' ? 'selected' : '' ?>>الثاني الثانوي</option>
                    <option value="third_secondary" <?= $grade_filter == 'third_secondary' ? 'selected' : '' ?>>الثالث الثانوي</option>
                    <option value="first_prep" <?= $grade_filter == 'first_prep' ? 'selected' : '' ?>>الأول الإعدادي</option>
                    <option value="second_prep" <?= $grade_filter == 'second_prep' ? 'selected' : '' ?>>الثاني الإعدادي</option>
                    <option value="third_prep" <?= $grade_filter == 'third_prep' ? 'selected' : '' ?>>الثالث الإعدادي</option>
                </select>
            </div>
            <div class="col-md-3">
                <label>من تاريخ:</label>
                <input type="date" name="date_from" value="<?= $date_from ?>" class="form-control">
            </div>
            <div class="col-md-3">
                <label>إلى تاريخ:</label>
                <input type="date" name="date_to" value="<?= $date_to ?>" class="form-control">
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary">تطبيق الفلترة</button>
                <a href="exam_results.php" class="btn btn-secondary">إعادة تعيين</a>
            </div>
        </form>
    </div>
</div>

<!-- الإحصائيات -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h4><?= $stats['total_results'] ?></h4>
                <p>إجمالي النتائج</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h4><?= round($stats['avg_percentage'] ?? 0, 1) ?>%</h4>
                <p>متوسط النسبة</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h4><?= round($stats['max_percentage'] ?? 0, 1) ?>%</h4>
                <p>أعلى نسبة</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h4><?= round($stats['min_percentage'] ?? 0, 1) ?>%</h4>
                <p>أقل نسبة</p>
            </div>
        </div>
    </div>
</div>

<!-- جدول النتائج -->
<div class="card">
    <div class="card-header">
        <h3>النتائج</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>الطالب</th>
                        <th>الاختبار</th>
                        <th>الصف</th>
                        <th>الدرجة</th>
                        <th>النسبة</th>
                        <th>الوقت</th>
                        <th>التاريخ</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($results as $result): ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars($result['student_name']) ?></strong>
                            <br><small class="text-muted"><?= $result['unique_student_id'] ?></small>
                        </td>
                        <td><?= htmlspecialchars($result['exam_title']) ?></td>
                        <td><?= get_grade_text($result['grade']) ?></td>
                        <td><?= $result['score'] ?>/<?= $result['total_questions'] ?></td>
                        <td>
                            <span class="badge badge-<?= get_percentage_color($result['percentage']) ?>">
                                <?= $result['percentage'] ?>%
                            </span>
                        </td>
                        <td><?= format_time($result['time_spent']) ?></td>
                        <td><?= format_date($result['completed_at']) ?></td>
                        <td>
                            <div class="btn-group">
                                <a href="../student/exam_result.php?attempt_id=<?= $result['attempt_id'] ?>" 
                                   target="_blank" class="btn btn-info btn-sm">عرض</a>
                                <button class="btn btn-success btn-sm" onclick="printResult(<?= $result['id'] ?>)">طباعة</button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <?php if (empty($results)): ?>
        <div class="alert alert-info text-center">لا توجد نتائج تطابق معايير البحث</div>
        <?php endif; ?>
    </div>
</div>

<script>
function printResult(resultId) {
    const printWindow = window.open(`../student/print_result.php?result_id=${resultId}`, '_blank');
    printWindow.onload = function() {
        printWindow.print();
    };
}
</script>

<?php include 'partials/footer.php'; ?>