<?php
$page_title = 'إدارة الإعلانات والإشعارات';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
$pdo = get_db_connection();

// معالجة إضافة أو تعديل
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_announcement'])) {
    $title = sanitize_input($_POST['title']);
    $content = sanitize_input($_POST['content'], true);
    $target_type = sanitize_input($_POST['target_type']);
    $target_id = $target_type !== 'all' ? intval($_POST['target_id']) : null;
    $is_notification = isset($_POST['is_notification']) ? 1 : 0;
    $show_in_main = isset($_POST['show_in_main']) ? 1 : 0;
    $can_dismiss = isset($_POST['can_dismiss']) ? 1 : 0;
    $lecture_id = !empty($_POST['lecture_id']) ? intval($_POST['lecture_id']) : null;
    $id = intval($_POST['id'] ?? 0);
    
    if ($id > 0) {
        $stmt = $pdo->prepare("
            UPDATE announcements SET 
            title=?, content=?, target_type=?, target_id=?, is_notification=?, 
            show_in_main=?, can_dismiss=?, lecture_id=? 
            WHERE id=?
        ");
        $stmt->execute([$title, $content, $target_type, $target_id, $is_notification, $show_in_main, $can_dismiss, $lecture_id, $id]);
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO announcements 
            (title, content, target_type, target_id, is_notification, show_in_main, can_dismiss, lecture_id) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$title, $content, $target_type, $target_id, $is_notification, $show_in_main, $can_dismiss, $lecture_id]);
    }
    
    $message = "<div class='alert alert-success'>تم حفظ الإعلان بنجاح.</div>";
}

// معالجة الحذف
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM announcements WHERE id = ?");
    $stmt->execute([$id]);
    $message = "<div class='alert alert-danger'>تم حذف الإعلان.</div>";
}

// معالجة التفعيل/التعطيل
if (isset($_GET['toggle'])) {
    $id = intval($_GET['toggle']);
    $stmt = $pdo->prepare("UPDATE announcements SET is_visible = NOT is_visible WHERE id = ?");
    $stmt->execute([$id]);
    $message = "<div class='alert alert-success'>تم تغيير حالة الإعلان.</div>";
}

// جلب البيانات
$announcements = $pdo->query("
    SELECT a.*, l.title as lecture_title 
    FROM announcements a 
    LEFT JOIN lectures l ON a.lecture_id = l.id 
    ORDER BY a.created_at DESC
")->fetchAll();

// جلب الطلاب للقائمة المنسدلة
$students = $pdo->query("SELECT id, name, unique_student_id FROM students ORDER BY name")->fetchAll();

// جلب المحاضرات للقائمة المنسدلة
$lectures = $pdo->query("SELECT id, title FROM lectures WHERE is_active = 1 ORDER BY title")->fetchAll();
?>

<div class="page-header">
    <h1>إدارة الإعلانات والإشعارات</h1>
    <button class="btn btn-primary" onclick="showAnnouncementForm()">إضافة إعلان جديد</button>
</div>

<?= $message ?? '' ?>

<!-- نموذج إضافة/تعديل إعلان -->
<div class="card" id="announcementForm" style="display: none;">
    <div class="card-header">
        <h3 id="announcementFormTitle">إضافة إعلان جديد</h3>
    </div>
    <div class="card-body">
        <form method="POST" id="announcementFormElement">
            <input type="hidden" name="id" id="announcement_id">
            
            <div class="form-group">
                <label>عنوان الإعلان:</label>
                <input type="text" name="title" id="announcement_title" required class="form-control">
            </div>
            
            <div class="form-group">
                <label>محتوى الإعلان:</label>
                <textarea name="content" id="announcement_content" rows="6" required class="form-control"></textarea>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>نوع الهدف:</label>
                        <select name="target_type" id="target_type" class="form-control" onchange="toggleTargetId()">
                            <option value="all">جميع المستخدمين</option>
                            <option value="specific_student">طالب محدد</option>
                            <option value="specific_grade">صف محدد</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group" id="targetIdField" style="display: none;">
                        <label id="targetIdLabel">الهدف:</label>
                        <select name="target_id" id="target_id" class="form-control">
                            <!-- سيتم تعبئته بالجافاسكريبت -->
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>المحاضرة (اختياري):</label>
                        <select name="lecture_id" id="lecture_id" class="form-control">
                            <option value="">لا توجد</option>
                            <?php foreach ($lectures as $lecture): ?>
                            <option value="<?= $lecture['id'] ?>"><?= htmlspecialchars($lecture['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small class="form-text text-muted">لإظهار الإعلان في صفحة محاضرة محددة</small>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4">
                    <div class="form-check">
                        <input type="checkbox" name="is_notification" id="is_notification" value="1" class="form-check-input">
                        <label class="form-check-label">إشعار</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-check">
                        <input type="checkbox" name="show_in_main" id="show_in_main" value="1" class="form-check-input">
                        <label class="form-check-label">عرض في الصفحة الرئيسية</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-check">
                        <input type="checkbox" name="can_dismiss" id="can_dismiss" value="1" checked class="form-check-input">
                        <label class="form-check-label">يمكن تجاهله</label>
                    </div>
                </div>
            </div>
            
            <div class="form-actions mt-3">
                <button type="submit" name="save_announcement" class="btn btn-success">حفظ الإعلان</button>
                <button type="button" class="btn btn-secondary" onclick="hideAnnouncementForm()">إلغاء</button>
            </div>
        </form>
    </div>
</div>

<!-- قائمة الإعلانات -->
<div class="card">
    <div class="card-header">
        <h3>الإعلانات والإشعارات</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>العنوان</th>
                        <th>الهدف</th>
                        <th>النوع</th>
                        <th>العرض</th>
                        <th>التاريخ</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($announcements as $ann): ?>
                    <tr>
                        <td><?= htmlspecialchars($ann['title']) ?></td>
                        <td>
                            <?php
                            $target_text = '';
                            if ($ann['target_type'] === 'all') {
                                $target_text = 'الجميع';
                            } elseif ($ann['target_type'] === 'specific_student') {
                                $target_text = 'طالب محدد';
                            } elseif ($ann['target_type'] === 'specific_grade') {
                                $target_text = get_grade_text($ann['target_id']);
                            }
                            echo $target_text;
                            ?>
                        </td>
                        <td>
                            <?= $ann['is_notification'] ? 'إشعار' : 'إعلان' ?>
                            <?= $ann['show_in_main'] ? '<br><small class="text-muted">(رئيسي)</small>' : '' ?>
                        </td>
                        <td>
                            <?= $ann['lecture_title'] ? 'محاضرة: ' . htmlspecialchars($ann['lecture_title']) : 'عام' ?>
                        </td>
                        <td><?= format_date($ann['created_at']) ?></td>
                        <td>
                            <span class="badge badge-<?= $ann['is_visible'] ? 'success' : 'danger' ?>">
                                <?= $ann['is_visible'] ? 'نشط' : 'معطل' ?>
                            </span>
                        </td>
                        <td>
                            <div class="btn-group">
                                <button onclick="editAnnouncement(<?= $ann['id'] ?>)" class="btn btn-warning btn-sm">تعديل</button>
                                <a href="?toggle=<?= $ann['id'] ?>" class="btn btn-<?= $ann['is_visible'] ? 'secondary' : 'info' ?> btn-sm">
                                    <?= $ann['is_visible'] ? 'تعطيل' : 'تفعيل' ?>
                                </a>
                                <a href="?delete=<?= $ann['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من الحذف؟')">حذف</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
const students = <?= json_encode($students) ?>;
const grades = [
    {value: 'first_secondary', text: 'الأول الثانوي'},
    {value: 'second_secondary', text: 'الثاني الثانوي'},
    {value: 'third_secondary', text: 'الثالث الثانوي'},
    {value: 'first_prep', text: 'الأول الإعدادي'},
    {value: 'second_prep', text: 'الثاني الإعدادي'},
    {value: 'third_prep', text: 'الثالث الإعدادي'}
];

function showAnnouncementForm() {
    document.getElementById('announcementForm').style.display = 'block';
    document.getElementById('announcementFormTitle').textContent = 'إضافة إعلان جديد';
    document.getElementById('announcementFormElement').reset();
    document.getElementById('announcement_id').value = '';
    toggleTargetId();
}

function hideAnnouncementForm() {
    document.getElementById('announcementForm').style.display = 'none';
}

function toggleTargetId() {
    const targetType = document.getElementById('target_type').value;
    const targetIdField = document.getElementById('targetIdField');
    const targetIdSelect = document.getElementById('target_id');
    
    if (targetType === 'all') {
        targetIdField.style.display = 'none';
    } else {
        targetIdField.style.display = 'block';
        
        // تفريغ القائمة
        targetIdSelect.innerHTML = '';
        
        if (targetType === 'specific_student') {
            document.getElementById('targetIdLabel').textContent = 'الطالب:';
            students.forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.textContent = student.name + ' (' + student.unique_student_id + ')';
                targetIdSelect.appendChild(option);
            });
        } else if (targetType === 'specific_grade') {
            document.getElementById('targetIdLabel').textContent = 'الصف:';
            grades.forEach(grade => {
                const option = document.createElement('option');
                option.value = grade.value;
                option.textContent = grade.text;
                targetIdSelect.appendChild(option);
            });
        }
    }
}

function editAnnouncement(id) {
    fetch(`ajax/get_announcement.php?id=${id}`)
        .then(response => response.json())
        .then(announcement => {
            document.getElementById('announcementForm').style.display = 'block';
            document.getElementById('announcementFormTitle').textContent = 'تعديل الإعلان';
            document.getElementById('announcement_id').value = announcement.id;
            document.getElementById('announcement_title').value = announcement.title;
            document.getElementById('announcement_content').value = announcement.content;
            document.getElementById('target_type').value = announcement.target_type;
            document.getElementById('lecture_id').value = announcement.lecture_id || '';
            document.getElementById('is_notification').checked = announcement.is_notification;
            document.getElementById('show_in_main').checked = announcement.show_in_main;
            document.getElementById('can_dismiss').checked = announcement.can_dismiss;
            
            toggleTargetId();
            
            // تعيين قيمة الهدف بعد تحميل القائمة
            setTimeout(() => {
                if (announcement.target_id) {
                    document.getElementById('target_id').value = announcement.target_id;
                }
            }, 100);
        })
        .catch(error => {
            console.error('Error:', error);
            alert('حدث خطأ أثناء تحميل بيانات الإعلان');
        });
}

// تهيئة الأحداث
document.addEventListener('DOMContentLoaded', function() {
    toggleTargetId();
});
</script>

<?php include 'partials/footer.php'; ?>