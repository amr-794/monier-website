<?php
require_once '../../includes/functions.php';
require_once '../../includes/db_connection.php';

if (!is_student()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$student_id = current_user()['id'];

if (!$input || !isset($input['exam_id']) || !isset($input['code'])) {
    echo json_encode(['success' => false, 'message' => 'بيانات غير مكتملة']);
    exit;
}

$exam_id = intval($input['exam_id']);
$code = sanitize_input($input['code']);

try {
    $pdo = get_db_connection();
    
    // التحقق من صحة الكود
    $code_stmt = $pdo->prepare("
        SELECT * FROM codes 
        WHERE exam_id = ? AND code_value = ? AND is_used = 0 AND is_active = 1
    ");
    $code_stmt->execute([$exam_id, $code]);
    $code_data = $code_stmt->fetch();

    if ($code_data) {
        // تفعيل الكود
        $pdo->beginTransaction();
        
        $update_stmt = $pdo->prepare("
            UPDATE codes SET is_used = 1, used_by_student_id = ?, used_at = NOW() 
            WHERE id = ?
        ");
        $update_stmt->execute([$student_id, $code_data['id']]);
        
        $pdo->commit();
        
        echo json_encode(['success' => true, 'message' => 'تم تفعيل الكود بنجاح']);
    } else {
        echo json_encode(['success' => false, 'message' => 'الكود غير صحيح أو تم استخدامه']);
    }
    
} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Error validating exam code: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'حدث خطأ أثناء التحقق من الكود']);
}
?>