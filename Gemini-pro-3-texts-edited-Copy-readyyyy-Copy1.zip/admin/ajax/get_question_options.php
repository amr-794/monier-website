<?php
require_once '../../includes/functions.php';
require_once '../../includes/db_connection.php';

if (!is_admin()) {
    http_response_code(401);
    echo json_encode(['error' => 'غير مصرح']);
    exit;
}

header('Content-Type: application/json');

$question_id = intval($_GET['question_id'] ?? 0);
if (!$question_id) {
    echo json_encode(['error' => 'معرف غير صحيح']);
    exit;
}

$pdo = get_db_connection();
$stmt = $pdo->prepare("SELECT * FROM exam_question_options WHERE question_id = ? ORDER BY sort_order, id");
$stmt->execute([$question_id]);
$options = $stmt->fetchAll();

echo json_encode($options);
?>