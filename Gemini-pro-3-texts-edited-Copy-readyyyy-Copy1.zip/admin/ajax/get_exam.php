<?php
require_once '../../includes/functions.php';
require_once '../../includes/db_connection.php';

if (!is_admin()) {
    http_response_code(401);
    echo json_encode(['error' => 'غير مصرح']);
    exit;
}

header('Content-Type: application/json');

$exam_id = intval($_GET['id'] ?? 0);
if (!$exam_id) {
    echo json_encode(['error' => 'معرف غير صحيح']);
    exit;
}

$pdo = get_db_connection();
$stmt = $pdo->prepare("SELECT * FROM exams WHERE id = ?");
$stmt->execute([$exam_id]);
$exam = $stmt->fetch();

if (!$exam) {
    echo json_encode(['error' => 'الاختبار غير موجود']);
    exit;
}

// تحويل التواريخ للتنسيق المناسب
$exam['start_date'] = $exam['start_date'] ? date('Y-m-d\TH:i', strtotime($exam['start_date'])) : '';
$exam['end_date'] = $exam['end_date'] ? date('Y-m-d\TH:i', strtotime($exam['end_date'])) : '';
$exam['results_schedule'] = $exam['results_schedule'] ? date('Y-m-d\TH:i', strtotime($exam['results_schedule'])) : '';

echo json_encode($exam);
?>