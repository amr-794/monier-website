<?php
require_once '../../includes/functions.php';
require_once '../../includes/db_connection.php';

if (!is_admin()) {
    http_response_code(401);
    echo json_encode(['error' => 'غير مصرح']);
    exit;
}

header('Content-Type: application/json');

$question_id = intval($_GET['id'] ?? 0);
if (!$question_id) {
    echo json_encode(['error' => 'معرف غير صحيح']);
    exit;
}

$pdo = get_db_connection();
$stmt = $pdo->prepare("SELECT * FROM exam_questions WHERE id = ?");
$stmt->execute([$question_id]);
$question = $stmt->fetch();

if (!$question) {
    echo json_encode(['error' => 'السؤال غير موجود']);
    exit;
}

echo json_encode($question);
?>