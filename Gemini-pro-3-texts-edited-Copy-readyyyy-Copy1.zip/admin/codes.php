<?php
$page_title = 'إدارة الأكواد';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
require_once __DIR__ . '/../includes/functions.php'; // تأكد من إضافة هذا السطر
$pdo = get_db_connection();

// معالجة إنشاء الأكواد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_codes'])) {
    $type = sanitize_input($_POST['type']);
    $target_id = intval($_POST['target_id']);
    $count = intval($_POST['count']);
    $custom_code = sanitize_input($_POST['custom_code'] ?? '');
    
    $codes_generated = 0;
    $generated_codes = [];
    
    for ($i = 0; $i < $count; $i++) {
        if (!empty($custom_code) && $i === 0) {
            // استخدام الكود المخصص
            $code_value = strtoupper($custom_code);
        } else {
            // إنشاء كود عشوائي
            $code_value = generate_random_code(8);
        }
        
        // التحقق من عدم تكرار الكود
        $check_stmt = $pdo->prepare("SELECT id FROM codes WHERE code_value = ?");
        $check_stmt->execute([$code_value]);
        
        if (!$check_stmt->fetch()) {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO codes (code_value, {$type}_id) 
                    VALUES (?, ?)
                ");
                $stmt->execute([$code_value, $target_id]);
                $codes_generated++;
                $generated_codes[] = $code_value;
            } catch (Exception $e) {
                // تجاهل الأخطاء الأخرى
                continue;
            }
        }
    }
    
    if ($codes_generated > 0) {
        $message = "<div class='alert alert-success'>تم إنشاء {$codes_generated} كود بنجاح.<br>";
        if (!empty($generated_codes)) {
            $message .= "الأكواد: " . implode(', ', $generated_codes) . "</div>";
        }
    } else {
        $message = "<div class='alert alert-danger'>لم يتم إنشاء أي أكواد. قد تكون الأكواد مكررة.</div>";
    }
}

// ... باقي الكود ...




// معالجة الحذف
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM codes WHERE id = ?");
    $stmt->execute([$id]);
    $message = "<div class='alert alert-danger'>تم حذف الكود.</div>";
}

// جلب البيانات
$lectures = $pdo->query("SELECT id, title FROM lectures WHERE is_active = 1 AND is_free = 0 ORDER BY title")->fetchAll();
$exams = $pdo->query("SELECT id, exam_id, title FROM exams WHERE is_active = 1 AND is_free = 0 ORDER BY title")->fetchAll();

// جلب الأكواد
$codes = $pdo->query("
    SELECT c.*, l.title as lecture_title, e.title as exam_title, 
           s.name as student_name, s.unique_student_id 
    FROM codes c 
    LEFT JOIN lectures l ON c.lecture_id = l.id 
    LEFT JOIN exams e ON c.exam_id = e.id 
    LEFT JOIN students s ON c.used_by_student_id = s.id 
    ORDER BY c.created_at DESC
")->fetchAll();
?>

<div class="page-header">
    <h1>إدارة الأكواد</h1>
</div>

<?= $message ?? '' ?>

<!-- نموذج إنشاء الأكواد -->
<div class="card mb-4">
    <div class="card-header">
        <h3>إنشاء أكواد جديدة</h3>
    </div>
    <div class="card-body">
        <form method="POST">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>النوع:</label>
                        <select name="type" id="code_type" class="form-control" onchange="toggleTarget()">
                            <option value="lecture_id">كود محاضرة</option>
                            <option value="exam_id">كود اختبار</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label id="target_label">المحاضرة:</label>
                        <select name="target_id" id="target_id" class="form-control" required>
                            <?php foreach ($lectures as $lecture): ?>
                            <option value="<?= $lecture['id'] ?>"><?= htmlspecialchars($lecture['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label>عدد الأكواد:</label>
                        <input type="number" name="count" value="1" min="1" max="100" class="form-control" required>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label>كود مخصص (اختياري):</label>
                        <input type="text" name="custom_code" class="form-control" placeholder="مثال: CODE123">
                        <small class="form-text text-muted">للكود الأول فقط</small>
                    </div>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" name="generate_codes" class="btn btn-primary">إنشاء الأكواد</button>
            </div>
        </form>
    </div>
</div>

<!-- قائمة الأكواد -->
<div class="card">
    <div class="card-header">
        <h3>الأكواد</h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>الكود</th>
                        <th>النوع</th>
                        <th>الهدف</th>
                        <th>الحالة</th>
                        <th>المستخدم</th>
                        <th>تاريخ الإنشاء</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($codes as $code): ?>
                    <tr>
                        <td>
                            <code><?= htmlspecialchars($code['code_value']) ?></code>
                            <?php if (!$code['is_active']): ?>
                                <br><small class="text-muted">(غير نشط)</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= $code['lecture_id'] ? 'محاضرة' : ($code['exam_id'] ? 'اختبار' : 'غير محدد') ?>
                        </td>
                        <td>
                            <?= $code['lecture_title'] ? htmlspecialchars($code['lecture_title']) : 
                               ($code['exam_title'] ? htmlspecialchars($code['exam_title']) : 'غير محدد') ?>
                        </td>
                        <td>
                            <span class="badge badge-<?= $code['is_used'] ? 'success' : ($code['is_active'] ? 'warning' : 'danger') ?>">
                                <?= $code['is_used'] ? 'مستخدم' : ($code['is_active'] ? 'نشط' : 'معطل') ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($code['used_by_student_id']): ?>
                                <?= htmlspecialchars($code['student_name']) ?>
                                <br><small class="text-muted"><?= $code['unique_student_id'] ?></small>
                                <br><small class="text-muted"><?= format_date($code['used_at']) ?></small>
                            <?php else: ?>
                                <span class="text-muted">لم يستخدم</span>
                            <?php endif; ?>
                        </td>
                        <td><?= format_date($code['created_at']) ?></td>
                        <td>
                            <?php if (!$code['is_used']): ?>
                            <a href="?delete=<?= $code['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('هل أنت متأكد من حذف الكود؟')">حذف</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function toggleTarget() {
    const type = document.getElementById('code_type').value;
    const targetSelect = document.getElementById('target_id');
    const targetLabel = document.getElementById('target_label');
    
    if (type === 'lecture_id') {
        targetLabel.textContent = 'المحاضرة:';
        targetSelect.innerHTML = `<?php foreach ($lectures as $lecture): ?>
            <option value="<?= $lecture['id'] ?>"><?= htmlspecialchars($lecture['title']) ?></option>
        <?php endforeach; ?>`;
    } else {
        targetLabel.textContent = 'الاختبار:';
        targetSelect.innerHTML = `<?php foreach ($exams as $exam): ?>
            <option value="<?= $exam['id'] ?>"><?= htmlspecialchars($exam['title']) ?></option>
        <?php endforeach; ?>`;
    }
}

function generate_random_code() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 8; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}
</script>

<?php include 'partials/footer.php'; ?>