<?php
$page_title = 'إعدادات النظام';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
$pdo = get_db_connection();

// جلب الإعدادات الحالية
$settings_stmt = $pdo->query("SELECT * FROM settings");
$settings = $settings_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// معالجة حفظ الإعدادات
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    foreach ($_POST['settings'] as $key => $value) {
        $stmt = $pdo->prepare("
            INSERT INTO settings (setting_name, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = ?
        ");
        
        if (is_array($value)) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE);
        }
        
        $stmt->execute([$key, $value, $value]);
    }
    
    $message = "<div class='alert alert-success'>تم حفظ الإعدادات بنجاح.</div>";
}
?>

<div class="page-header">
    <h1>إعدادات النظام</h1>
</div>

<?= $message ?? '' ?>

<form method="POST">
    <div class="card mb-4">
        <div class="card-header">
            <h3>إعدادات العرض</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <div class="form-check">
                    <input type="checkbox" name="settings[mobile_only_mode]" value="1" 
                           <?= $settings['mobile_only_mode'] ?? 0 ? 'checked' : '' ?> class="form-check-input">
                    <label class="form-check-label">تفعيل وضع الجوال فقط</label>
                    <small class="form-text text-muted">يمنع المستخدمين من مشاهدة المحتوى من أجهزة الكمبيوتر</small>
                </div>
            </div>
            
            <div class="form-group">
                <label>رسالة المتصفح:</label>
                <textarea name="settings[browser_message]" rows="4" class="form-control"><?= htmlspecialchars($settings['browser_message'] ?? '') ?></textarea>
                <small class="form-text text-muted">الرسالة التي تظهر للمستخدمين عند الدخول من متصفح كمبيوتر</small>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h3>إعدادات الاختبارات</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label>ظهور النتائج:</label>
                <select name="settings[exam_results_visibility]" class="form-control">
                    <option value="immediate" <?= ($settings['exam_results_visibility'] ?? 'immediate') === 'immediate' ? 'selected' : '' ?>>فوري</option>
                    <option value="scheduled" <?= ($settings['exam_results_visibility'] ?? 'immediate') === 'scheduled' ? 'selected' : '' ?>>مجدول</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>موعد ظهور النتائج (إذا كان مجدول):</label>
                <input type="datetime-local" name="settings[exam_results_schedule]" 
                       value="<?= $settings['exam_results_schedule'] ?? '' ?>" class="form-control">
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h3>روابط التطبيق</h3>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label>رابط تحميل Android (APK):</label>
                <input type="url" name="settings[app_apk_files][]" 
                       value="<?= htmlspecialchars(json_decode($settings['app_apk_files'] ?? '[]')[0] ?? '') ?>" 
                       class="form-control" placeholder="https://example.com/app.apk">
            </div>
            
            <div class="form-group">
                <label>رابط Google Play:</label>
                <input type="url" name="settings[app_download_links][]" 
                       value="<?= htmlspecialchars(json_decode($settings['app_download_links'] ?? '[]')[0] ?? '') ?>" 
                       class="form-control" placeholder="https://play.google.com/store/apps/details?id=com.example.app">
            </div>
            
            <div class="form-group">
                <label>رابط App Store:</label>
                <input type="url" name="settings[app_download_links][]" 
                       value="<?= htmlspecialchars(json_decode($settings['app_download_links'] ?? '[]')[1] ?? '') ?>" 
                       class="form-control" placeholder="https://apps.apple.com/app/id123456789">
            </div>
        </div>
    </div>

    <div class="form-actions">
        <button type="submit" name="save_settings" class="btn btn-success">حفظ الإعدادات</button>
    </div>
</form>

<?php include 'partials/footer.php'; ?>