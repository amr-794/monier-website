<?php
require_once '../includes/functions.php';
if (!is_admin()) redirect('../login.php');

$page_title = "تفعيل وضع الجوال فقط";
include 'partials/header.php';
$pdo = get_db_connection();

// جلب الإعداد الحالي
$mode_stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_name = 'mobile_only_mode'");
$mode_stmt->execute();
$current_mode = $mode_stmt->fetchColumn();

// معالجة التبديل
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_mode = intval($_POST['mobile_only_mode']);
    
    $stmt = $pdo->prepare("
        INSERT INTO settings (setting_name, setting_value) 
        VALUES ('mobile_only_mode', ?) 
        ON DUPLICATE KEY UPDATE setting_value = ?
    ");
    $stmt->execute([$new_mode, $new_mode]);
    
    $message = $new_mode ? 
        "<div class='alert alert-success'>تم تفعيل وضع الجوال فقط. سيتم منع المستخدمين من الدخول من المتصفح.</div>" :
        "<div class='alert alert-success'>تم تعطيل وضع الجوال فقط. يمكن للمستخدمين الدخول من جميع الأجهزة.</div>";
    
    $current_mode = $new_mode;
}
?>

<div class="page-header">
    <h1>تفعيل وضع الجوال فقط</h1>
</div>

<?= $message ?? '' ?>

<div class="card">
    <div class="card-header">
        <h3>حالة النظام الحالية</h3>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-8">
                <h4>الوضع الحالي: 
                    <span class="badge badge-<?= $current_mode ? 'danger' : 'success' ?>">
                        <?= $current_mode ? 'مفعل - الجوال فقط' : 'معطل - جميع الأجهزة' ?>
                    </span>
                </h4>
                
                <div class="alert alert-info mt-3">
                    <h5><i class="fas fa-info-circle"></i> معلومات حول وضع الجوال فقط:</h5>
                    <ul>
                        <li>عند التفعيل: يمنع المستخدمين من مشاهدة المحاضرات والاختبارات من متصفح الكمبيوتر</li>
                        <li>يظهر للمستخدمين رسالة توجيه لتحميل التطبيق</li>
                        <li>يسمح للأدمن بالدخول من جميع الأجهزة</li>
                        <li>يحسن أمان النظام ويقلل من مشاركة الحسابات</li>
                    </ul>
                </div>
            </div>
            
            <div class="col-md-4">
                <form method="POST" class="text-center">
                    <div class="form-group">
                        <label class="h5">تغيير وضع النظام:</label>
                        <div class="btn-group-vertical w-100">
                            <button type="submit" name="mobile_only_mode" value="1" 
                                    class="btn btn-<?= $current_mode ? 'danger' : 'outline-danger' ?> btn-lg">
                                <i class="fas fa-mobile-alt"></i> تفعيل وضع الجوال فقط
                            </button>
                            <button type="submit" name="mobile_only_mode" value="0" 
                                    class="btn btn-<?= !$current_mode ? 'success' : 'outline-success' ?> btn-lg mt-2">
                                <i class="fas fa-desktop"></i> تعطيل (جميع الأجهزة)
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="row mt-4">
            <div class="col-12">
                <h5>معاينة رسالة المتصفح:</h5>
                <div class="border rounded p-4 bg-light">
                    <?= $settings['browser_message'] ?? '<h2>المشاهدة من التطبيق فقط</h2><p>عذراً، لا يمكنك مشاهدة المحاضرة من المتصفح. يرجى تحميل التطبيق الخاص بنا للمتابعة.</p>' ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'partials/footer.php'; ?>