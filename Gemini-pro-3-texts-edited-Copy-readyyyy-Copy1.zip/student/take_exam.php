<?php
require_once '../includes/functions.php';
if (!is_student()) redirect('../login.php');

// تأكد من وجود المستخدم
$user = current_user();
if (!$user) {
    redirect('../login.php');
}

$exam_id = intval($_GET['exam_id'] ?? 0);
if (!$exam_id) die('معرف الاختبار مطلوب.');

$pdo = get_db_connection();
$student_id = $user['id'];

// التحقق من صلاحية الدخول للاختبار
$exam_stmt = $pdo->prepare("
    SELECT e.*, 
    (SELECT COUNT(*) FROM student_exam_attempts WHERE student_id = ? AND exam_id = e.id) as attempts_count
    FROM exams e 
    WHERE e.id = ? AND e.is_active = 1
    AND (e.start_date IS NULL OR e.start_date <= NOW())
    AND (e.end_date IS NULL OR e.end_date >= NOW())
");
$exam_stmt->execute([$student_id, $exam_id]);
$exam = $exam_stmt->fetch();

if (!$exam) die('الاختبار غير متوفر.');
if ($exam['attempts_count'] >= $exam['max_attempts']) die('لقد استنفذت عدد المحاولات المسموحة.');

// التحقق من الكود إذا كان الاختبار مدفوع
if (!$exam['is_free']) {
    $code_stmt = $pdo->prepare("
        SELECT * FROM codes 
        WHERE exam_id = ? AND used_by_student_id = ? AND is_used = 1
    ");
    $code_stmt->execute([$exam_id, $student_id]);
    if (!$code_stmt->fetch()) {
        die('يجب تفعيل الاختبار باستخدام كود أولاً.');
    }
}

// جلب الأسئلة
$questions_stmt = $pdo->prepare("
    SELECT eq.* 
    FROM exam_questions eq 
    WHERE eq.exam_id = ? 
    ORDER BY eq.sort_order, eq.id
");
$questions_stmt->execute([$exam_id]);
$questions = $questions_stmt->fetchAll();

// جلب التقدم السابق إن وجد
$progress_stmt = $pdo->prepare("
    SELECT * FROM student_exam_progress 
    WHERE student_id = ? AND exam_id = ?
");
$progress_stmt->execute([$student_id, $exam_id]);
$progress = $progress_stmt->fetch();

if (!$progress) {
    // بدء محاولة جديدة
    $time_remaining = $exam['time_limit_minutes'] * 60;
    $progress_stmt = $pdo->prepare("
        INSERT INTO student_exam_progress (student_id, exam_id, time_remaining_seconds, current_question, answers_json) 
        VALUES (?, ?, ?, 1, '{}')
    ");
    $progress_stmt->execute([$student_id, $exam_id, $time_remaining]);
} else {
    // استخدام الوقت المتبقي من الجلسة السابقة
    $time_remaining = $progress['time_remaining_seconds'];
    
    // إذا انتهى الوقت، ابدأ من جديد
    if ($time_remaining <= 0) {
        $time_remaining = $exam['time_limit_minutes'] * 60;
        $update_stmt = $pdo->prepare("
            UPDATE student_exam_progress SET time_remaining_seconds = ? 
            WHERE student_id = ? AND exam_id = ?
        ");
        $update_stmt->execute([$time_remaining, $student_id, $exam_id]);
    }
}

// جلب الخيارات لكل سؤال
foreach ($questions as &$question) {
    $options_stmt = $pdo->prepare("
        SELECT * FROM exam_question_options 
        WHERE question_id = ? 
        ORDER BY sort_order, id
    ");
    $options_stmt->execute([$question['id']]);
    $question['options'] = $options_stmt->fetchAll();
}
unset($question);

$current_question = $progress['current_question'] ?? 1;
$answers_json = $progress['answers_json'] ? json_decode($progress['answers_json'], true) : [];
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اختبار: <?= htmlspecialchars($exam['title']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* نفس الستايل السابق */

         .exam-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background: #f8f9fa;
            min-height: 100vh;
        }
        
        .exam-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .exam-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
        }
        
        .exam-timer {
            background: #dc3545;
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 1.2rem;
            font-weight: bold;
        }
        
        .question-nav {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .question-numbers {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
        }
        
        .question-number {
            width: 40px;
            height: 40px;
            border: 2px solid #ddd;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        
        .question-number.current {
            border-color: #007bff;
            background: #007bff;
            color: white;
        }
        
        .question-number.answered {
            border-color: #28a745;
            background: #28a745;
            color: white;
        }
        
        .question-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .question-text {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 20px;
            line-height: 1.6;
        }
        
        .question-image {
            max-width: 100%;
            max-height: 400px;
            margin-bottom: 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: transform 0.3s ease;
        }
        
        .question-image:hover {
            transform: scale(1.02);
        }
        
        .options-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .option-label {
            display: flex;
            align-items: center;
            padding: 15px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .option-label:hover {
            border-color: #007bff;
            background: #f8f9ff;
        }
        
        .option-label.selected {
            border-color: #007bff;
            background: #e7f3ff;
        }
        
        .option-input {
            margin-left: 15px;
        }
        
        .option-text {
            flex: 1;
            font-size: 1.1rem;
        }
        
        .exam-footer {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-buttons {
            display: flex;
            gap: 10px;
        }
        
        .image-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .image-modal img {
            max-width: 90%;
            max-height: 90%;
            border-radius: 10px;
        }
        
        .close-modal {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            font-size: 2rem;
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .exam-header {
                flex-direction: column;
                gap: 15px;
            }
            
            .question-numbers {
                gap: 5px;
            }
            
            .question-number {
                width: 35px;
                height: 35px;
                font-size: 0.9rem;
            }
            
            .question-card {
                padding: 20px;
            }
            
            .exam-footer {
                flex-direction: column;
                gap: 15px;
            }
            
            .nav-buttons {
                width: 100%;
                justify-content: space-between;
            }
        }
    </style>
</head>
<body>
    <!-- نفس المحتوى السابق -->

    <div class="exam-container">
        <!-- رأس الاختبار -->
        <div class="exam-header">
            <div class="exam-title"><?= htmlspecialchars($exam['title']) ?></div>
            <div class="exam-timer" id="timer">--:--</div>
        </div>
        
        <!-- تنقل بين الأسئلة -->
        <div class="question-nav">
            <div class="question-numbers" id="questionNumbers">
                <?php foreach ($questions as $index => $question): ?>
                <div class="question-number <?= ($index + 1) == $current_question ? 'current' : '' ?> <?= isset($answers_json[$question['id']]) ? 'answered' : '' ?>" 
                     data-question="<?= $index + 1 ?>">
                    <?= $index + 1 ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- السؤال الحالي -->
        <div class="question-card">
            <?php if ($current_question <= count($questions)): ?>
            <?php $question = $questions[$current_question - 1]; ?>
            <div class="question-text"><?= nl2br(htmlspecialchars($question['question_text'])) ?></div>
            
            <?php if ($question['question_image']): ?>
            <img src="../<?= $question['question_image'] ?>" 
                 alt="صورة السؤال" 
                 class="question-image"
                 onclick="openImageModal(this.src)">
            <?php endif; ?>
            
            <div class="options-list">
                <?php foreach ($question['options'] as $option): ?>
                <label class="option-label <?= in_array($option['id'], $answers_json[$question['id']] ?? []) ? 'selected' : '' ?>">
                    <input type="<?= $question['question_type'] == 'multiple' ? 'checkbox' : 'radio' ?>" 
                           name="question_<?= $question['id'] ?>" 
                           value="<?= $option['id'] ?>" 
                           class="option-input"
                           <?= in_array($option['id'], $answers_json[$question['id']] ?? []) ? 'checked' : '' ?>
                           onchange="saveAnswer(<?= $question['id'] ?>, <?= $option['id'] ?>, this.checked, '<?= $question['question_type'] ?>')">
                    <span class="option-text"><?= htmlspecialchars($option['option_text']) ?></span>
                </label>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center">
                <h3>تم الانتهاء من جميع الأسئلة</h3>
                <p>يمكنك مراجعة إجاباتك أو تسليم الاختبار</p>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- تذييل الاختبار -->
        <div class="exam-footer">
            <div class="nav-buttons">
                <button class="btn btn-secondary" onclick="previousQuestion()" <?= $current_question <= 1 ? 'disabled' : '' ?>>
                    <i class="fas fa-arrow-right"></i> السابق
                </button>
                <button class="btn btn-primary" onclick="nextQuestion()" <?= $current_question >= count($questions) ? 'disabled' : '' ?>>
                    التالي <i class="fas fa-arrow-left"></i>
                </button>
            </div>
            <button class="btn btn-success" onclick="submitExam()">
                <i class="fas fa-paper-plane"></i> تسليم الاختبار
            </button>
        </div>
    </div>
    
    <!-- مودال عرض الصورة -->
    <div class="image-modal" id="imageModal" onclick="closeImageModal()">
        <span class="close-modal">&times;</span>
        <img id="modalImage" src="" alt="صورة مكبرة">
    </div>
    
    <script>
        const EXAM_DATA = {
            examId: <?= $exam_id ?>,
            timeRemaining: <?= $time_remaining ?>,
            totalQuestions: <?= count($questions) ?>,
            currentQuestion: <?= $current_question ?>,
            studentId: <?= $student_id ?>
        };
        
        let answers = <?= json_encode($answers_json) ?>;
        let timerInterval;
        
        // بدء العد التنازلي
        function startTimer() {
            updateTimerDisplay();
            timerInterval = setInterval(() => {
                EXAM_DATA.timeRemaining--;
                updateTimerDisplay();
                
                if (EXAM_DATA.timeRemaining <= 0) {
                    clearInterval(timerInterval);
                    submitExam();
                }
                
                // حفظ الوقت كل 30 ثانية
                if (EXAM_DATA.timeRemaining % 30 === 0) {
                    saveProgress();
                }
            }, 1000);
        }
        
        function updateTimerDisplay() {
            const minutes = Math.floor(EXAM_DATA.timeRemaining / 60);
            const seconds = EXAM_DATA.timeRemaining % 60;
            document.getElementById('timer').textContent = 
                `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            // تغيير اللون عندما يقل الوقت عن 5 دقائق
            if (EXAM_DATA.timeRemaining < 300) {
                document.getElementById('timer').style.background = '#dc3545';
            }
        }
        
        // حفظ الإجابة
        function saveAnswer(questionId, optionId, isChecked, questionType) {
            if (!answers[questionId]) {
                answers[questionId] = [];
            }
            
            if (questionType === 'single') {
                answers[questionId] = isChecked ? [optionId] : [];
            } else {
                if (isChecked) {
                    if (!answers[questionId].includes(optionId)) {
                        answers[questionId].push(optionId);
                    }
                } else {
                    answers[questionId] = answers[questionId].filter(id => id !== optionId);
                }
            }
            
            // تحديث مظهر الزر
            updateQuestionNumber(EXAM_DATA.currentQuestion);
            saveProgress();
        }
        
        // حفظ التقدم
        function saveProgress() {
            fetch('../api/save_exam_progress.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    exam_id: EXAM_DATA.examId,
                    time_remaining: EXAM_DATA.timeRemaining,
                    current_question: EXAM_DATA.currentQuestion,
                    answers: answers
                })
            }).catch(error => console.error('Error saving progress:', error));
        }
        
        // التنقل بين الأسئلة
        function goToQuestion(questionNumber) {
            EXAM_DATA.currentQuestion = questionNumber;
            saveProgress();
            window.location.href = `?exam_id=<?= $exam_id ?>&question=${questionNumber}`;
        }
        
        function nextQuestion() {
            if (EXAM_DATA.currentQuestion < EXAM_DATA.totalQuestions) {
                goToQuestion(EXAM_DATA.currentQuestion + 1);
            }
        }
        
        function previousQuestion() {
            if (EXAM_DATA.currentQuestion > 1) {
                goToQuestion(EXAM_DATA.currentQuestion - 1);
            }
        }
        
        // تحديث مظهر أرقام الأسئلة
        function updateQuestionNumber(questionNumber) {
            const questionNumbers = document.querySelectorAll('.question-number');
            questionNumbers.forEach((num, index) => {
                num.classList.remove('current');
                if (index + 1 === questionNumber) {
                    num.classList.add('current');
                }
                
                const questionId = <?= json_encode(array_column($questions, 'id')) ?>[index];
                if (answers[questionId] && answers[questionId].length > 0) {
                    num.classList.add('answered');
                } else {
                    num.classList.remove('answered');
                }
            });
        }
        
        // إدارة الصور
        function openImageModal(src) {
            document.getElementById('modalImage').src = src;
            document.getElementById('imageModal').style.display = 'flex';
        }
        
        function closeImageModal() {
            document.getElementById('imageModal').style.display = 'none';
        }
        
        // تسليم الاختبار
        function submitExam() {
            if (confirm('هل أنت متأكد من تسليم الاختبار؟ لا يمكنك العودة بعد التسليم.')) {
                clearInterval(timerInterval);
                
                fetch('../api/submit_exam.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        exam_id: EXAM_DATA.examId,
                        answers: answers,
                        time_spent: <?= $exam['time_limit_minutes'] * 60 ?> - EXAM_DATA.timeRemaining
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        window.location.href = 'exam_result.php?attempt_id=' + data.attempt_id;
                    } else {
                        alert('حدث خطأ أثناء تسليم الاختبار: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('حدث خطأ أثناء تسليم الاختبار');
                });
            }
        }
        
        // الأحداث
        document.addEventListener('DOMContentLoaded', function() {
            startTimer();
            
            // إضافة حدث النقر على أرقام الأسئلة
            document.querySelectorAll('.question-number').forEach((num, index) => {
                num.addEventListener('click', () => goToQuestion(index + 1));
            });
            
            // منع إعادة تحميل الصفحة
            window.addEventListener('beforeunload', function(e) {
                if (EXAM_DATA.timeRemaining > 0) {
                    e.preventDefault();
                    e.returnValue = 'هل تريد حقاً مغادرة الصفحة؟ ستفقد تقدمك الحالي.';
                    return e.returnValue;
                }
            });
        });
    </script>
</body>
</html>