<?php
require_once '../includes/functions.php';
if (!is_student()) redirect('../login.php');

$page_title = "الاختبارات الشاملة";
include 'partials/header.php';
$pdo = get_db_connection();
$student_id = $user['id'];
$student_grade = $user['grade'];

// جلب الاختبارات المتاحة للطالب
$exams_stmt = $pdo->prepare("
    SELECT e.*, 
    (SELECT COUNT(*) FROM exam_questions WHERE exam_id = e.id) as questions_count,
    (SELECT COUNT(*) FROM student_exam_attempts WHERE student_id = ? AND exam_id = e.id) as attempts_count
    FROM exams e 
    WHERE e.is_active = 1 
    AND (e.grade = 'all' OR e.grade = ?)
    AND (e.start_date IS NULL OR e.start_date <= NOW())
    AND (e.end_date IS NULL OR e.end_date >= NOW())
    ORDER BY e.created_at DESC
");
$exams_stmt->execute([$student_id, $student_grade]);
$available_exams = $exams_stmt->fetchAll();

// جلب نتائج الاختبارات
$results_stmt = $pdo->prepare("
    SELECT r.*, e.title as exam_title, e.exam_id
    FROM student_exam_results r 
    JOIN exams e ON r.exam_id = e.id 
    WHERE r.student_id = ? AND r.is_visible = 1
    ORDER BY r.completed_at DESC
");
$results_stmt->execute([$student_id]);
$exam_results = $results_stmt->fetchAll();
?>

<div class="page-header">
    <h1>الاختبارات الشاملة</h1>
</div>

<!-- قسم الاختبارات المتاحة -->
<div class="card mb-4">
    <div class="card-header">
        <h3>الاختبارات المتاحة</h3>
    </div>
    <div class="card-body">
        <?php if (empty($available_exams)): ?>
            <div class="alert alert-info">لا توجد اختبارات متاحة حالياً.</div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($available_exams as $exam): ?>
                <div class="col-md-6 mb-3">
                    <div class="card exam-card">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($exam['title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($exam['description']) ?></p>
                            <div class="exam-details">
                                <small class="text-muted">
                                    <i class="fas fa-clock"></i> <?= $exam['time_limit_minutes'] ?> دقيقة
                                </small>
                                <small class="text-muted">
                                    <i class="fas fa-question-circle"></i> <?= $exam['questions_count'] ?> سؤال
                                </small>
                                <small class="text-muted">
                                    <i class="fas fa-redo"></i> <?= $exam['attempts_count'] ?>/<?= $exam['max_attempts'] ?> محاولة
                                </small>
                            </div>
                            <div class="exam-actions mt-3">
                                <?php if ($exam['attempts_count'] < $exam['max_attempts']): ?>
                                    <?php if ($exam['is_free']): ?>
                                        <a href="take_exam.php?exam_id=<?= $exam['id'] ?>" class="btn btn-primary">بدء الاختبار</a>
                                    <?php else: ?>
                                        <button class="btn btn-warning" onclick="showCodeModal(<?= $exam['id'] ?>)">أدخل الكود</button>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <button class="btn btn-secondary" disabled>تم الانتهاء من المحاولات</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- قسم نتائج الاختبارات -->
<div class="card">
    <div class="card-header">
        <h3>نتائج الاختبارات</h3>
    </div>
    <div class="card-body">
        <?php if (empty($exam_results)): ?>
            <div class="alert alert-info">لا توجد نتائج متاحة حالياً.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>اسم الاختبار</th>
                            <th>الدرجة</th>
                            <th>النسبة</th>
                            <th>الوقت المستغرق</th>
                            <th>تاريخ الإكمال</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($exam_results as $result): ?>
                        <tr>
                            <td><?= htmlspecialchars($result['exam_title']) ?></td>
                            <td><?= $result['score'] ?>/<?= $result['total_questions'] ?></td>
                            <td>
                                <span class="badge badge-<?= get_percentage_color($result['percentage']) ?>">
                                    <?= $result['percentage'] ?>%
                                </span>
                            </td>
                            <td><?= format_time($result['time_spent']) ?></td>
                            <td><?= format_date($result['completed_at']) ?></td>
                            <td>
                                <button class="btn btn-info btn-sm" onclick="viewResultDetails(<?= $result['id'] ?>)">عرض التفاصيل</button>
                                <button class="btn btn-success btn-sm" onclick="printResult(<?= $result['id'] ?>)">طباعة</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- مودال إدخال الكود -->
<div class="modal fade" id="codeModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">أدخل كود الدخول</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="codeForm">
                    <input type="hidden" id="exam_id_input">
                    <div class="form-group">
                        <label>كود الدخول:</label>
                        <input type="text" id="exam_code" class="form-control" required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="validateCode()">بدء الاختبار</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">إلغاء</button>
            </div>
        </div>
    </div>
</div>

<script>
function showCodeModal(examId) {
    document.getElementById('exam_id_input').value = examId;
    $('#codeModal').modal('show');
}

function validateCode() {
    const examId = document.getElementById('exam_id_input').value;
    const code = document.getElementById('exam_code').value;
    
    fetch('ajax/validate_exam_code.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({exam_id: examId, code: code})
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = `take_exam.php?exam_id=${examId}`;
        } else {
            alert(data.message || 'كود غير صحيح');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('حدث خطأ أثناء التحقق من الكود');
    });
}

function viewResultDetails(resultId) {
    window.open(`exam_result.php?result_id=${resultId}`, '_blank');
}

function printResult(resultId) {
    const printWindow = window.open(`print_result.php?result_id=${resultId}`, '_blank');
    printWindow.onload = function() {
        printWindow.print();
    };
}
</script>

<?php include 'partials/footer.php'; ?>