<?php
require_once '../includes/functions.php';
if (!is_student()) redirect('../login.php');

// تأكد من وجود المستخدم
$user = current_user();
if (!$user) {
    redirect('../login.php');
}

$result_id = intval($_GET['result_id'] ?? 0);
if (!$result_id) die('معرف النتيجة مطلوب.');

$pdo = get_db_connection();
$student_id = $user['id'];

// جلب بيانات النتيجة
$result_stmt = $pdo->prepare("
    SELECT r.*, s.name as student_name, s.unique_student_id, s.grade,
           e.title as exam_title, e.exam_id, e.time_limit_minutes
    FROM student_exam_results r 
    JOIN students s ON r.student_id = s.id 
    JOIN exams e ON r.exam_id = e.id 
    WHERE r.id = ? AND r.student_id = ?
");
$result_stmt->execute([$result_id, $student_id]);
$result = $result_stmt->fetch();

if (!$result) die('النتيجة غير موجودة.');
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>طباعة نتيجة الاختبار - <?= htmlspecialchars($result['exam_title']) ?></title>
    <style>
        @media print {
            @page {
                size: A4;
                margin: 20mm;
            }
            
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                line-height: 1.6;
                color: #333;
                background: white;
            }
            
            .no-print {
                display: none !important;
            }
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 210mm;
            margin: 0 auto;
            padding: 20px;
            background: #f8f9fa;
        }
        
        .print-header {
            text-align: center;
            border-bottom: 3px double #333;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .print-title {
            font-size: 24px;
            font-weight: bold;
            color: #2c5e8e;
            margin-bottom: 10px;
        }
        
        .print-subtitle {
            font-size: 18px;
            color: #666;
        }
        
        .student-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            border-right: 4px solid #2c5e8e;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e9ecef;
        }
        
        .info-label {
            font-weight: bold;
            color: #555;
        }
        
        .info-value {
            color: #333;
        }
        
        .result-summary {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
        }
        
        .score-display {
            font-size: 48px;
            font-weight: bold;
            margin: 20px 0;
        }
        
        .score-excellent { color: #28a745; }
        .score-good { color: #17a2b8; }
        .score-average { color: #ffc107; }
        .score-poor { color: #dc3545; }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }
        
        .stat-card {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #2c5e8e;
        }
        
        .stat-label {
            color: #666;
            margin-top: 5px;
        }
        
        .grade-badge {
            display: inline-block;
            background: #2c5e8e;
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 18px;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .footer {
            text-align: center;
            margin-top: 50px;
            padding-top: 20px;
            border-top: 2px solid #e9ecef;
            color: #666;
        }
        
        .signature-area {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
        }
        
        .signature-line {
            border-top: 1px solid #333;
            width: 200px;
            text-align: center;
            padding-top: 5px;
        }
        
        .watermark {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 80px;
            color: rgba(0,0,0,0.1);
            z-index: -1;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <!-- علامة مائية -->
    <div class="watermark"><?= SITE_NAME ?></div>
    
    <!-- رأس الطباعة -->
    <div class="print-header">
        <div class="print-title">شهادة نتيجة الاختبار</div>
        <div class="print-subtitle">منصة <?= SITE_NAME ?></div>
    </div>
    
    <!-- معلومات الطالب -->
    <div class="student-info">
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">اسم الطالب:</span>
                <span class="info-value"><?= htmlspecialchars($result['student_name']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">رقم الطالب:</span>
                <span class="info-value"><?= $result['unique_student_id'] ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">الصف الدراسي:</span>
                <span class="info-value"><?= get_grade_text($result['grade']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">اسم الاختبار:</span>
                <span class="info-value"><?= htmlspecialchars($result['exam_title']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">معرف الاختبار:</span>
                <span class="info-value"><?= $result['exam_id'] ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">تاريخ الاختبار:</span>
                <span class="info-value"><?= format_date($result['completed_at'], 'Y-m-d') ?></span>
            </div>
        </div>
    </div>
    
    <!-- ملخص النتيجة -->
    <div class="result-summary">
        <div class="score-display <?= get_percentage_color_class($result['percentage']) ?>">
            <?= $result['score'] ?>/<?= $result['total_questions'] ?>
        </div>
        
        <div class="grade-badge">
            النسبة: <?= $result['percentage'] ?>%
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?= $result['score'] ?></div>
                <div class="stat-label">الدرجة</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $result['total_questions'] ?></div>
                <div class="stat-label">إجمالي الأسئلة</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= $result['percentage'] ?>%</div>
                <div class="stat-label">النسبة المئوية</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= format_time($result['time_spent']) ?></div>
                <div class="stat-label">الوقت المستغرق</div>
            </div>
        </div>
        
        <div class="grade-badge" style="background: #28a745;">
            التقدير: <?= get_grade_from_percentage($result['percentage']) ?>
        </div>
    </div>
    
    <!-- التوقيعات -->
    <div class="signature-area">
        <div class="signature-line">
            توقيع الطالب<br>
            ...........................
        </div>
        <div class="signature-line">
            ختم المدرسة<br>
            ...........................
        </div>
    </div>
    
    <!-- التذييل -->
    <div class="footer">
        <p>تم إصدار هذه الشهادة electronically من قبل <?= SITE_NAME ?></p>
        <p>تاريخ الإصدار: <?= date('Y-m-d H:i') ?></p>
        <p>رقم المرجع: RES<?= $result['id'] . '-' . $result['attempt_id'] ?></p>
    </div>
    
    <!-- أزرار التحكم (لا تطبع) -->
    <div class="no-print" style="text-align: center; margin-top: 30px;">
        <button onclick="window.print()" class="btn btn-primary">
            <i class="fas fa-print"></i> طباعة
        </button>
        <button onclick="window.close()" class="btn btn-secondary">
            <i class="fas fa-times"></i> إغلاق
        </button>
    </div>
    
    <script>
        // الطباعة التلقائية
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>

<?php
/**
 * دالة مساعدة: الحصول على كلاس اللون للنسبة
 */
function get_percentage_color_class($percentage) {
    if ($percentage >= 85) return 'score-excellent';
    if ($percentage >= 70) return 'score-good';
    if ($percentage >= 50) return 'score-average';
    return 'score-poor';
}

/**
 * دالة مساعدة: الحصول على التقدير
 */
function get_grade_from_percentage($percentage) {
    if ($percentage >= 90) return 'ممتاز';
    if ($percentage >= 80) return 'جيد جداً';
    if ($percentage >= 70) return 'جيد';
    if ($percentage >= 60) return 'مقبول';
    return 'راسب';
}
?>