<?php
require_once '../includes/functions.php';
if (!is_student()) redirect('../login.php');

// تأكد من وجود المستخدم
$user = current_user();
if (!$user) {
    redirect('../login.php');
}

$attempt_id = intval($_GET['attempt_id'] ?? 0);
if (!$attempt_id) die('معرف المحاولة مطلوب.');

$pdo = get_db_connection();
$student_id = $user['id'];

// جلب بيانات المحاولة
$attempt_stmt = $pdo->prepare("
    SELECT a.*, e.title as exam_title, e.exam_id, r.is_visible 
    FROM student_exam_attempts a 
    JOIN exams e ON a.exam_id = e.id 
    LEFT JOIN student_exam_results r ON a.id = r.attempt_id 
    WHERE a.id = ? AND a.student_id = ?
");
$attempt_stmt->execute([$attempt_id, $student_id]);
$attempt = $attempt_stmt->fetch();

if (!$attempt) die('المحاولة غير موجودة.');

// جلب الإجابات التفصيلية
$answers_stmt = $pdo->prepare("
    SELECT sea.*, eq.question_text, eq.question_image, eq.question_type 
    FROM student_exam_answers sea 
    JOIN exam_questions eq ON sea.question_id = eq.id 
    WHERE sea.attempt_id = ? 
    ORDER BY eq.sort_order, eq.id
");
$answers_stmt->execute([$attempt_id]);
$answers = $answers_stmt->fetchAll();

// جلب الخيارات لكل سؤال
foreach ($answers as &$answer) {
    $options_stmt = $pdo->prepare("
        SELECT eqo.* 
        FROM exam_question_options eqo 
        WHERE eqo.question_id = ? 
        ORDER BY eqo.sort_order, eqo.id
    ");
    $options_stmt->execute([$answer['question_id']]);
    $answer['options'] = $options_stmt->fetchAll();
    
    $answer['selected_options'] = json_decode($answer['selected_options'], true) ?: [];
}
unset($answer);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نتيجة الاختبار - <?= htmlspecialchars($attempt['exam_title']) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* نفس الستايل السابق - محفوظ للاختصار */
        .result-container { max-width: 1000px; margin: 0 auto; padding: 20px; background: #f8f9fa; min-height: 100vh; }
        .result-header { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center; margin-bottom: 30px; }
        .result-title { font-size: 2rem; font-weight: bold; color: #333; margin-bottom: 10px; }
        .result-score { font-size: 3rem; font-weight: bold; margin: 20px 0; }
        .score-excellent { color: #28a745; } .score-good { color: #17a2b8; } .score-average { color: #ffc107; } .score-poor { color: #dc3545; }
        .result-details { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 30px 0; }
        .detail-card { background: #f8f9fa; padding: 20px; border-radius: 10px; text-align: center; }
        .detail-value { font-size: 1.5rem; font-weight: bold; color: #333; }
        .detail-label { color: #666; margin-top: 5px; }
        .answers-section { background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin-bottom: 30px; }
        .section-title { font-size: 1.5rem; font-weight: bold; margin-bottom: 20px; color: #333; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px; }
        .question-card { border: 2px solid #e9ecef; border-radius: 10px; padding: 25px; margin-bottom: 25px; transition: all 0.3s ease; }
        .question-card.correct { border-color: #28a745; background: #f8fff9; }
        .question-card.incorrect { border-color: #dc3545; background: #fff8f8; }
        .question-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
        .question-text { flex: 1; font-size: 1.1rem; font-weight: 600; line-height: 1.6; }
        .question-status { padding: 8px 15px; border-radius: 20px; font-weight: bold; font-size: 0.9rem; margin-right: 15px; }
        .status-correct { background: #28a745; color: white; } .status-incorrect { background: #dc3545; color: white; }
        .question-image { max-width: 100%; max-height: 300px; border-radius: 8px; margin: 15px 0; cursor: pointer; }
        .options-list { display: flex; flex-direction: column; gap: 12px; }
        .option-item { padding: 15px; border-radius: 8px; border: 2px solid #e9ecef; display: flex; align-items: center; gap: 12px; }
        .option-item.correct { border-color: #28a745; background: #d4edda; } .option-item.incorrect { border-color: #dc3545; background: #f8d7da; }
        .option-item.selected { border-color: #007bff; background: #e7f3ff; }
        .option-marker { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 0.8rem; }
        .marker-correct { background: #28a745; color: white; } .marker-incorrect { background: #dc3545; color: white; }
        .marker-selected { background: #007bff; color: white; } .marker-normal { background: #6c757d; color: white; }
        .option-text { flex: 1; font-size: 1rem; }
        .result-actions { background: white; padding: 20px; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); display: flex; justify-content: center; gap: 15px; flex-wrap: wrap; }
        .image-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 1000; align-items: center; justify-content: center; }
        .image-modal img { max-width: 90%; max-height: 90%; border-radius: 10px; }
        .close-modal { position: absolute; top: 20px; left: 20px; color: white; font-size: 2rem; cursor: pointer; }
        @media (max-width: 768px) { .result-details { grid-template-columns: 1fr; } .question-header { flex-direction: column; gap: 10px; } .question-status { align-self: flex-start; } .result-actions { flex-direction: column; } }
        .print-only { display: none; }
        @media print { .no-print { display: none; } .print-only { display: block; } .result-container { background: white; padding: 0; } .result-header, .answers-section { box-shadow: none; border: 1px solid #ddd; } .question-card { break-inside: avoid; } }
    </style>
</head>
<body>
    <div class="result-container">
        <!-- رأس النتيجة -->
        <div class="result-header">
            <h1 class="result-title">نتيجة اختبار: <?= htmlspecialchars($attempt['exam_title']) ?></h1>
            
            <div class="result-score <?= get_percentage_color_class($attempt['percentage']) ?>">
                <?= $attempt['score'] ?>/<?= $attempt['total_questions'] ?> 
                (<?= $attempt['percentage'] ?>%)
            </div>
            
            <div class="result-details">
                <div class="detail-card">
                    <div class="detail-value"><?= $attempt['percentage'] ?>%</div>
                    <div class="detail-label">النسبة المئوية</div>
                </div>
                <div class="detail-card">
                    <div class="detail-value"><?= format_time($attempt['time_spent']) ?></div>
                    <div class="detail-label">الوقت المستغرق</div>
                </div>
                <div class="detail-card">
                    <div class="detail-value"><?= format_date($attempt['completed_at']) ?></div>
                    <div class="detail-label">تاريخ الإكمال</div>
                </div>
                <div class="detail-card">
                    <div class="detail-value"><?= get_grade_from_percentage($attempt['percentage']) ?></div>
                    <div class="detail-label">التقدير</div>
                </div>
            </div>
        </div>
        
        <!-- الإجابات التفصيلية -->
        <div class="answers-section">
            <h2 class="section-title">تفاصيل الإجابات</h2>
            
            <?php foreach ($answers as $index => $answer): ?>
            <div class="question-card <?= $answer['is_correct'] ? 'correct' : 'incorrect' ?>">
                <div class="question-header">
                    <div class="question-text">
                        <strong>السؤال <?= $index + 1 ?>:</strong> 
                        <?= nl2br(htmlspecialchars($answer['question_text'])) ?>
                    </div>
                    <div class="question-status <?= $answer['is_correct'] ? 'status-correct' : 'status-incorrect' ?>">
                        <?= $answer['is_correct'] ? 'إجابة صحيحة' : 'إجابة خاطئة' ?>
                    </div>
                </div>
                
                <?php if ($answer['question_image']): ?>
                <img src="../<?= $answer['question_image'] ?>" 
                     alt="صورة السؤال" 
                     class="question-image"
                     onclick="openImageModal(this.src)">
                <?php endif; ?>
                
                <div class="options-list">
                    <?php foreach ($answer['options'] as $option): ?>
                    <?php
                    $is_selected = in_array($option['id'], $answer['selected_options']);
                    $is_correct_option = $option['is_correct'];
                    $marker_class = '';
                    
                    if ($is_correct_option) {
                        $marker_class = 'marker-correct';
                    } elseif ($is_selected && !$is_correct_option) {
                        $marker_class = 'marker-incorrect';
                    } elseif ($is_selected) {
                        $marker_class = 'marker-selected';
                    } else {
                        $marker_class = 'marker-normal';
                    }
                    ?>
                    <div class="option-item <?= $is_selected ? 'selected' : '' ?> <?= $is_correct_option ? 'correct' : '' ?>">
                        <div class="option-marker <?= $marker_class ?>">
                            <?= $is_correct_option ? '✓' : ($is_selected ? '✗' : '') ?>
                        </div>
                        <div class="option-text"><?= htmlspecialchars($option['option_text']) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- أزرار الإجراءات -->
        <div class="result-actions no-print">
            <button class="btn btn-primary" onclick="window.print()">
                <i class="fas fa-print"></i> طباعة النتيجة
            </button>
            <a href="exams.php" class="btn btn-secondary">
                <i class="fas fa-arrow-right"></i> العودة للاختبارات
            </a>
            <a href="index.php" class="btn btn-info">
                <i class="fas fa-home"></i> الصفحة الرئيسية
            </a>
        </div>
    </div>
    
    <!-- مودال عرض الصورة -->
    <div class="image-modal" id="imageModal" onclick="closeImageModal()">
        <span class="close-modal">&times;</span>
        <img id="modalImage" src="" alt="صورة مكبرة">
    </div>
    
    <script>
        function openImageModal(src) {
            document.getElementById('modalImage').src = src;
            document.getElementById('imageModal').style.display = 'flex';
        }
        
        function closeImageModal() {
            document.getElementById('imageModal').style.display = 'none';
        }
        
        // الطباعة التلقائية إذا طلب المستخدم
        <?php if (isset($_GET['print']) && $_GET['print'] == '1'): ?>
        window.onload = function() {
            window.print();
        };
        <?php endif; ?>
    </script>
</body>
</html>

<?php
/**
 * دالة مساعدة: الحصول على كلاس اللون للنسبة
 */
function get_percentage_color_class($percentage) {
    if ($percentage >= 85) return 'score-excellent';
    if ($percentage >= 70) return 'score-good';
    if ($percentage >= 50) return 'score-average';
    return 'score-poor';
}

/**
 * دالة مساعدة: الحصول على التقدير
 */
function get_grade_from_percentage($percentage) {
    if ($percentage >= 90) return 'ممتاز';
    if ($percentage >= 80) return 'جيد جداً';
    if ($percentage >= 70) return 'جيد';
    if ($percentage >= 60) return 'مقبول';
    return 'راسب';
}
?>