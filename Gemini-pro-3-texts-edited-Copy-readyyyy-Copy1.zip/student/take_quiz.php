<?php
require_once '../includes/functions.php';
if (!is_student()) redirect('../login.php');

$user = current_user();
$quiz_id = intval($_GET['id'] ?? 0);
if (!$quiz_id) die('معرف الاختبار مطلوب.');

require_once '../includes/db_connection.php';
$pdo = get_db_connection();
$user_id = $user['id'];

$quiz = $pdo->prepare("SELECT q.*, l.title as lecture_title FROM quizzes q JOIN lectures l ON q.lecture_id = l.id WHERE q.id = ? AND q.is_active = 1");
$quiz->execute([$quiz_id]);
$quiz_data = $quiz->fetch();
if (!$quiz_data) die('الاختبار غير متوفر.');

// التحقق من أن الطالب لم يؤد الاختبار من قبل
$attempt_check = $pdo->prepare("SELECT id FROM student_quiz_attempts WHERE student_id = ? AND quiz_id = ?");
$attempt_check->execute([$user_id, $quiz_id]);
if ($attempt_check->fetch()) die('لقد قمت بإجراء هذا الاختبار بالفعل.');

$questions = $pdo->prepare("
    SELECT q.id, q.question_text, q.question_image
    FROM quiz_questions q 
    WHERE q.quiz_id = ? 
    ORDER BY RAND()
");
$questions->execute([$quiz_id]);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>الاختبار: <?= htmlspecialchars($quiz_data['title']) ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .quiz-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .quiz-header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .quiz-timer {
            background: #dc3545;
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: bold;
        }
        
        .question-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .options-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-top: 20px;
        }
        
        .option-label {
            display: flex;
            align-items: center;
            padding: 15px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .option-label:hover {
            border-color: #007bff;
            background: #f8f9ff;
        }
        
        .option-label input {
            margin-left: 15px;
        }
        
        .quiz-footer {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
    </style>
</head>
<body class="quiz-page-body">
    <div class="quiz-container">
        <header class="quiz-header">
            <h1><?= htmlspecialchars($quiz_data['title']) ?></h1>
            <div id="timer" class="quiz-timer">--:--</div>
        </header>
        
        <form id="quiz-form" action="../api/quiz_handler.php" method="POST">
            <input type="hidden" name="quiz_id" value="<?= $quiz_id ?>">
            <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
            
            <?php foreach($questions->fetchAll() as $index => $q): ?>
            <div class="question-card">
                <h3>السؤال <?= $index + 1 ?>: <?= htmlspecialchars($q['question_text']) ?></h3>
                <?php if ($q['question_image']): ?>
                <img src="../<?= $q['question_image'] ?>" alt="صورة السؤال" style="max-width: 100%; margin: 15px 0;">
                <?php endif; ?>
                <div class="options-list">
                    <?php
                    $options = $pdo->prepare("SELECT id, option_text FROM question_options WHERE question_id = ? ORDER BY RAND()");
                    $options->execute([$q['id']]);
                    foreach($options->fetchAll() as $opt):
                    ?>
                    <label class="option-label">
                        <input type="radio" name="answers[<?= $q['id'] ?>]" value="<?= $opt['id'] ?>" required>
                        <span><?= htmlspecialchars($opt['option_text']) ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
            
            <footer class="quiz-footer">
                <button type="submit" class="btn btn-primary btn-lg">إنهاء وتسليم الإجابات</button>
            </footer>
        </form>
    </div>

<script>
    const QUIZ_DATA = {
        quizId: <?= $quiz_id ?>,
        timeLimit: <?= $quiz_data['time_limit_minutes'] ?>
    };
    
    let timeRemaining = QUIZ_DATA.timeLimit * 60;
    
    function startTimer() {
        updateTimerDisplay();
        const timerInterval = setInterval(() => {
            timeRemaining--;
            updateTimerDisplay();
            
            if (timeRemaining <= 0) {
                clearInterval(timerInterval);
                document.getElementById('quiz-form').submit();
            }
        }, 1000);
    }
    
    function updateTimerDisplay() {
        const minutes = Math.floor(timeRemaining / 60);
        const seconds = timeRemaining % 60;
        document.getElementById('timer').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    document.addEventListener('DOMContentLoaded', startTimer);
</script>
</body>
</html>