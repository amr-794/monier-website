
<?php
$page_title = 'عرض القائمة';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
$pdo = get_db_connection();

$student_id = $user['id'];
$student_grade = $user['grade'];
$playlist_id = intval($_GET['id'] ?? 0);
if (!$playlist_id) {
    redirect('index.php');
}

// جلب بيانات القائمة
$playlist_stmt = $pdo->prepare("SELECT * FROM playlists WHERE id = ? AND is_active = 1");
$playlist_stmt->execute([$playlist_id]);
$playlist = $playlist_stmt->fetch();
if (!$playlist) {
    redirect('index.php');
}

// جلب صلاحيات وصول الطالب
$access_stmt = $pdo->prepare("SELECT lecture_id, remaining_views FROM student_lecture_access WHERE student_id = ?");
$access_stmt->execute([$student_id]);
$my_lectures_access = $access_stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// جلب محاضرات القائمة للصف الدراسي الحالي
$lectures_stmt = $pdo->prepare("SELECT * FROM lectures WHERE playlist_id = ? AND (grade = ? OR grade = 'all') AND is_active = 1 ORDER BY id ASC");
$lectures_stmt->execute([$playlist_id, $student_grade]);
$lectures = $lectures_stmt->fetchAll();
?>

<div class="playlist-container">
    <div class="playlist-header">
        <div class="header-content">
            <a href="index.php" class="back-btn">
                <i class="fas fa-arrow-right"></i>
                العودة للقوائم
            </a>
            <div class="playlist-info">
                <h1><?= htmlspecialchars($playlist['name']) ?></h1>
                <p class="playlist-description"><?= htmlspecialchars($playlist['description'] ?? '') ?></p>
                <div class="playlist-meta">
                    <span class="meta-item">
                        <i class="fas fa-play-circle"></i>
                        <?= count($lectures) ?> محاضرة
                    </span>
                </div>
            </div>
        </div>
    </div>

    <div class="lectures-grid">
        <?php if(empty($lectures)): ?>
            <div class="empty-state">
                <i class="fas fa-video-slash"></i>
                <h3>لا توجد محاضرات متاحة</h3>
                <p>لا توجد محاضرات متاحة في هذه القائمة حالياً.</p>
            </div>
        <?php else: ?>
            <?php foreach ($lectures as $index => $lecture): ?>
            <div class="lecture-card">
                <div class="lecture-thumbnail">
                    <img src="../<?= htmlspecialchars($lecture['thumbnail_path'] ?? 'assets/images/default-thumb.png') ?>" 
                         alt="<?= htmlspecialchars($lecture['title']) ?>"
                         class="thumbnail-img">
                    <div class="lecture-overlay">
                        <div class="lecture-number"><?= $index + 1 ?></div>
                        <div class="play-icon">
                            <i class="fas fa-play"></i>
                        </div>
                    </div>
                    <?php if(!$lecture['is_free']): ?>
                        <div class="premium-badge">
                            <i class="fas fa-crown"></i>
                            مدفوعة
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="lecture-content">
                    <h3 class="lecture-title"><?= htmlspecialchars($lecture['title']) ?></h3>
                    <p class="lecture-description"><?= htmlspecialchars(mb_substr($lecture['description'] ?? '', 0, 120)) ?>...</p>
                    
                    <div class="lecture-meta">
                        <span class="grade-badge">
                            <i class="fas fa-user-graduate"></i>
                            <?= get_grade_text($lecture['grade']) ?>
                        </span>
                        <?php if($lecture['is_free']): ?>
                            <span class="free-badge">
                                <i class="fas fa-unlock"></i>
                                مجانية
                            </span>
                        <?php else: ?>
                            <span class="price-badge">
                                <i class="fas fa-tag"></i>
                                <?= (float)$lecture['price'] ?> جنيه
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="lecture-actions">
                        <?php if ($lecture['is_free']): ?>
                            <a href="../view_lecture.php?id=<?= $lecture['id'] ?>" class="btn watch-btn">
                                <i class="fas fa-play"></i>
                                مشاهدة المحاضرة
                            </a>
                        <?php elseif (isset($my_lectures_access[$lecture['id']]) && $my_lectures_access[$lecture['id']] > 0): ?>
                            <a href="../view_lecture.php?id=<?= $lecture['id'] ?>" class="btn watch-btn has-access">
                                <i class="fas fa-play"></i>
                                مشاهدة (<?= $my_lectures_access[$lecture['id']] ?> متبقي)
                            </a>
                        <?php elseif (isset($my_lectures_access[$lecture['id']])): ?>
                            <a href="activate_lecture.php?lecture_id=<?= $lecture['id'] ?>" class="btn renew-btn">
                                <i class="fas fa-sync"></i>
                                تجديد الكود
                            </a>
                        <?php else: ?>
                            <a href="activate_lecture.php?lecture_id=<?= $lecture['id'] ?>" class="btn activate-btn">
                                <i class="fas fa-key"></i>
                                تفعيل المحاضرة
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
 <script src="<?= SITE_URL ?>/assets/js/main.js"></script>
<style>
:root {
    --primary-color: #667eea;
    --primary-dark: #5a6fd8;
    --secondary-color: #764ba2;
    --success-color: #28a745;
    --warning-color: #ffc107;
    --danger-color: #dc3545;
    --light-bg: #f8f9fa;
    --dark-text: #333;
    --gray-text: #666;
    --border-color: #e9ecef;
    --card-shadow: 0 4px 15px rgba(0,0,0,0.1);
    --shadow-sm: 0 2px 8px rgba(0,0,0,0.08);
}

.playlist-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 20px;
}

/* هيدر القائمة */
.playlist-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    border-radius: 20px;
    margin-bottom: 30px;
    overflow: hidden;
    box-shadow: var(--card-shadow);
}

.header-content {
    padding: 30px;
    position: relative;
}

.back-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    color: white;
    text-decoration: none;
    padding: 10px 20px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 25px;
    transition: all 0.3s ease;
    margin-bottom: 20px;
    font-weight: 500;
}

.back-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateX(-5px);
}

.playlist-info h1 {
    font-size: 2.2rem;
    margin-bottom: 15px;
    font-weight: 700;
}

.playlist-description {
    font-size: 1.1rem;
    opacity: 0.9;
    margin-bottom: 20px;
    line-height: 1.6;
}

.playlist-meta {
    display: flex;
    gap: 20px;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(255, 255, 255, 0.2);
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: 500;
}

/* شبكة المحاضرات */
.lectures-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 25px;
    margin-bottom: 40px;
}

.lecture-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: var(--card-shadow);
    transition: all 0.3s ease;
    border: 1px solid var(--border-color);
}

.lecture-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

/* الصورة المصغرة */
.lecture-thumbnail {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.thumbnail-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.lecture-card:hover .thumbnail-img {
    transform: scale(1.05);
}

.lecture-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(0,0,0,0.4), transparent);
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    padding: 15px;
}

.lecture-number {
    background: rgba(255, 255, 255, 0.9);
    color: var(--dark-text);
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.1rem;
    box-shadow: var(--shadow-sm);
}

.play-icon {
    background: var(--primary-color);
    color: white;
    width: 50px;
    height: 50px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    box-shadow: var(--shadow-sm);
    transform: scale(0.9);
    transition: transform 0.3s ease;
}

.lecture-card:hover .play-icon {
    transform: scale(1);
}

.premium-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    background: linear-gradient(45deg, #ffd700, #ffed4e);
    color: #856404;
    padding: 6px 12px;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
    box-shadow: var(--shadow-sm);
}

/* محتوى المحاضرة */
.lecture-content {
    padding: 25px;
}

.lecture-title {
    font-size: 1.3rem;
    font-weight: 700;
    margin-bottom: 12px;
    color: var(--dark-text);
    line-height: 1.4;
}

.lecture-description {
    color: var(--gray-text);
    font-size: 0.95rem;
    line-height: 1.5;
    margin-bottom: 20px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.lecture-meta {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.grade-badge,
.free-badge,
.price-badge {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 6px 12px;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: 600;
}

.grade-badge {
    background: #e3f2fd;
    color: #1976d2;
}

.free-badge {
    background: #e8f5e8;
    color: #2e7d32;
}

.price-badge {
    background: #fff3cd;
    color: #856404;
}

/* أزرار المشاهدة */
.lecture-actions .btn {
    width: 100%;
    padding: 12px 20px;
    border: none;
    border-radius: 12px;
    font-weight: 600;
    text-decoration: none;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.3s ease;
    font-size: 0.95rem;
}

.watch-btn {
    background: var(--primary-color);
    color: white;
}

.watch-btn:hover {
    background: var(--primary-dark);
    transform: translateY(-2px);
}

.has-access {
    background: var(--success-color);
}

.has-access:hover {
    background: #218838;
}

.renew-btn {
    background: var(--warning-color);
    color: var(--dark-text);
}

.renew-btn:hover {
    background: #e0a800;
    transform: translateY(-2px);
}

.activate-btn {
    background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
    color: white;
}

.activate-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

/* حالة فارغة */
.empty-state {
    grid-column: 1 / -1;
    text-align: center;
    padding: 60px 20px;
    color: var(--gray-text);
}

.empty-state i {
    font-size: 4rem;
    margin-bottom: 20px;
    opacity: 0.5;
}

.empty-state h3 {
    font-size: 1.5rem;
    margin-bottom: 10px;
    color: var(--dark-text);
}

.empty-state p {
    font-size: 1.1rem;
    opacity: 0.8;
}

/* التجاوب مع الشاشات الصغيرة */
@media (max-width: 768px) {
    .playlist-container {
        padding: 15px;
    }
    
    .header-content {
        padding: 25px 20px;
    }
    
    .playlist-info h1 {
        font-size: 1.8rem;
    }
    
    .lectures-grid {
        grid-template-columns: 1fr;
        gap: 20px;
    }
    
    .lecture-thumbnail {
        height: 180px;
    }
    
    .lecture-content {
        padding: 20px;
    }
    
    .playlist-meta {
        flex-direction: column;
        gap: 10px;
    }
}

@media (max-width: 480px) {
    .playlist-container {
        padding: 10px;
    }
    
    .header-content {
        padding: 20px 15px;
    }
    
    .playlist-info h1 {
        font-size: 1.5rem;
    }
    
    .lecture-thumbnail {
        height: 160px;
    }
    
    .lecture-content {
        padding: 15px;
    }
    
    .lecture-title {
        font-size: 1.2rem;
    }
    
    .lecture-meta {
        flex-direction: column;
        align-items: flex-start;
    }
}

/* تأثيرات الدخول */
.lecture-card {
    animation: fadeInUp 0.6s ease;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* تنسيق متدرج للبطاقات */
.lecture-card:nth-child(2n) {
    animation-delay: 0.1s;
}

.lecture-card:nth-child(3n) {
    animation-delay: 0.2s;
}
</style>
