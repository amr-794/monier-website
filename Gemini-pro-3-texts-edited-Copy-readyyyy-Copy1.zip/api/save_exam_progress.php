<?php
require_once '../includes/functions.php';
require_once '../includes/db_connection.php';

if (!is_student()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$student_id = current_user()['id'];

if (!$input || !isset($input['exam_id'])) {
    echo json_encode(['success' => false, 'message' => 'بيانات غير مكتملة']);
    exit;
}

$exam_id = intval($input['exam_id']);
$time_remaining = intval($input['time_remaining']);
$current_question = intval($input['current_question']);
$answers = $input['answers'] ?? [];

try {
    $pdo = get_db_connection();
    
    $stmt = $pdo->prepare("
        INSERT INTO student_exam_progress 
        (student_id, exam_id, time_remaining_seconds, current_question, answers_json, last_updated) 
        VALUES (?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE 
        time_remaining_seconds = VALUES(time_remaining_seconds),
        current_question = VALUES(current_question),
        answers_json = VALUES(answers_json),
        last_updated = NOW()
    ");
    
    $stmt->execute([
        $student_id, 
        $exam_id, 
        $time_remaining, 
        $current_question, 
        json_encode($answers, JSON_UNESCAPED_UNICODE)
    ]);
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    error_log("Error saving exam progress: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطأ في حفظ التقدم']);
}