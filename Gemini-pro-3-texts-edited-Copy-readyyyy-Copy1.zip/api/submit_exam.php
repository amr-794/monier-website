<?php
require_once '../includes/functions.php';
require_once '../includes/db_connection.php';

if (!is_student()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$student_id = current_user()['id'];

if (!$input || !isset($input['exam_id']) || !isset($input['answers'])) {
    echo json_encode(['success' => false, 'message' => 'بيانات غير مكتملة']);
    exit;
}

$exam_id = intval($input['exam_id']);
$answers = $input['answers'];
$time_spent = intval($input['time_spent']);

try {
    $pdo = get_db_connection();
    $pdo->beginTransaction();

    // جلب بيانات الاختبار والأسئلة
    $exam_stmt = $pdo->prepare("SELECT * FROM exams WHERE id = ?");
    $exam_stmt->execute([$exam_id]);
    $exam = $exam_stmt->fetch();

    if (!$exam) {
        throw new Exception('الاختبار غير موجود');
    }

    // جلب جميع أسئلة الاختبار
    $questions_stmt = $pdo->prepare("
        SELECT eq.*, eqo.id as option_id, eqo.is_correct 
        FROM exam_questions eq 
        LEFT JOIN exam_question_options eqo ON eq.id = eqo.question_id 
        WHERE eq.exam_id = ? 
        ORDER BY eq.sort_order, eq.id, eqo.sort_order
    ");
    $questions_stmt->execute([$exam_id]);
    $questions_data = $questions_stmt->fetchAll();

    // تنظيم البيانات
    $questions = [];
    $total_questions = 0;
    $score = 0;

    foreach ($questions_data as $row) {
        if (!isset($questions[$row['id']])) {
            $questions[$row['id']] = [
                'id' => $row['id'],
                'question_text' => $row['question_text'],
                'question_type' => $row['question_type'],
                'options' => []
            ];
            $total_questions++;
        }
        
        if ($row['option_id']) {
            $questions[$row['id']]['options'][$row['option_id']] = $row['is_correct'];
        }
    }

    // حساب الدرجة
    foreach ($questions as $question_id => $question) {
        $student_answers = $answers[$question_id] ?? [];
        
        if ($question['question_type'] === 'single') {
            // اختيار واحد
            if (count($student_answers) === 1) {
                $selected_option = $student_answers[0];
                if (isset($question['options'][$selected_option]) && $question['options'][$selected_option]) {
                    $score++;
                }
            }
        } else {
            // اختيار متعدد
            $correct_options = array_keys(array_filter($question['options']));
            $student_correct = array_intersect($student_answers, $correct_options);
            $student_wrong = array_diff($student_answers, $correct_options);
            
            if (empty($student_wrong) && count($student_correct) === count($correct_options)) {
                $score++;
            }
        }
    }

    $percentage = $total_questions > 0 ? round(($score / $total_questions) * 100, 2) : 0;

    // حفظ محاولة الاختبار
    $attempt_stmt = $pdo->prepare("
        INSERT INTO student_exam_attempts 
        (student_id, exam_id, score, total_questions, percentage, time_spent, completed_at) 
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    $attempt_stmt->execute([$student_id, $exam_id, $score, $total_questions, $percentage, $time_spent]);
    $attempt_id = $pdo->lastInsertId();

    // حفظ الإجابات التفصيلية
    foreach ($answers as $question_id => $student_answers) {
        if (!is_array($student_answers)) continue;
        
        $is_correct = 0;
        $question = $questions[$question_id] ?? null;
        
        if ($question) {
            if ($question['question_type'] === 'single') {
                if (count($student_answers) === 1) {
                    $selected_option = $student_answers[0];
                    $is_correct = isset($question['options'][$selected_option]) && $question['options'][$selected_option] ? 1 : 0;
                }
            } else {
                $correct_options = array_keys(array_filter($question['options']));
                $student_correct = array_intersect($student_answers, $correct_options);
                $student_wrong = array_diff($student_answers, $correct_options);
                $is_correct = (empty($student_wrong) && count($student_correct) === count($correct_options)) ? 1 : 0;
            }
        }

        $answer_stmt = $pdo->prepare("
            INSERT INTO student_exam_answers 
            (attempt_id, question_id, selected_options, is_correct) 
            VALUES (?, ?, ?, ?)
        ");
        $answer_stmt->execute([
            $attempt_id, 
            $question_id, 
            json_encode($student_answers, JSON_UNESCAPED_UNICODE),
            $is_correct
        ]);
    }

    // حفظ النتيجة
    $grade = get_grade_from_percentage($percentage);
    $result_stmt = $pdo->prepare("
        INSERT INTO student_exam_results 
        (student_id, exam_id, attempt_id, score, total_questions, percentage, grade, time_spent, completed_at, is_visible) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)
    ");
    $result_visible = $exam['results_visible'] && (!$exam['results_schedule'] || strtotime($exam['results_schedule']) <= time());
    $result_stmt->execute([
        $student_id, $exam_id, $attempt_id, $score, $total_questions, 
        $percentage, $grade, $time_spent, $result_visible ? 1 : 0
    ]);

    // حذف التقدم المحفوظ
    $progress_stmt = $pdo->prepare("DELETE FROM student_exam_progress WHERE student_id = ? AND exam_id = ?");
    $progress_stmt->execute([$student_id, $exam_id]);

    $pdo->commit();

    // إرسال إشعار للطالب
    send_exam_result_notification($student_id, $exam_id, $attempt_id, $score, $total_questions, $percentage);

    echo json_encode([
        'success' => true,
        'attempt_id' => $attempt_id,
        'score' => $score,
        'total_questions' => $total_questions,
        'percentage' => $percentage
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Error submitting exam: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'خطأ في تسليم الاختبار: ' . $e->getMessage()]);
}

/**
 * دالة مساعدة: الحصول على التقدير من النسبة
 */
function get_grade_from_percentage($percentage) {
    if ($percentage >= 90) return 'ممتاز';
    if ($percentage >= 80) return 'جيد جداً';
    if ($percentage >= 70) return 'جيد';
    if ($percentage >= 60) return 'مقبول';
    return 'راسب';
}

/**
 * دالة مساعدة: إرسال إشعار بنتيجة الاختبار
 */
function send_exam_result_notification($student_id, $exam_id, $attempt_id, $score, $total_questions, $percentage) {
    global $pdo;
    
    $exam_stmt = $pdo->prepare("SELECT title FROM exams WHERE id = ?");
    $exam_stmt->execute([$exam_id]);
    $exam = $exam_stmt->fetch();
    
    if ($exam) {
        $title = "نتيجة اختبار: " . $exam['title'];
        $content = "لقد حصلت على درجة {$score} من {$total_questions} ({$percentage}%) في الاختبار.";
        
        $notification_stmt = $pdo->prepare("
            INSERT INTO announcements 
            (title, content, target_type, target_id, is_notification) 
            VALUES (?, ?, 'specific_student', ?, 1)
        ");
        $notification_stmt->execute([$title, $content, $student_id]);
    }
}
?>