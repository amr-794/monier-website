<?php
require_once '../includes/functions.php';
require_once '../includes/db_connection.php';

if (!is_student()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$student_id = current_user()['id'];

if (!$input || !isset($input['notification_id'])) {
    echo json_encode(['success' => false, 'message' => 'بيانات غير مكتملة']);
    exit;
}

$notification_id = intval($input['notification_id']);

try {
    $pdo = get_db_connection();
    
    $stmt = $pdo->prepare("
        INSERT INTO student_notifications (student_id, announcement_id, is_read, read_at) 
        VALUES (?, ?, 1, NOW())
        ON DUPLICATE KEY UPDATE is_read = 1, read_at = NOW()
    ");
    $stmt->execute([$student_id, $notification_id]);
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    error_log("Error marking notification read: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'حدث خطأ']);
}
?>