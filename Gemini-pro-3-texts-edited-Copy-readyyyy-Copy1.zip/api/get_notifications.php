<?php
require_once '../includes/functions.php';
require_once '../includes/db_connection.php';

header('Content-Type: application/json');

if (!current_user()) {
    echo json_encode(['success' => false, 'message' => 'غير مصرح']);
    exit;
}

$user = current_user();
$user_id = $user['id'];
$user_type = $user['type'];

try {
    $pdo = get_db_connection();
    
    if ($user_type === 'student') {
        // جلب الإشعارات للطالب
        $stmt = $pdo->prepare("
            SELECT a.*, sn.is_read, sn.is_dismissed 
            FROM announcements a 
            LEFT JOIN student_notifications sn ON a.id = sn.announcement_id AND sn.student_id = ?
            WHERE a.is_visible = 1 
            AND (a.target_type = 'all' OR (a.target_type = 'specific_student' AND a.target_id = ?) OR (a.target_type = 'specific_grade' AND a.target_id = ?))
            AND (sn.is_dismissed IS NULL OR sn.is_dismissed = 0)
            ORDER BY a.created_at DESC 
            LIMIT 10
        ");
        $stmt->execute([$user_id, $user_id, $user['grade']]);
    } else {
        // جلب الإشعارات للأدمن
        $stmt = $pdo->prepare("
            SELECT * FROM announcements 
            WHERE is_visible = 1 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        $stmt->execute();
    }
    
    $notifications = $stmt->fetchAll();
    
    // تنسيق البيانات
    $formatted_notifications = [];
    foreach ($notifications as $notification) {
        $formatted_notifications[] = [
            'id' => $notification['id'],
            'title' => $notification['title'],
            'message' => $notification['content'],
            'time' => format_date($notification['created_at'], 'H:i - Y/m/d'),
            'is_read' => $notification['is_read'] ?? 0,
            'is_dismissed' => $notification['is_dismissed'] ?? 0,
            'show_in_main' => $notification['show_in_main'],
            'can_dismiss' => $notification['can_dismiss']
        ];
    }
    
    echo json_encode([
        'success' => true,
        'notifications' => $formatted_notifications
    ]);
    
} catch (Exception $e) {
    error_log("Error getting notifications: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'حدث خطأ في جلب الإشعارات']);
}
?>