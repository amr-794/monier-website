<?php
require_once 'auth.php';
handle_logout();