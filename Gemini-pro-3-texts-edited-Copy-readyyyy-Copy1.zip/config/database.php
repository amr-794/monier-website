<?php
// إعدادات الاتصال بقاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'chemistry1_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// إعدادات الموقع
define('SITE_URL', 'http://localhost/chemistry_platform/gemini/Gemini-pro-3-texts-edited-Copy');
define('SITE_NAME', 'منصة منير');

// إعدادات أخرى
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
?>