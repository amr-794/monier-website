<?php
$page_title = 'تفاصيل الطالب';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';

$student_id = intval($_GET['id'] ?? 0);
if (!$student_id) { 
    die('<div class="alert alert-danger">معرف الطالب غير صالح.</div>');
}

$pdo = get_db_connection();
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) { 
    die('<div class="alert alert-danger">الطالب غير موجود.</div>');
}

$message = '';

// معالجة الأوامر
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // تحديث بيانات الطالب
    if (isset($_POST['update_student'])) {
        $name = sanitize_input($_POST['name']);
        $phone = sanitize_input($_POST['phone']);
        $parent_phone = sanitize_input($_POST['parent_phone']);
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $grade = sanitize_input($_POST['grade']);
        $notes = sanitize_input($_POST['notes']);
        
        $stmt_update = $pdo->prepare("UPDATE students SET name=?, phone=?, parent_phone=?, email=?, grade=?, notes=? WHERE id=?");
        $stmt_update->execute([$name, $phone, $parent_phone, $email, $grade, $notes, $student_id]);
        $message = "<div class='alert alert-success'>تم تحديث بيانات الطالب بنجاح.</div>";
        
        // إعادة جلب البيانات المحدثة
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();
    }

    // تعليق الحساب
    if (isset($_POST['suspend_account'])) {
        $duration = sanitize_input($_POST['suspension_duration']);
        $suspend_until = null;
        if ($duration !== 'permanent') {
            $suspend_until = (new DateTime())->modify($duration)->format('Y-m-d H:i:s');
        }
        $reason = sanitize_input($_POST['suspension_reason']);
        $new_status = 'suspended';
        
        $stmt_suspend = $pdo->prepare("UPDATE students SET status = ?, notes = CONCAT(IFNULL(notes,''), ?), suspend_until = ? WHERE id = ?");
        $stmt_suspend->execute([$new_status, "\n[إيقاف " . date('Y-m-d H:i') . "]: " . $reason, $suspend_until, $student_id]);
        $message = "<div class='alert alert-success'>تم إيقاف حساب الطالب.</div>";
        
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();
    }

    // إعادة تفعيل الحساب
    if (isset($_POST['reactivate_account'])) {
        $stmt_reactivate = $pdo->prepare("UPDATE students SET status = 'active', suspend_until = NULL WHERE id = ?");
        $stmt_reactivate->execute([$student_id]);
        $message = "<div class='alert alert-success'>تم إعادة تفعيل حساب الطالب.</div>";
        
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();
    }

    // مسح سجل النشاط
    if (isset($_POST['clear_activity'])) {
        $result = clear_student_activity($student_id);
        if (isset($result['success'])) {
            $message = "<div class='alert alert-success'>" . $result['success'] . "</div>";
        } else {
            $message = "<div class='alert alert-danger'>" . $result['error'] . "</div>";
        }
        
        $stmt->execute([$student_id]);
        $student = $stmt->fetch();
    }

    // مسح صلاحيات المحاضرات
    if (isset($_POST['clear_lecture_access'])) {
        $result = clear_student_lecture_access($student_id);
        if (isset($result['success'])) {
            $message = "<div class='alert alert-success'>" . $result['success'] . "</div>";
        } else {
            $message = "<div class='alert alert-danger'>" . $result['error'] . "</div>";
        }
    }

    // مسح محاولات الاختبارات
    if (isset($_POST['clear_quiz_attempts'])) {
        $result = clear_student_quiz_attempts($student_id);
        if (isset($result['success'])) {
            $message = "<div class='alert alert-success'>" . $result['success'] . "</div>";
        } else {
            $message = "<div class='alert alert-danger'>" . $result['error'] . "</div>";
        }
    }
}

// طرد المستخدم
if(isset($_GET['action']) && $_GET['action'] === 'kick') {
    $stmt_kick = $pdo->prepare("UPDATE user_sessions SET is_active = 0 WHERE user_id = ? AND user_type = 'student'");
    $stmt_kick->execute([$student_id]);
    $message = "<div class='alert alert-warning'>تم إرسال أمر الطرد. سيتم تسجيل خروج الطالب من جميع الأجهزة خلال الدقائق القادمة.</div>";
}

// جلب الإحصائيات والنشاط
$activity = get_student_detailed_activity($student_id);

// إحصائيات عامة
$stats_stmt = $pdo->prepare("
    SELECT 
        COUNT(DISTINCT sla.lecture_id) as total_lectures_accessed,
        COUNT(DISTINCT sqa.quiz_id) as total_quizzes_taken,
        SUM(sla.remaining_views) as total_remaining_views,
        MAX(sla.last_viewed) as last_lecture_activity
    FROM students s
    LEFT JOIN student_lecture_access sla ON s.id = sla.student_id
    LEFT JOIN student_quiz_attempts sqa ON s.id = sqa.student_id
    WHERE s.id = ?
");
$stats_stmt->execute([$student_id]);
$stats = $stats_stmt->fetch();

// جلب المحاضرات التي لديه صلاحية عليها
$accessible_lectures_stmt = $pdo->prepare("
    SELECT l.id, l.title, sla.remaining_views, sla.last_viewed
    FROM student_lecture_access sla
    JOIN lectures l ON sla.lecture_id = l.id
    WHERE sla.student_id = ? AND sla.remaining_views > 0
    ORDER BY sla.last_viewed DESC
");
$accessible_lectures_stmt->execute([$student_id]);
$accessible_lectures = $accessible_lectures_stmt->fetchAll();
?>

<div class="page-header">
    <h1>تفاصيل الطالب: <?= htmlspecialchars($student['name']) ?></h1>
    <div class="header-actions">
        <a href="students.php" class="btn btn-secondary">العودة للقائمة</a>
        <a href="grant_views.php?student_id=<?= $student_id ?>" class="btn btn-success">منح مشاهدات</a>
    </div>
</div>

<?= $message ?>

<div class="grid-container" style="grid-template-columns: 2fr 1fr; gap: 20px; align-items: flex-start;">
    
    <!-- الجزء الأيسر: المعلومات والنشاط -->
    <div>
        <!-- بطاقة المعلومات الأساسية -->
        <div class="card">
            <div class="card-header">
                <h3>المعلومات الأساسية</h3>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>الاسم الكامل:</label>
                            <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>رقم الهاتف:</label>
                            <input type="text" name="phone" value="<?= htmlspecialchars($student['phone']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>هاتف ولي الأمر:</label>
                            <input type="text" name="parent_phone" value="<?= htmlspecialchars($student['parent_phone']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>البريد الإلكتروني:</label>
                            <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>الصف الدراسي:</label>
                            <select name="grade" required>
                                <option value="first_secondary" <?= $student['grade'] == 'first_secondary' ? 'selected' : '' ?>>الأول الثانوي</option>
                                <option value="second_secondary" <?= $student['grade'] == 'second_secondary' ? 'selected' : '' ?>>الثاني الثانوي</option>
                                <option value="third_secondary" <?= $student['grade'] == 'third_secondary' ? 'selected' : '' ?>>الثالث الثانوي</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>الحالة:</label>
                            <span class="status-badge status-<?= $student['status'] ?>">
                                <?= get_status_text($student['status']) ?>
                            </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>ملاحظات:</label>
                        <textarea name="notes" rows="3" style="width: 100%;"><?= htmlspecialchars($student['notes'] ?? '') ?></textarea>
                    </div>
                    <button type="submit" name="update_student" class="btn btn-primary">تحديث البيانات</button>
                </form>
            </div>
        </div>

        <!-- بطاقة الإحصائيات -->
        <div class="card">
            <div class="card-header">
                <h3>الإحصائيات والنشاط</h3>
            </div>
            <div class="card-body">
                <div class="stats-grid-mini">
                    <div class="stat-card-mini">
                        <div class="stat-number"><?= $stats['total_lectures_accessed'] ?? 0 ?></div>
                        <div class="stat-label">محاضرة تم الوصول لها</div>
                    </div>
                    <div class="stat-card-mini">
                        <div class="stat-number"><?= $stats['total_quizzes_taken'] ?? 0 ?></div>
                        <div class="stat-label">اختبار تم حلّه</div>
                    </div>
                    <div class="stat-card-mini">
                        <div class="stat-number"><?= $stats['total_remaining_views'] ?? 0 ?></div>
                        <div class="stat-label">مشاهدات متبقية</div>
                    </div>
                    <div class="stat-card-mini">
                        <div class="stat-number"><?= $student['login_count'] ?? 0 ?></div>
                        <div class="stat-label">مرة دخول</div>
                    </div>
                </div>
                
                <?php if($stats['last_lecture_activity']): ?>
                <div class="activity-info">
                    <strong>آخر نشاط دراسي:</strong> 
                    <?= time_since($stats['last_lecture_activity']) ?>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- بطاقة المحاضرات المتاحة -->
        <div class="card">
            <div class="card-header">
                <h3>المحاضرات المتاحة للطالب</h3>
            </div>
            <div class="card-body">
                <?php if(empty($accessible_lectures)): ?>
                    <p class="text-muted">لا توجد محاضرات متاحة للطالب حالياً.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="data-table minimal">
                            <thead>
                                <tr>
                                    <th>المحاضرة</th>
                                    <th>المشاهدات المتبقية</th>
                                    <th>آخر مشاهدة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($accessible_lectures as $lecture): ?>
                                <tr>
                                    <td><?= htmlspecialchars($lecture['title']) ?></td>
                                    <td>
                                        <span class="badge badge-info"><?= $lecture['remaining_views'] ?></span>
                                    </td>
                                    <td>
                                        <?= $lecture['last_viewed'] ? time_since($lecture['last_viewed']) : 'لم يشاهد' ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- بطاقة النشاط التفصيلي -->
        <div class="card">
            <div class="card-header">
                <h3>سجل النشاط والجلسات</h3>
                <div class="card-actions">
                    <?php if(!empty($activity)): ?>
                    <form method="POST" style="display: inline;" onsubmit="return confirm('هل أنت متأكد من مسح سجل النشاط والجلسات؟ هذا الإجراء لا يمكن التراجع عنه.');">
                        <button type="submit" name="clear_activity" class="btn btn-sm btn-danger">🗑️ مسح السجل</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if(empty($activity)): ?>
                    <p class="text-muted">لا توجد سجلات نشاط للطالب.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>وقت الدخول</th>
                                    <th>آخر نشاط</th>
                                    <th>IP العنوان</th>
                                    <th>الجهاز</th>
                                    <th>المحاضرات</th>
                                    <th>الاختبارات</th>
                                    <th>الحالة</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($activity as $session): ?>
                                <tr>
                                    <td><?= date('Y-m-d H:i:s', strtotime($session['login_time'])) ?></td>
                                    <td><?= time_since($session['last_activity']) ?></td>
                                    <td><code><?= htmlspecialchars($session['ip_address']) ?></code></td>
                                    <td>
                                        <span class="tooltip" data-tooltip="<?= htmlspecialchars($session['user_agent']) ?>">
                                            <?= get_device_from_ua($session['user_agent']) ?>
                                        </span>
                                    </td>
                                    <td><?= $session['lectures_accessed'] ?></td>
                                    <td><?= $session['quizzes_taken'] ?></td>
                                    <td>
                                        <span class="status-badge <?= $session['is_active'] ? 'status-active' : 'status-inactive' ?>">
                                            <?= $session['is_active'] ? 'نشط' : 'منتهي' ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- الجزء الأيمن: أدوات التحكم -->
    <div class="card">
        <div class="card-header"><h3>إجراءات التحكم</h3></div>
        <div class="card-body">
            <div class="admin-actions">
                <!-- زر الطرد -->
                <a href="?id=<?= $student_id ?>&action=kick" class="btn btn-warning btn-block" 
                   onclick="return confirm('هل أنت متأكد من طرد هذا الطالب؟ سيتم تسجيل خروجه من جميع جلساته النشطة.')">
                   🚫 طرد الطالب من جميع الجلسات
                </a>
                <hr>
                
                <!-- مسح البيانات -->
                <div class="clear-actions-section">
                    <h4>🧹 مسح البيانات</h4>
                    
                    <form method="POST" onsubmit="return confirm('هل أنت متأكد من مسح جميع صلاحيات المحاضرات؟');">
                        <button type="submit" name="clear_lecture_access" class="btn btn-outline-danger btn-block btn-sm">
                            مسح صلاحيات المحاضرات
                        </button>
                    </form>
                    
                    <form method="POST" onsubmit="return confirm('هل أنت متأكد من مسح جميع محاولات الاختبارات؟');" style="margin-top: 5px;">
                        <button type="submit" name="clear_quiz_attempts" class="btn btn-outline-danger btn-block btn-sm">
                            مسح محاولات الاختبارات
                        </button>
                    </form>
                </div>
                <hr>
                
                <?php if ($student['status'] === 'active'): ?>
                    <h4>⏸️ إيقاف الحساب</h4>
                    <form method="POST">
                        <div class="form-group">
                            <label>مدة الإيقاف:</label>
                            <select name="suspension_duration" class="form-control">
                                <option value="+1 hour">ساعة واحدة</option>
                                <option value="+3 hours">٣ ساعات</option>
                                <option value="+1 day">يوم واحد</option>
                                <option value="+3 days">٣ أيام</option>
                                <option value="+1 week">أسبوع</option>
                                <option value="+2 weeks">أسبوعين</option>
                                <option value="+1 month">شهر</option>
                                <option value="permanent">إيقاف دائم (حظر)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>سبب الإيقاف:</label>
                            <textarea name="suspension_reason" rows="2" class="form-control" placeholder="أدخل سبب الإيقاف..." required></textarea>
                        </div>
                        <button type="submit" name="suspend_account" class="btn btn-danger btn-block">تأكيد الإيقاف</button>
                    </form>
                <?php else: ?>
                    <h4>✅ إعادة تفعيل الحساب</h4>
                    <p>هذا الحساب موقوف حالياً. 
                        <?php if($student['suspend_until']): ?>
                            <br>حتى: <?= date('Y-m-d H:i', strtotime($student['suspend_until'])) ?>
                        <?php endif; ?>
                    </p>
                    <form method="POST">
                        <button type="submit" name="reactivate_account" class="btn btn-success btn-block">إعادة التفعيل الآن</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.stats-grid-mini {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 15px;
    margin-bottom: 20px;
}
.stat-card-mini {
    background: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    text-align: center;
    border: 1px solid #e9ecef;
}
.stat-card-mini .stat-number {
    font-size: 24px;
    font-weight: bold;
    color: #007bff;
}
.stat-card-mini .stat-label {
    font-size: 12px;
    color: #6c757d;
    margin-top: 5px;
}
.activity-info {
    background: #e7f3ff;
    padding: 10px;
    border-radius: 5px;
    border-right: 4px solid #007bff;
}
.header-actions {
    display: flex;
    gap: 10px;
    margin-top: 10px;
}
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}
.card-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}
.clear-actions-section {
    margin-bottom: 15px;
}
.clear-actions-section h4 {
    margin-bottom: 10px;
    color: #dc3545;
}
.btn-outline-danger {
    border: 1px solid #dc3545;
    color: #dc3545;
    background: transparent;
}
.btn-outline-danger:hover {
    background: #dc3545;
    color: white;
}
@media (max-width: 768px) {
    .grid-container {
        grid-template-columns: 1fr !important;
    }
    .form-grid {
        grid-template-columns: 1fr;
    }
    .stats-grid-mini {
        grid-template-columns: 1fr;
    }
    .header-actions {
        flex-direction: column;
    }
}
</style>

<?php include 'partials/footer.php'; ?>