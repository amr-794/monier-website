<?php
require_once 'includes/auth.php';
handle_logout();