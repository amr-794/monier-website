<?php
$page_title = 'منح مشاهدات للطالب';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';

$student_id = intval($_GET['student_id'] ?? 0);
if (!$student_id) {
    die('<div class="alert alert-danger">معرف الطالب غير صالح.</div>');
}

$pdo = get_db_connection();

// جلب معلومات الطالب
$stmt = $pdo->prepare("SELECT id, name FROM students WHERE id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if (!$student) {
    die('<div class="alert alert-danger">الطالب غير موجود.</div>');
}

$message = '';

// معالجة منح المشاهدات
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['grant_views'])) {
    $lecture_ids = $_POST['lecture_id'] ?? [];
    $views = intval($_POST['views']);
    
    if (empty($lecture_ids)) {
        $message = "<div class='alert alert-danger'>يرجى اختيار محاضرة واحدة على الأقل.</div>";
    } elseif ($views < 1) {
        $message = "<div class='alert alert-danger'>عدد المشاهدات يجب أن يكون 1 على الأقل.</div>";
    } else {
        $success_count = 0;
        $errors = [];
        
        foreach ($lecture_ids as $lecture_id) {
            $lecture_id = intval($lecture_id);
            if ($lecture_id > 0) {
                try {
                    $sql = "INSERT INTO student_lecture_access (student_id, lecture_id, remaining_views) 
                            VALUES (?, ?, ?)
                            ON DUPLICATE KEY UPDATE 
                            remaining_views = remaining_views + VALUES(remaining_views),
                            last_viewed = IF(VALUES(remaining_views) > 0, last_viewed, NULL)";
                    
                    $stmt_grant = $pdo->prepare($sql);
                    $stmt_grant->execute([$student_id, $lecture_id, $views]);
                    $success_count++;
                    
                } catch (PDOException $e) {
                    $errors[] = "خطأ في منح الصلاحية للمحاضرة ID: $lecture_id";
                }
            }
        }
        
        if ($success_count > 0) {
            $message = "<div class='alert alert-success'>تم منح $views مشاهدات لـ $success_count محاضرة بنجاح.</div>";
        }
        if (!empty($errors)) {
            $message .= "<div class='alert alert-warning'>" . implode('<br>', $errors) . "</div>";
        }
    }
}

// جلب جميع المحاضرات
$lectures_stmt = $pdo->query("
    SELECT l.id, l.title, p.name as playlist_name, l.grade 
    FROM lectures l 
    JOIN playlists p ON l.playlist_id = p.id 
    WHERE l.is_active = 1 
    ORDER BY p.name, l.title
");
$lectures = $lectures_stmt->fetchAll();

// جلب المحاضرات المتاحة حالياً للطالب
$current_access_stmt = $pdo->prepare("
    SELECT lecture_id, remaining_views, last_viewed 
    FROM student_lecture_access 
    WHERE student_id = ? AND remaining_views > 0
");
$current_access_stmt->execute([$student_id]);
$current_access = $current_access_stmt->fetchAll();

// تحويل إلى مصفوفة سهلة البحث
$current_access_map = [];
foreach ($current_access as $access) {
    $current_access_map[$access['lecture_id']] = $access;
}
?>

<div class="page-header">
    <h1>منح مشاهدات للطالب</h1>
    <div class="header-actions">
        <a href="student_details.php?id=<?= $student_id ?>" class="btn btn-secondary">العودة لتفاصيل الطالب</a>
        <a href="students.php" class="btn btn-outline">قائمة الطلاب</a>
    </div>
</div>

<?= $message ?>

<div class="grid-container" style="grid-template-columns: 1fr 1fr; gap: 20px;">
    
    <!-- نموذج منح المشاهدات -->
    <div class="card">
        <div class="card-header">
            <h3>منح مشاهدات جديدة</h3>
            <p>للطالب: <strong><?= htmlspecialchars($student['name']) ?></strong></p>
        </div>
        <div class="card-body">
            <form method="POST" id="grantViewsForm">
                <div class="form-group">
                    <label>اختر المحاضرات:</label>
                    <div class="lectures-list" style="max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; border-radius: 5px;">
                        <div class="form-group" style="margin-bottom: 10px;">
                            <input type="text" id="lectureSearch" placeholder="ابحث في المحاضرات..." style="width: 100%; padding: 8px;">
                        </div>
                        
                        <div class="select-all-group" style="margin-bottom: 10px; padding: 5px; background: #f8f9fa; border-radius: 3px;">
                            <label style="cursor: pointer;">
                                <input type="checkbox" id="selectAllLectures"> 
                                <strong>تحديد كل المحاضرات</strong>
                            </label>
                        </div>
                        
                        <?php 
                        $current_playlist = '';
                        foreach ($lectures as $lecture): 
                            $is_selected = isset($current_access_map[$lecture['id']]);
                            if ($current_playlist != $lecture['playlist_name']): 
                                $current_playlist = $lecture['playlist_name'];
                        ?>
                            <div class="playlist-section" style="margin: 10px 0; padding: 5px; background: #e9ecef; border-radius: 3px;">
                                <strong>📁 <?= htmlspecialchars($lecture['playlist_name']) ?></strong>
                                <small class="text-muted">(<?= get_grade_text($lecture['grade']) ?>)</small>
                            </div>
                        <?php endif; ?>
                        
                        <div class="lecture-item" data-playlist="<?= htmlspecialchars($lecture['playlist_name']) ?>" data-title="<?= htmlspecialchars(strtolower($lecture['title'])) ?>">
                            <label style="display: flex; align-items: center; padding: 5px; margin: 2px 0; cursor: pointer; border-radius: 3px; transition: background 0.2s;">
                                <input type="checkbox" name="lecture_id[]" value="<?= $lecture['id'] ?>" 
                                       style="margin-left: 8px;" 
                                       <?= $is_selected ? 'checked' : '' ?>>
                                <span style="flex: 1;">
                                    <?= htmlspecialchars($lecture['title']) ?>
                                    <?php if ($is_selected): ?>
                                        <small class="text-success">(✔️ متاح: <?= $current_access_map[$lecture['id']]['remaining_views'] ?> مشاهدة)</small>
                                    <?php endif; ?>
                                </span>
                            </label>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>عدد المشاهدات:</label>
                    <input type="number" name="views" value="3" min="1" max="100" required style="width: 100px;">
                    <small class="text-muted">(من 1 إلى 100 مشاهدة)</small>
                </div>
                
                <div class="form-actions">
                    <button type="submit" name="grant_views" class="btn btn-success">💾 منح المشاهدات المحددة</button>
                    <button type="reset" class="btn btn-secondary">إعادة تعيين</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- المحاضرات المتاحة حالياً -->
    <div class="card">
        <div class="card-header">
            <h3>المحاضرات المتاحة حالياً</h3>
            <p>المشاهدات الحالية للطالب</p>
        </div>
        <div class="card-body">
            <?php if(empty($current_access)): ?>
                <p class="text-muted">لا توجد محاضرات متاحة للطالب حالياً.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table minimal">
                        <thead>
                            <tr>
                                <th>المحاضرة</th>
                                <th>المشاهدات</th>
                                <th>آخر نشاط</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // جلب أسماء المحاضرات
                            foreach ($current_access as $access): 
                                $lecture_stmt = $pdo->prepare("SELECT title FROM lectures WHERE id = ?");
                                $lecture_stmt->execute([$access['lecture_id']]);
                                $lecture = $lecture_stmt->fetch();
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($lecture['title']) ?></td>
                                <td>
                                    <span class="badge badge-info" style="font-size: 14px;"><?= $access['remaining_views'] ?></span>
                                </td>
                                <td>
                                    <?= $access['last_viewed'] ? time_since($access['last_viewed']) : 'لم يشاهد' ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="stats-summary" style="margin-top: 15px; padding: 10px; background: #f8f9fa; border-radius: 5px;">
                    <strong>الإجمالي:</strong> 
                    <?= count($current_access) ?> محاضرة | 
                    <?= array_sum(array_column($current_access, 'remaining_views')) ?> مشاهدة متبقية
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// بحث في المحاضرات
document.getElementById('lectureSearch').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const lectureItems = document.querySelectorAll('.lecture-item');
    
    lectureItems.forEach(item => {
        const title = item.getAttribute('data-title');
        const playlist = item.getAttribute('data-playlist');
        const matches = title.includes(searchTerm) || playlist.toLowerCase().includes(searchTerm);
        item.style.display = matches ? 'block' : 'none';
    });
});

// تحديد كل المحاضرات
document.getElementById('selectAllLectures').addEventListener('change', function(e) {
    const checkboxes = document.querySelectorAll('input[name="lecture_id[]"]');
    checkboxes.forEach(checkbox => {
        if (checkbox.closest('.lecture-item').style.display !== 'none') {
            checkbox.checked = e.target.checked;
        }
    });
});

// تأكيد عند الإرسال
document.getElementById('grantViewsForm').addEventListener('submit', function(e) {
    const selectedCount = document.querySelectorAll('input[name="lecture_id[]"]:checked').length;
    if (selectedCount === 0) {
        e.preventDefault();
        alert('يرجى اختيار محاضرة واحدة على الأقل.');
        return;
    }
    
    if (!confirm(`هل أنت متأكد من منح المشاهدات لـ ${selectedCount} محاضرة؟`)) {
        e.preventDefault();
    }
});
</script>

<style>
.lecture-item:hover {
    background: #f8f9fa;
}
.playlist-section {
    font-size: 14px;
}
.badge-info {
    background: #17a2b8;
    color: white;
    padding: 3px 8px;
    border-radius: 10px;
}
.form-actions {
    display: flex;
    gap: 10px;
    margin-top: 20px;
}
@media (max-width: 768px) {
    .grid-container {
        grid-template-columns: 1fr !important;
    }
}
</style>

<?php include 'partials/footer.php'; ?>