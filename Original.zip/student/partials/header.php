<?php
require_once __DIR__ . '/../../includes/functions.php';

// التحقق من أن المستخدم هو طالب ومسجل دخوله
if (!is_student()) {
    redirect(SITE_URL . '/login.php');
}

// هذا السطر مهم جدًا لتفعيل نظام الحماية من تعدد الجلسات
require_once __DIR__ . '/../../includes/header.php';

$user = current_user();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'لوحة التحكم' ?> - <?= SITE_NAME ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* استخدام نفس نظام الألوان من الصفحة الرئيسية */
        :root {
            --primary: #0f0f23;
            --primary-dark: #070711;
            --primary-light: #1a1a2e;
            --secondary: #00d4ff;
            --secondary-dark: #0099cc;
            --accent: #7b42f6;
            --accent-dark: #5e2fc9;
            --neon: #e5ff00ff;
            --neon-secondary: #00ffbfff;
            --gold: #ffd700;
            --silver: #c0c0c0;
            --text-dark: #0f172a;
            --text-darker: #020617;
            --text-light: #f0f8ff;
            --text-muted: #94a3b8;
            --bg-light: #0a0a18;
            --bg-dark: #050510;
            --card-light: rgba(16, 16, 36, 0.8);
            --card-dark: rgba(10, 10, 30, 0.9);
            --border-light: rgba(0, 212, 255, 0.3);
            --border-dark: rgba(123, 66, 246, 0.3);
            --shadow: 0 0 20px rgba(0, 212, 255, 0.3);
            --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.4);
            --transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --gradient-primary: linear-gradient(135deg, #60aa00ff, #008ee0ff);
            --gradient-secondary: linear-gradient(135deg, #ff00aa, #7b42f6);
            --gradient-gold: linear-gradient(135deg, #ffd700, #ffaa00);
            --success: #00ff88;
            --danger: #ff0066;
        }

        .light-mode {
            --primary: #f0f8ff;
            --primary-dark: #d6e4f0;
            --primary-light: #ffffff;
            --secondary: #0066cc;
            --secondary-dark: #004499;
            --accent: #7b42f6;
            --accent-dark: #5e2fc9;
            --neon: #0099cc;
            --neon-secondary: #cc0066;
            --gold: #ffaa00;
            --silver: #666666;
            --text-dark: #1e293b;
            --text-darker: #0f172a;
            --text-light: #1e293b;
            --text-muted: #64748b;
            --bg-light: #f0f8ff;
            --bg-dark: #e6f2ff;
            --card-light: rgba(255, 255, 255, 0.9);
            --card-dark: rgba(240, 248, 255, 0.95);
            --border-light: rgba(0, 102, 204, 0.3);
            --border-dark: rgba(123, 66, 246, 0.3);
            --shadow: 0 0 20px rgba(0, 102, 204, 0.2);
            --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.2);
            --gradient-primary: linear-gradient(135deg, #0066cc, #7b42f6);
            --gradient-secondary: linear-gradient(135deg, #cc0066, #7b42f6);
            --gradient-gold: linear-gradient(135deg, #ffaa00, #ff6600);
            --success: #00aa55;
            --danger: #cc0044;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: var(--bg-light);
            color: var(--text-light);
            overflow-x: hidden;
            line-height: 1.6;
            min-height: 100vh;
            transition: background-color 0.8s ease, color 0.5s ease;
            padding: 0;
            margin: 0;
        }

        .light-mode body {
            background: var(--bg-light);
            color: var(--text-dark);
        }

        /* خلفية ثابتة */
        .cyber-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -2;
            overflow: hidden;
            background: 
                radial-gradient(circle at 20% 80%, rgba(0, 212, 255, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(123, 66, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(255, 0, 170, 0.05) 0%, transparent 50%);
        }

        .grid-lines {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(0, 212, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 212, 255, 0.05) 1px, transparent 1px);
            background-size: 50px 50px;
        }

        /* Header Styles - محسنة */
        .student-header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: rgba(15, 15, 35, 0.98);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border-light);
            z-index: 10000; /* قيمة عالية جداً */
            transition: var(--transition);
            padding: 0.8rem 0;
            height: 70px;
            display: flex;
            align-items: center;
        }

        .light-mode .student-header {
            background: rgba(240, 248, 255, 0.98);
            border-bottom: 1px solid var(--border-light);
        }

        .student-header.scrolled {
            padding: 0.5rem 0;
            height: 60px;
            box-shadow: var(--shadow);
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 1.5rem;
            width: 100%;
            height: 100%;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 1rem;
            height: 100%;
        }

        .home-btn {
            color: var(--text-light);
            font-size: 1.2rem;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .light-mode .home-btn {
            color: var(--text-dark);
        }

        .home-btn:hover {
            background: var(--border-light);
            transform: scale(1.1);
        }

        .logo-link {
            text-decoration: none;
        }

        .logo-link h1 {
            color: var(--text-light);
            font-size: 1.3rem;
            font-weight: 700;
            margin: 0;
        }

        .light-mode .logo-link h1 {
            color: var(--text-dark);
        }

        /* Navigation */
        .student-nav {
            display: flex;
            align-items: center;
            gap: 1rem;
            height: 100%;
        }

        .nav-link {
            color: var(--text-light);
            text-decoration: none;
            font-weight: 600;
            padding: 0.6rem 1rem;
            border-radius: 20px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            border: 1px solid transparent;
            font-size: 0.9rem;
            height: fit-content;
        }

        .light-mode .nav-link {
            color: var(--text-dark);
        }

        .nav-link:hover {
            color: var(--neon);
            background: rgba(0, 212, 255, 0.1);
            border-color: var(--secondary);
        }

        .light-mode .nav-link:hover {
            color: var(--secondary);
        }

        .nav-link.active {
            background: var(--gradient-primary);
            color: white;
            border-color: transparent;
        }

        /* User Actions */
        .user-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
            height: 100%;
        }

        .notification-icon {
            position: relative;
            color: var(--text-light);
            font-size: 1.2rem;
            cursor: pointer;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .light-mode .notification-icon {
            color: var(--text-dark);
        }

        .notification-icon:hover {
            background: var(--border-light);
            transform: scale(1.1);
        }

        .notification-count {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 0.7rem;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
        }

        .welcome-message {
            color: var(--text-light);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .light-mode .welcome-message {
            color: var(--text-dark);
        }

        .welcome-message strong {
            color: var(--neon);
        }

        .light-mode .welcome-message strong {
            color: var(--secondary);
        }

        .logout-btn-student {
            color: var(--text-light);
            text-decoration: none;
            font-weight: 600;
            padding: 0.6rem 1rem;
            border-radius: 20px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 0.5rem;
            border: 1px solid var(--secondary);
            font-size: 0.9rem;
        }

        .light-mode .logout-btn-student {
            color: var(--text-dark);
            border: 1px solid var(--secondary);
        }

        .logout-btn-student:hover {
            background: var(--secondary);
            color: white;
            transform: translateY(-2px);
        }

        /* Notification Panel */
        .notification-panel {
            position: fixed;
            top: 80px;
            left: 50%;
            transform: translateX(-50%);
            width: 350px;
            background: var(--card-light);
            border: 1px solid var(--border-light);
            border-radius: 15px;
            box-shadow: var(--shadow-dark);
            backdrop-filter: blur(15px);
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 10001;
        }

        .light-mode .notification-panel {
            background: var(--card-light);
            border: 1px solid var(--border-light);
            box-shadow: var(--shadow-dark);
        }

        .notification-panel.active {
            opacity: 1;
            visibility: visible;
        }

        .panel-header {
            padding: 1rem;
            border-bottom: 1px solid var(--border-light);
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-weight: 700;
            color: var(--text-light);
        }

        .light-mode .panel-header {
            color: var(--text-dark);
            border-bottom-color: var(--border-light);
        }

        .panel-body {
            max-height: 300px;
            overflow-y: auto;
            padding: 0.5rem;
        }

        .notification-item {
            padding: 0.8rem;
            border-bottom: 1px solid var(--border-light);
            transition: var(--transition);
        }

        .notification-item:hover {
            background: rgba(0, 212, 255, 0.05);
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-item h5 {
            color: var(--text-light);
            margin-bottom: 0.3rem;
            font-weight: 700;
            font-size: 0.9rem;
        }

        .light-mode .notification-item h5 {
            color: var(--text-dark);
        }

        .notification-item p {
            color: var(--text-light);
            font-size: 0.8rem;
            margin-bottom: 0.3rem;
            font-weight: 600;
            opacity: 0.9;
        }

        .light-mode .notification-item p {
            color: var(--text-dark);
        }

        .notification-item small {
            color: var(--neon);
            font-weight: 600;
            font-size: 0.75rem;
        }

        .light-mode .notification-item small {
            color: var(--secondary);
        }

        .empty-notifications {
            text-align: center;
            padding: 1.5rem;
            color: var(--text-muted);
            font-size: 0.9rem;
        }

        /* Main Content - الحل الحقيقي هنا */
        .student-container {
            min-height: 100vh;
            position: relative;
            z-index: 1;
            padding-top: 80px; /* تأكد أن هذه القيمة أكبر من ارتفاع الهيدر */
        }

        .main-content {
            min-height: calc(100vh - 140px);
            position: relative;
            z-index: 1;
        }

        /* تأثيرات الدخول */
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                padding: 0 1rem;
                flex-wrap: wrap;
                gap: 0.8rem;
            }

            .student-header {
                padding: 0.6rem 0;
                height: 80px;
            }

            .student-header.scrolled {
                padding: 0.4rem 0;
                height: 70px;
            }

            .header-left {
                flex: 1;
            }

            .logo-link h1 {
                font-size: 1.1rem;
            }

            .student-nav {
                order: 3;
                width: 100%;
                justify-content: center;
                gap: 0.5rem;
                margin-top: 0.5rem;
            }

            .nav-link {
                padding: 0.5rem 0.8rem;
                font-size: 0.85rem;
            }

            .user-actions {
                gap: 0.8rem;
            }

            .welcome-message {
                display: none;
            }

            .notification-panel {
                width: 90vw;
                left: 5vw;
                transform: none;
                top: 90px;
            }

            .student-container {
                padding-top: 90px;
            }
        }

        @media (max-width: 480px) {
            .header-content {
                flex-direction: column;
                gap: 0.8rem;
                height: auto;
            }

            .student-header {
                height: auto;
                min-height: 100px;
            }

            .student-header.scrolled {
                height: auto;
                min-height: 90px;
            }

            .header-left {
                width: 100%;
                justify-content: space-between;
            }

            .student-nav {
                order: 2;
                width: 100%;
            }

            .user-actions {
                order: 3;
                width: 100%;
                justify-content: center;
            }

            .notification-panel {
                width: 95vw;
                left: 2.5vw;
                top: 110px;
            }

            .student-container {
                padding-top: 120px;
            }
        }

        @media (max-width: 360px) {
            .student-container {
                padding-top: 130px;
            }
            
            .notification-panel {
                top: 120px;
            }
        }
    </style>
</head>
<body>
    <!-- خلفية ثابتة -->
    <div class="cyber-bg">
        <div class="grid-lines"></div>
    </div>

    <header class="student-header fade-in">
        <div class="header-content">
            <div class="header-left">
                <a href="<?= SITE_URL ?>" class="home-btn" title="الصفحة الرئيسية">
                    <i class="fas fa-home"></i>
                </a>
                <a href="index.php" class="logo-link">
                    <h1><?= SITE_NAME ?></h1>
                </a>
            </div>

            <nav class="student-nav">
                <a href="index.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : '' ?>">
                    <i class="fas fa-play-circle"></i>
                    <span>الكورسات</span>
                </a>
                <a href="profile.php" class="nav-link <?= (basename($_SERVER['PHP_SELF']) == 'profile.php') ? 'active' : '' ?>">
                    <i class="fas fa-user"></i>
                    <span>ملفي الشخصي</span>
                </a>
            </nav>

            <div class="user-actions">
                <div class="notification-icon" id="notification-bell">
                    <i class="fas fa-bell"></i>
                    <span class="notification-count" id="notification-count">0</span>
                </div>
                
                <div class="welcome-message">
                    <span>أهلًا بك،</span>
                    <strong><?= htmlspecialchars($user['name']) ?></strong>
                </div>
                
                <a href="../logout.php" class="logout-btn-student" title="تسجيل الخروج">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>تسجيل الخروج</span>
                </a>
            </div>
        </div>

        <div class="notification-panel" id="notification-panel">
            <div class="panel-header">
                <span>الإشعارات</span>
                <button id="close-notifications" style="background: none; border: none; color: var(--text-light); cursor: pointer;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="panel-body" id="notification-list">
                <div class="empty-notifications">
                    <i class="fas fa-bell-slash" style="font-size: 1.5rem; margin-bottom: 0.5rem; opacity: 0.5;"></i>
                    <p>لا توجد إشعارات جديدة</p>
                </div>
            </div>
        </div>
    </header>

    <main class="student-container">
        <div class="main-content">