<?php
$page_title = 'الملف الشخصي';
include 'partials/header.php';
require_once __DIR__ . '/../includes/db_connection.php';
$pdo = get_db_connection();

$student_id = $user['id'];
$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch();
?>

<div class="page-container">
    <div class="page-header">
        <h1><i class="fas fa-user"></i> ملفي الشخصي</h1>
        <p>هذه هي بياناتك المسجلة في المنصة. لا يمكنك تعديلها مباشرة.</p>
    </div>

    <div class="profile-container">
        <div class="profile-card">
            <div class="profile-header">
                <div class="profile-avatar">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="profile-title">
                    <h2><?= htmlspecialchars($student['name']) ?></h2>
                    <p>طالب في <?= get_grade_text($student['grade']) ?></p>
                </div>
            </div>
            
            <div class="profile-body">
                <div class="profile-section">
                    <h3><i class="fas fa-id-card"></i> المعلومات الأساسية</h3>
                    <div class="profile-grid">
                        <div class="profile-field">
                            <label>ID الخاص بك:</label>
                            <span class="field-value"><?= htmlspecialchars($student['unique_student_id']) ?></span>
                        </div>
                        <div class="profile-field">
                            <label>الاسم بالكامل:</label>
                            <span class="field-value"><?= htmlspecialchars($student['name']) ?></span>
                        </div>
                        <div class="profile-field">
                            <label>رقم الهاتف:</label>
                            <span class="field-value"><?= htmlspecialchars($student['phone']) ?></span>
                        </div>
                        <div class="profile-field">
                            <label>رقم هاتف ولي الأمر:</label>
                            <span class="field-value"><?= htmlspecialchars($student['parent_phone']) ?></span>
                        </div>
                        <div class="profile-field">
                            <label>البريد الإلكتروني:</label>
                            <span class="field-value"><?= htmlspecialchars($student['email']) ?></span>
                        </div>
                        <div class="profile-field">
                            <label>الصف الدراسي:</label>
                            <span class="field-value"><?= get_grade_text($student['grade']) ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="profile-section">
                    <h3><i class="fas fa-info-circle"></i> معلومات الحساب</h3>
                    <div class="profile-grid">
                        <div class="profile-field">
                            <label>حالة الحساب:</label>
                            <span class="field-value">
                                <span class="status-badge status-<?= htmlspecialchars($student['status']) ?>">
                                    <?= get_status_text($student['status']) ?>
                                </span>
                            </span>
                        </div>
                        <div class="profile-field">
                            <label>تاريخ التسجيل:</label>
                            <span class="field-value"><?= date('Y-m-d', strtotime($student['created_at'])) ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="profile-note">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>لتعديل أي من هذه البيانات، يرجى التواصل مع مسؤول المنصة.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.page-container {
    padding: 2rem;
    max-width: 1400px;
    margin: 0 auto;
    min-height: calc(100vh - 200px);
}

.page-header {
    text-align: center;
    margin-bottom: 3rem;
    animation: fadeInUp 0.8s ease-out;
}

.page-header h1 {
    font-size: 2.5rem;
    font-weight: 800;
    color: var(--text-light);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
}

.light-mode .page-header h1 {
    color: var(--text-dark);
}

.page-header h1 i {
    color: var(--neon);
    font-size: 2.8rem;
}

.light-mode .page-header h1 i {
    color: var(--secondary);
}

.page-header p {
    font-size: 1.2rem;
    color: var(--text-light);
    opacity: 0.9;
    font-weight: 600;
}

.light-mode .page-header p {
    color: var(--text-dark);
}

.profile-container {
    max-width: 800px;
    margin: 0 auto;
    animation: fadeInUp 0.8s ease-out;
}

.profile-card {
    background: var(--card-light);
    border-radius: 20px;
    box-shadow: var(--shadow);
    overflow: hidden;
    border: 1px solid var(--border-light);
    transition: var(--transition);
}

.light-mode .profile-card {
    background: var(--card-light);
    border: 1px solid var(--border-light);
    box-shadow: var(--shadow);
}

.profile-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 212, 255, 0.2);
}

.light-mode .profile-card:hover {
    box-shadow: 0 15px 30px rgba(0, 102, 204, 0.2);
}

.profile-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    color: white;
    padding: 2rem;
    display: flex;
    align-items: center;
    gap: 1.5rem;
}

.profile-avatar {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
}

.profile-title h2 {
    margin: 0 0 0.5rem;
    font-size: 1.8rem;
    font-weight: 700;
}

.profile-title p {
    margin: 0;
    opacity: 0.9;
    font-size: 1.1rem;
    font-weight: 600;
}

.profile-body {
    padding: 2rem;
}

.profile-section {
    margin-bottom: 2rem;
}

.profile-section:last-child {
    margin-bottom: 0;
}

.profile-section h3 {
    margin: 0 0 1.5rem;
    padding-bottom: 0.8rem;
    border-bottom: 2px solid var(--border-light);
    color: var(--text-light);
    font-size: 1.3rem;
    display: flex;
    align-items: center;
    gap: 0.8rem;
    font-weight: 700;
}

.light-mode .profile-section h3 {
    color: var(--text-dark);
    border-bottom-color: var(--border-light);
}

.profile-section h3 i {
    color: var(--neon);
}

.light-mode .profile-section h3 i {
    color: var(--secondary);
}

.profile-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
}

.profile-field {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    padding: 1rem;
    background: rgba(0, 212, 255, 0.05);
    border-radius: 10px;
    border: 1px solid var(--border-light);
    transition: var(--transition);
}

.light-mode .profile-field {
    background: rgba(0, 102, 204, 0.05);
    border: 1px solid var(--border-light);
}

.profile-field:hover {
    transform: translateX(5px);
    border-color: var(--secondary);
}

.profile-field label {
    font-weight: 700;
    color: var(--text-light);
    font-size: 0.9rem;
    opacity: 0.9;
}

.light-mode .profile-field label {
    color: var(--text-dark);
}

.field-value {
    color: var(--text-light);
    font-size: 1.05rem;
    font-weight: 600;
}

.light-mode .field-value {
    color: var(--text-dark);
}

.status-badge {
    padding: 0.5rem 1rem;
    border-radius: 20px;
    font-size: 0.85rem;
    font-weight: 700;
    text-align: center;
    display: inline-block;
    min-width: 80px;
}

.status-active {
    background: rgba(0, 255, 136, 0.2);
    color: var(--success);
    border: 1px solid rgba(0, 255, 136, 0.3);
}

.status-inactive {
    background: rgba(255, 0, 102, 0.2);
    color: var(--danger);
    border: 1px solid rgba(255, 0, 102, 0.3);
}

.status-pending {
    background: rgba(255, 193, 7, 0.2);
    color: var(--warning-color);
    border: 1px solid rgba(255, 193, 7, 0.3);
}

.profile-note {
    background: rgba(255, 193, 7, 0.1);
    border: 1px solid rgba(255, 193, 7, 0.3);
    border-radius: 10px;
    padding: 1.2rem;
    margin-top: 2rem;
    display: flex;
    align-items: center;
    gap: 1rem;
}

.profile-note i {
    color: var(--warning-color);
    font-size: 1.3rem;
    flex-shrink: 0;
}

.profile-note p {
    margin: 0;
    color: var(--warning-color);
    font-size: 0.95rem;
    font-weight: 600;
}

@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 768px) {
    .page-container {
        padding: 1rem;
    }

    .page-header h1 {
        font-size: 2rem;
    }
    
    .profile-header {
        flex-direction: column;
        text-align: center;
        padding: 1.5rem;
    }
    
    .profile-body {
        padding: 1.5rem;
    }
    
    .profile-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .profile-field {
        text-align: center;
        padding: 1rem;
    }

    .profile-title h2 {
        font-size: 1.5rem;
    }
}

@media (max-width: 480px) {
    .page-container {
        padding: 0.8rem;
    }

    .page-header h1 {
        font-size: 1.8rem;
    }
    
    .profile-header {
        padding: 1.2rem;
    }
    
    .profile-body {
        padding: 1.2rem;
    }
    
    .profile-avatar {
        width: 70px;
        height: 70px;
        font-size: 1.8rem;
    }
    
    .profile-title h2 {
        font-size: 1.3rem;
    }
    
    .profile-section h3 {
        font-size: 1.1rem;
    }
}
</style>

<?php include 'partials/footer.php'; ?>