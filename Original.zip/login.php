<?php
require_once 'includes/functions.php';

// إذا كان المستخدم مسجل دخوله بالفعل، يتم توجيهه للوحة التحكم
if (current_user()) {
    redirect(is_admin() ? 'admin/index.php' : 'student/index.php');
}

$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once 'includes/auth.php';
    $result = handle_login($_POST);
    
    if (isset($result['error'])) {
        $error = $result['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول - <?= SITE_NAME ?></title>
    
    <!-- مكتبات CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* استخدام نفس نظام الألوان من index.php */
        :root {
            --primary: #0f0f23;
            --primary-dark: #070711;
            --primary-light: #1a1a2e;
            --secondary: #00d4ff;
            --secondary-dark: #0099cc;
            --accent: #7b42f6;
            --accent-dark: #5e2fc9;
            --neon: #e5ff00ff;
            --neon-secondary: #00ffbfff;
            --gold: #ffd700;
            --silver: #c0c0c0;
            --text-dark: #0f172a;
            --text-darker: #020617;
            --text-light: #f0f8ff;
            --text-muted: #94a3b8;
            --bg-light: #0a0a18;
            --bg-dark: #050510;
            --card-light: rgba(16, 16, 36, 0.8);
            --card-dark: rgba(10, 10, 30, 0.9);
            --border-light: rgba(0, 212, 255, 0.3);
            --border-dark: rgba(123, 66, 246, 0.3);
            --shadow: 0 0 20px rgba(0, 212, 255, 0.3);
            --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.4);
            --transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --gradient-primary: linear-gradient(135deg, #60aa00ff, #008ee0ff);
            --gradient-secondary: linear-gradient(135deg, #ff00aa, #7b42f6);
            --gradient-gold: linear-gradient(135deg, #ffd700, #ffaa00);
            --success: #00ff88;
            --danger: #ff0066;
        }

        .light-mode {
            --primary: #f0f8ff;
            --primary-dark: #d6e4f0;
            --primary-light: #ffffff;
            --secondary: #0066cc;
            --secondary-dark: #004499;
            --accent: #7b42f6;
            --accent-dark: #5e2fc9;
            --neon: #0099cc;
            --neon-secondary: #cc0066;
            --gold: #ffaa00;
            --silver: #666666;
            --text-dark: #1e293b;
            --text-darker: #0f172a;
            --text-light: #1e293b;
            --text-muted: #64748b;
            --bg-light: #f0f8ff;
            --bg-dark: #e6f2ff;
            --card-light: rgba(255, 255, 255, 0.9);
            --card-dark: rgba(240, 248, 255, 0.95);
            --border-light: rgba(0, 102, 204, 0.3);
            --border-dark: rgba(123, 66, 246, 0.3);
            --shadow: 0 0 20px rgba(0, 102, 204, 0.2);
            --shadow-dark: 0 0 30px rgba(123, 66, 246, 0.2);
            --gradient-primary: linear-gradient(135deg, #0066cc, #7b42f6);
            --gradient-secondary: linear-gradient(135deg, #cc0066, #7b42f6);
            --gradient-gold: linear-gradient(135deg, #ffaa00, #ff6600);
            --success: #00aa55;
            --danger: #cc0044;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: var(--bg-light);
            color: var(--text-light);
            overflow-x: hidden;
            line-height: 1.6;
            min-height: 100vh;
            transition: background-color 0.8s ease, color 0.5s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
        }

        .light-mode body {
            background: var(--bg-light);
            color: var(--text-dark);
        }

        /* خلفية ثابتة بدون تأثيرات تبطئ الجهاز */
        .cyber-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
            background: 
                radial-gradient(circle at 20% 80%, rgba(0, 212, 255, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(123, 66, 246, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(255, 0, 170, 0.05) 0%, transparent 50%);
        }

        .grid-lines {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(0, 212, 255, 0.05) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 212, 255, 0.05) 1px, transparent 1px);
            background-size: 50px 50px;
        }

        .auth-container {
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            position: relative;
            z-index: 10;
        }

        .auth-box {
            background: var(--card-light);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-light);
            backdrop-filter: blur(10px);
            transition: var(--transition);
            display: flex;
            flex-direction: column;
            min-height: 600px;
        }

        .light-mode .auth-box {
            background: var(--card-light);
            border: 1px solid var(--border-light);
            box-shadow: var(--shadow);
        }

        .auth-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 212, 255, 0.2);
        }

        .light-mode .auth-box:hover {
            box-shadow: 0 15px 30px rgba(0, 102, 204, 0.2);
        }

        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .header-top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .home-btn {
            color: var(--text-light);
            font-size: 1.3rem;
            transition: var(--transition);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        .light-mode .home-btn {
            color: var(--text-dark);
        }

        .home-btn:hover {
            background: var(--border-light);
            transform: scale(1.1);
        }

        .auth-title {
            font-size: 2rem;
            font-weight: 800;
            color: var(--text-light);
            margin: 0;
            flex: 1;
            text-align: center;
        }

        .light-mode .auth-title {
            color: var(--text-dark);
        }

        .auth-subtitle {
            color: var(--text-light);
            font-size: 1.1rem;
            opacity: 0.9;
            font-weight: 600;
        }

        .light-mode .auth-subtitle {
            color: var(--text-dark);
        }

        .auth-content {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .alert {
            padding: 1rem 1.5rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .alert-danger {
            background: rgba(255, 0, 102, 0.1);
            border: 1px solid var(--danger);
            color: var(--danger);
        }

        .alert-success {
            background: rgba(0, 255, 136, 0.1);
            border: 1px solid var(--success);
            color: var(--success);
        }

        .alert i {
            font-size: 1.2rem;
        }

        .auth-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            flex: 1;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-group label {
            color: var(--text-light);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .light-mode .form-group label {
            color: var(--text-dark);
        }

        .form-group label i {
            color: var(--neon);
            width: 20px;
        }

        .light-mode .form-group label i {
            color: var(--secondary);
        }

        .form-group input,
        .form-group select {
            padding: 1rem 1.2rem;
            border-radius: 10px;
            border: 1px solid var(--border-light);
            background: var(--primary-light);
            color: var(--text-light);
            font-size: 1rem;
            transition: var(--transition);
            outline: none;
        }

        .light-mode .form-group input,
        .light-mode .form-group select {
            background: var(--primary-light);
            color: var(--text-dark);
            border: 1px solid var(--border-light);
        }

        .form-group input:focus,
        .form-group select:focus {
            border-color: var(--neon);
            box-shadow: 0 0 0 3px rgba(0, 212, 255, 0.2);
        }

        .light-mode .form-group input:focus,
        .light-mode .form-group select:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(0, 102, 204, 0.2);
        }

        /* تنسيق خاص لعناصر select */
        .form-group select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%2300d4ff' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: left 1.2rem center;
            background-size: 16px;
            padding-left: 3rem;
        }

        .light-mode .form-group select {
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%230066cc' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        }

        .form-group select option {
            background: var(--primary-light);
            color: var(--text-light);
            padding: 10px;
        }

        .light-mode .form-group select option {
            background: var(--primary-light);
            color: var(--text-dark);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.7rem 1.5rem;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            text-align: center;
            white-space: nowrap;
            font-size: 0.9rem;
            justify-content: center;
        }

        .btn-primary {
            background: var(--gradient-primary);
            color: white;
            box-shadow: 0 4px 15px rgba(0, 212, 255, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 7px 20px rgba(0, 212, 255, 0.5);
        }

        .btn-secondary {
            background: transparent;
            color: var(--text-light);
            border: 2px solid var(--secondary);
        }

        .light-mode .btn-secondary {
            color: var(--text-dark);
            border: 2px solid var(--secondary);
        }

        .btn-secondary:hover {
            background: var(--secondary);
            color: white;
            transform: translateY(-3px);
        }

        .btn-block {
            width: 100%;
            display: flex;
        }

        .form-actions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
            margin-top: 1rem;
        }

        .login-info {
            background: rgba(0, 212, 255, 0.1);
            border-radius: 10px;
            padding: 1.5rem;
            margin: 2rem 0;
            border: 1px solid var(--border-light);
        }

        .light-mode .login-info {
            background: rgba(0, 102, 204, 0.1);
            border: 1px solid var(--border-light);
        }

        .login-info h4 {
            color: var(--text-light);
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 700;
        }

        .light-mode .login-info h4 {
            color: var(--text-dark);
        }

        .login-info h4 i {
            color: var(--neon);
        }

        .light-mode .login-info h4 i {
            color: var(--secondary);
        }

        .login-info p {
            color: var(--text-light);
            margin-bottom: 0.5rem;
            font-weight: 600;
            opacity: 0.9;
        }

        .light-mode .login-info p {
            color: var(--text-dark);
        }

        .auth-footer {
            text-align: center;
            margin-top: auto;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-light);
        }

        .auth-footer p {
            color: var(--text-light);
            font-weight: 600;
            opacity: 0.9;
            margin: 0;
        }

        .light-mode .auth-footer p {
            color: var(--text-dark);
        }

        .auth-footer a {
            color: var(--neon);
            text-decoration: none;
            font-weight: 700;
            transition: var(--transition);
        }

        .light-mode .auth-footer a {
            color: var(--secondary);
        }

        .auth-footer a:hover {
            text-decoration: underline;
        }

        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid transparent;
            border-top: 2px solid currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 0.5rem;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .auth-box {
                padding: 2rem 1.5rem;
                min-height: 550px;
            }
            
            .auth-title {
                font-size: 1.8rem;
            }
            
            .header-top {
                flex-direction: column;
                gap: 1rem;
            }
            
            .home-btn {
                align-self: flex-start;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 1rem 0.5rem;
            }
            
            .auth-box {
                padding: 1.5rem 1rem;
                min-height: 500px;
            }
            
            .auth-title {
                font-size: 1.6rem;
            }
            
            .form-group input,
            .form-group select {
                padding: 0.8rem 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- خلفية ثابتة بدون تأثيرات تبطئ الجهاز -->
    <div class="cyber-bg">
        <div class="grid-lines"></div>
    </div>

    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <div class="header-top">
                    <a href="<?= SITE_URL ?>" class="home-btn" title="الصفحة الرئيسية">
                        <i class="fas fa-home"></i>
                    </a>
                    <h1 class="auth-title">تسجيل الدخول</h1>
                </div>
                <p class="auth-subtitle">مرحباً بعودتك! أدخل بياناتك للمتابعة</p>
            </div>

            <div class="auth-content">
                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <form action="login.php" method="POST" class="auth-form" id="loginForm">
                    <input type="hidden" name="csrf_token" value="<?= generate_csrf_token() ?>">
                    
                    <div class="form-group">
                        <label for="login_identifier">
                            <i class="fas fa-user"></i> رقم الهاتف / البريد الإلكتروني:
                        </label>
                        <input type="text" id="login_identifier" name="login_identifier" required autofocus placeholder="أدخل رقم الهاتف أو البريد الإلكتروني">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i> كلمة المرور:
                        </label>
                        <input type="password" id="password" name="password" required placeholder="أدخل كلمة المرور">
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-block" id="submitBtn">
                            <i class="fas fa-sign-in-alt"></i> دخول
                        </button>
                        <a href="<?= SITE_URL ?>" class="btn btn-secondary">
                            <i class="fas fa-home"></i> الصفحة الرئيسية
                        </a>
                    </div>
                </form>

                <div class="login-info">
                    <h4><i class="fas fa-info-circle"></i> معلومات الدخول:</h4>
                    <p>• استخدم رقم الهاتف أو البريد الإلكتروني المسجل</p>
                    <p>• تأكد من إدخال كلمة المرور الصحيحة</p>
                </div>

                <div class="auth-footer">
                    <p>ليس لديك حساب؟ <a href="register.php">أنشئ حسابًا جديدًا</a></p>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('loginForm');
            const submitBtn = document.getElementById('submitBtn');
            
            if (form) {
                form.addEventListener('submit', function() {
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> جاري تسجيل الدخول<span class="loading"></span>';
                });
            }

            // التركيز التلقائي على حقل الإدخال
            const identifierField = document.getElementById('login_identifier');
            if (identifierField) {
                identifierField.focus();
            }
        });
    </script>
</body>
</html>