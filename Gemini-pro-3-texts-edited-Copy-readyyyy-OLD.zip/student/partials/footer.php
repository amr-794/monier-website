</main>
    <footer class="student-footer">
        <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. جميع الحقوق محفوظة.</p>
    </footer>
    <!-- إضافة ملف الجافاسكريبت الرئيسي -->
    <script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>