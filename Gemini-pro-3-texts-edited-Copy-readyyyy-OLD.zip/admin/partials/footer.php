
</main>
    <footer class="admin-footer">
        <p>&copy; <?= date('Y') ?> <?= SITE_NAME ?>. جميع الحقوق محفوظة.</p>
    </footer>
    <script src="<?= SITE_URL ?>/assets/js/session_manager.js"></script>
    <script src="<?= SITE_URL ?>/assets/js/admin-main.js"></script>
    </body>
</html>
